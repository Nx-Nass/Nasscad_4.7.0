# NASSCAD on native Ubuntu — live session or installed system

This folder holds everything needed to run NASSCAD, engine included, on a real
Ubuntu: a live USB, a virtual machine, or an installed system. No Windows, no
WSL, no cross-compiler.

```
install-linux.sh     build and install the MEDUSA engine   (run once)
install-launcher.sh  put NASSCAD in the menu and on the desktop (run once)
nasscad.sh           start the engine and open NASSCAD     (every time)
uninstall-linux.sh   remove everything it installed
nasscad_medusa.cpp   engine source
icons/               application icon, 32 to 256 px
```

---

## 1. What you need

Copy **the whole NASSCAD folder** onto the Ubuntu machine — the four files
above plus `NASSCAD_V4_7_0.htm` and its companions. The launcher finds the
page by looking for it next to itself, then one level up; a renamed folder will
not break it.

Then, once:

```bash
bash install-linux.sh
```

It installs the build tools, builds Manifold and the engine, and runs two
checks before declaring success. Expect **10 to 20 minutes** on a live session,
**25 to 75 minutes** on an installed system — the difference is explained
below and it is deliberate.

---

## 2. The one decision the installer makes for you

Where OpenCASCADE comes from. It matters enough to be explicit.

| Situation | OCCT source | Why |
|---|---|---|
| **Live session** | apt package | The root filesystem is a RAM overlay. Building OCCT needs ~20 GB; you do not have it. apt takes 2–3 minutes. |
| **Installed system** | 8.0.1 from source | Strict parity with the Windows build, which compiles exactly that version with exactly the same options. Built once, then cached. |

Detection uses three independent signals — `boot=casper`/`boot=live` on the
kernel command line, the presence of `/run/live/medium`, and an `overlay`
filesystem on `/`. Any one is enough. It also falls back to apt if `$HOME` has
less than 20 GB free, whatever the session type.

Override it if you disagree:

```bash
bash install-linux.sh --occt=apt       # fast, whatever the distro ships
bash install-linux.sh --occt=source    # 8.0.1, parity with Windows
bash install-linux.sh --rebuild        # force a fresh OCCT build
```

`--occt=source` on a live session is **refused** unless you add `--force`. That
is not politeness: the build would run for twenty minutes and then die with a
disk-full error that reads exactly like a compiler crash. Better to stop at the
start than to waste your time and mislead you.

**Does the apt version cost you anything?** For colours, no — the semantics the
engine relies on have been stable since OCCT 7.5, and the colour self-test
passes identically on both. STEP tessellation may differ at the margin between
OCCT versions. On a live session, take apt without a second thought.

---

## 3. Running it

```bash
bash nasscad.sh
```

Starts the engine if it is not already up, waits for it to answer, then opens
NASSCAD in your browser.

**Or click an icon, like on Windows.** Run this once:

```bash
bash install-launcher.sh
```

It puts NASSCAD in your applications menu, on your desktop as a
double-clickable icon, and as a plain `nasscad` command. All three run the same
`nasscad.sh`. Right-clicking the icon offers *engine only*, *follow log* and
*stop*.

Worth knowing, because it is the usual source of "my script does nothing":
a `.sh` file is **not** double-clickable on Linux — most file managers open it
in a text editor instead. What you click is a `.desktop` entry, which is what
that script writes. Nothing goes outside your home folder, no sudo, and
`bash install-launcher.sh --remove` takes it all back out.

If `nasscad` says *command not found* in a terminal, log out and back in:
`~/.local/bin` only joins your PATH at login. Re-run `install-launcher.sh`
after moving the NASSCAD folder — the entry stores an absolute path.

The engine opens in **its own terminal window**, the same way it does on
Windows: you read the log live, and closing that window stops it. No PID to
hunt. On a machine with no graphical session — a server, an SSH login — it
falls back to a detached process and tells you where the log is.

```bash
bash nasscad.sh --stop          # stop the engine
bash nasscad.sh --log           # follow the log of a background engine
bash nasscad.sh --background    # start detached, no window
bash nasscad.sh --no-browser    # engine only, do not open the page
bash nasscad.sh --logfile       # engine also writes medusa-logs-<date>.txt
```

The engine itself writes **no log file** unless `--logfile` asks for one. Its
journal lives in memory — the last 20 000 lines — and is read on demand: the
jellyfish button in the NASSCAD Logs panel pulls it in over `GET /log`, beside
the browser-side log of the same session. `--log` above is a different thing: it
follows `/tmp/nasscad_medusa.log`, where a *detached* engine's console output is
redirected.

**The one thing that will waste your time if you do not know it:** NASSCAD
probes for the engine **once per page session**. If the page was already open
before the engine started, it has memorised "absent" and will not look again.
Press **F5**. The Logs panel must then show:

```
⚡ NASSCAD Engine detected (native localhost companion)
```

---

## 4. Checking it yourself

Two commands, both quick.

```bash
~/nasscad-medusa/engine/nasscad_medusa --selftest-colors
```

Must end on `ALL PASS — 0 failure(s)`. It verifies the sRGB round-trip and the
solid-versus-face colour precedence table on the edge cases found in real CAD
exports. No file, no server, a few milliseconds. If this fails, something is
wrong with the build — do not go looking at the browser.

```bash
curl http://127.0.0.1:8765/ping
```

Should report `"csgtree":true`, and `"occt"` tells you which kernel version you
actually ended up on.

---

## 5. Why the engine is worth the install

Without it NASSCAD still opens STEP files in the browser alone, but with two
limits that were measured, not assumed: colours come **per part only** — the
in-browser engine exposes no per-face colour at all — and large assemblies may
tessellate to nothing. Up to roughly 20 MB the browser is comfortable. Beyond
that the engine is not an accelerator, it is the requirement.

And for booleans it is the requirement outright, at any size: since 4.7.0
`manifold.js` is gone from the browser entirely. With the engine stopped,
Union / Subtraction / Intersection stop with an explicit error rather than
silently degrading — there is no WASM fallback left to fall back to.

---

## 6. If something goes wrong

| Symptom | Cause |
|---|---|
| `install-linux.sh: command not found` on a line that looks fine | The file picked up Windows line endings. `sed -i 's/\r$//' *.sh` |
| Build dies with no space left | A live session, or a small `$HOME`. Use `--occt=apt`. |
| `cannot open shared object file: libTK...` | The engine cannot find OCCT. Rebuild with `bash install-linux.sh` — the link sets an RPATH, and a stale binary from an older attempt will not have it. |
| Engine starts, NASSCAD does not see it | Press F5 on the page. See §3. |
| `no answer on port 8765` | Another process holds the port: `ss -lptn 'sport = :8765'` |

| Double-clicking `nasscad.sh` opens it in a text editor | Expected — see §3, use `install-launcher.sh`. |
| The desktop icon shows as a text file and will not run | GNOME does not trust it yet. `install-launcher.sh` sets that flag; if it did not take, right-click it and choose *Allow launching*. |

Uninstall everything the installer created:

```bash
bash uninstall-linux.sh
bash install-launcher.sh --remove
```
