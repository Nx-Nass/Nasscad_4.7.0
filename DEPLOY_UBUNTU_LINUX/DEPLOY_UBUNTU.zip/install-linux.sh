#!/bin/bash
# ============================================================================
# install-linux.sh -- NASSCAD MEDUSA engine, native Ubuntu (live or installed)
#
# Same job as deploy.sh on WSL, minus everything Windows: no MinGW cross
# compiler, no wslpath, no copying files back to a Windows folder. The browser
# is on this machine, so the engine and the page are neighbours.
#
# THE ONE REAL DECISION THIS SCRIPT MAKES -- where OCCT comes from.
#
#   Building OCCT 8.0.1 from source gives strict parity with the Windows/MSVC
#   build, but it needs roughly 20 GB of disk and 15 to 60 minutes. On a LIVE
#   session the root filesystem is a RAM overlay: 20 GB simply is not there,
#   and the build dies half-way with a disk-full error that looks like a
#   compiler bug. So:
#
#     live session      -> OCCT from apt (2-3 minutes, whatever the distro
#                          ships -- 7.6.3 on 24.04). Everything works; the
#                          colour decoding is identical, only the mesher may
#                          differ at the margin from the Windows build.
#     installed system  -> OCCT 8.0.1 from source. Full parity. Cached, so
#                          you pay the build once.
#
#   Override with  --occt=apt  or  --occt=source  if you disagree with the
#   detection. --occt=source on a live session is refused unless you also
#   pass --force: it is not a warning worth ignoring by accident.
#
# Usage:  bash install-linux.sh [--occt=auto|apt|source] [--force] [--rebuild]
# ============================================================================
set -e

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NASSCAD_HOME="$HOME/nasscad-medusa"
ENGINE_DIR="$NASSCAD_HOME/engine"

OCCT_VERSION="8.0.1"
OCCT_TAG="V8_0_1"
OCCT_ROOT="$HOME/occt801_gcc"
OCCT_SRC="$OCCT_ROOT/src"
OCCT_BUILD="$OCCT_ROOT/build"
OCCT_INSTALL="$OCCT_ROOT/install"

OCCT_MODE="auto"
FORCE=0
REBUILD=0
for a in "$@"; do
    case "$a" in
        --occt=auto|--occt=apt|--occt=source) OCCT_MODE="${a#--occt=}" ;;
        --force)   FORCE=1 ;;
        --rebuild) REBUILD=1 ;;
        -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
        *) echo "Unknown option: $a"; exit 1 ;;
    esac
done

vital() {
    if ! eval "$2"; then
        echo "    FAILED: $1"
        echo "    Stopping -- nothing left half-done."
        exit 1
    fi
    echo "    OK: $1"
}

echo "==================================================="
echo "  NASSCAD MEDUSA -- native Linux install"
echo "==================================================="

vital "nasscad_medusa.cpp found next to this script" "[ -f '$HERE/nasscad_medusa.cpp' ]"

# -- [1] Live session or installed system? ----------------------------------
# Three independent signals, any one is enough. A live USB with persistence
# still reports as live, which is the safe answer: persistence is usually a
# few GB, not the 20 GB an OCCT build wants.
IS_LIVE=0
grep -qE '(^| )(boot=casper|boot=live)( |$)' /proc/cmdline 2>/dev/null && IS_LIVE=1
[ -d /run/live/medium ] && IS_LIVE=1
[ "$(findmnt -no FSTYPE / 2>/dev/null)" = "overlay" ] && IS_LIVE=1

AVAIL_GB=$(( $(df -P -k "$HOME" | awk 'NR==2{print $4}') / 1048576 ))

echo ""
echo "[env] Session          : $([ "$IS_LIVE" = 1 ] && echo 'LIVE (RAM overlay)' || echo 'installed')"
echo "[env] Free space in \$HOME : ${AVAIL_GB} GB"
echo "[env] CPU cores        : $(nproc)"

if [ "$OCCT_MODE" = "auto" ]; then
    if [ "$IS_LIVE" = 1 ]; then
        OCCT_MODE="apt"
    elif [ "$AVAIL_GB" -lt 20 ]; then
        echo "[env] Less than 20 GB free -- falling back to the apt OCCT."
        echo "      Use --occt=source --force to build anyway."
        OCCT_MODE="apt"
    else
        OCCT_MODE="source"
    fi
fi

if [ "$OCCT_MODE" = "source" ] && [ "$IS_LIVE" = 1 ] && [ "$FORCE" != "1" ]; then
    echo ""
    echo "  REFUSED: --occt=source on a live session."
    echo "  The root filesystem is a RAM overlay; an OCCT build needs ~20 GB and"
    echo "  will die half-way with a disk-full error that reads like a compiler"
    echo "  crash. Add --force if you know your session has real storage."
    exit 1
fi

echo "[env] OCCT source      : $OCCT_MODE"

SUDO=""
[ "$(id -u)" = "0" ] || SUDO="sudo"

# -- [2] System packages -----------------------------------------------------
echo ""
echo "[step 1/5] System packages"
$SUDO apt-get update || echo "    (at least one repo failed -- continuing)"

if [ "$OCCT_MODE" = "apt" ]; then
    $SUDO apt-get install -y build-essential cmake git curl libtbb-dev \
        libocct-foundation-dev libocct-modeling-data-dev \
        libocct-modeling-algorithms-dev libocct-data-exchange-dev \
        libocct-ocaf-dev
else
    # No libocct-*-dev here on purpose: their headers in /usr/include/opencascade
    # would sit beside ours and you would never be sure which one you compiled
    # against. We pass an explicit -I, but why leave the ambiguity in place.
    $SUDO apt-get install -y build-essential cmake git curl libtbb-dev
fi
vital "g++ installed"   "command -v g++ >/dev/null 2>&1"
vital "cmake installed" "command -v cmake >/dev/null 2>&1"
vital "git installed"   "command -v git >/dev/null 2>&1"

# -- [3] OCCT ----------------------------------------------------------------
echo ""
echo "[step 2/5] OpenCASCADE"

if [ "$OCCT_MODE" = "apt" ]; then
    OCCT_INC="/usr/include/opencascade"
    OCCT_LIB=""            # system paths, already in the ldconfig cache
    OCCT_RPATH=""
    vital "OCCT headers present" "[ -d '$OCCT_INC' ]"
    OCCT_VER="$(sed -n 's/^#define *OCC_VERSION_COMPLETE *"\([^"]*\)".*/\1/p' \
                "$OCCT_INC/Standard_Version.hxx" 2>/dev/null)"
    echo "    OCCT version (apt): ${OCCT_VER:-unknown}"
    if [ "$OCCT_VER" != "$OCCT_VERSION" ]; then
        echo "    NOTE: the Windows build uses $OCCT_VERSION. Colour decoding is"
        echo "          identical (the semantics have been stable since 7.5);"
        echo "          STEP tessellation may differ at the margin."
    fi
else
    OCCT_INC="$OCCT_INSTALL/include/opencascade"
    OCCT_LIB="$OCCT_INSTALL/lib"
    OCCT_RPATH="-Wl,-rpath,$OCCT_LIB"

    OCCT_HAVE=""
    [ -f "$OCCT_INC/Standard_Version.hxx" ] && OCCT_HAVE="$(sed -n \
        's/^#define *OCC_VERSION_COMPLETE *"\([^"]*\)".*/\1/p' "$OCCT_INC/Standard_Version.hxx")"
    [ "$REBUILD" = "1" ] && { rm -rf "$OCCT_ROOT"; OCCT_HAVE=""; }

    if [ "$OCCT_HAVE" = "$OCCT_VERSION" ]; then
        echo "    OCCT $OCCT_VERSION already built -- reused. (--rebuild to force)"
    else
        [ -n "$OCCT_HAVE" ] && { echo "    Found $OCCT_HAVE, want $OCCT_VERSION -- rebuilding."; rm -rf "$OCCT_ROOT"; }
        echo "    Building OCCT $OCCT_VERSION from source."
        echo "    15 to 60 minutes depending on the machine. This happens ONCE."
        mkdir -p "$OCCT_ROOT"
        [ -d "$OCCT_SRC/.git" ] || git clone --depth 1 --branch "$OCCT_TAG" \
            https://github.com/Open-Cascade-SAS/OCCT.git "$OCCT_SRC"
        mkdir -p "$OCCT_BUILD"
        # Options copied verbatim from build_msvc.bat -- that is what "parity"
        # means here. Visualization and Draw off also removes the X11, Tcl/Tk
        # and FreeType build dependencies.
        ( cd "$OCCT_BUILD" && cmake "$OCCT_SRC" \
            -DCMAKE_BUILD_TYPE=Release \
            -DCMAKE_INSTALL_PREFIX="$OCCT_INSTALL" \
            -DBUILD_LIBRARY_TYPE=Shared \
            -DBUILD_DOC_Overview=OFF \
            -DBUILD_MODULE_Visualization=OFF \
            -DBUILD_MODULE_Draw=OFF \
            -DUSE_FREETYPE=OFF -DUSE_TBB=ON -DUSE_FREEIMAGE=OFF \
            -DUSE_OPENVR=OFF -DUSE_FFMPEG=OFF )
        ( cd "$OCCT_BUILD" && make -j"$(nproc)" && make install )
    fi
    vital "OCCT $OCCT_VERSION headers installed" "[ -f '$OCCT_INC/Standard_Version.hxx' ]"
    vital "OCCT XCAF toolkit built" "[ -f '$OCCT_LIB/libTKXCAF.so' ]"
fi

# Toolkit naming: 7.8 consolidated the STEP toolkits into TKDE/TKDESTEP.
#
# The two branches below are deliberately separate, and this is not
# over-engineering -- the naive single test is WRONG and was caught in
# testing. Asking "is there a libTKSTEP.so anywhere" via ldconfig answers for
# the SYSTEM: on a machine that also carries the apt OCCT 7.6.3, it says yes,
# and the source build (8.0.1, which has no TKSTEP at all) would be linked
# against toolkit names that do not exist in its own prefix. When we own the
# prefix, that prefix is the only thing allowed to answer.
if [ -n "$OCCT_LIB" ]; then
    if [ -f "$OCCT_LIB/libTKSTEP.so" ]; then OCCT_LAYOUT="old"; else OCCT_LAYOUT="new"; fi
else
    if ldconfig -p 2>/dev/null | grep -q "libTKSTEP\.so"; then OCCT_LAYOUT="old"; else OCCT_LAYOUT="new"; fi
fi

if [ "$OCCT_LAYOUT" = "old" ]; then
    echo "    OCCT <=7.7 layout (separate TKSTEP)"
    STEP_LIBS="-lTKSTEP -lTKSTEPBase -lTKSTEPAttr -lTKXSBase -lTKShHealing"
    XDE_STEP_LIBS="-lTKXDESTEP"
else
    echo "    OCCT >=7.8 layout (TKDE/TKDESTEP consolidated)"
    STEP_LIBS="-lTKDE -lTKDESTEP -lTKXSBase -lTKShHealing"
    XDE_STEP_LIBS=""
fi

# -- [4] Manifold ------------------------------------------------------------
echo ""
echo "[step 3/5] Manifold (native CSG engine)"
mkdir -p "$ENGINE_DIR"
rm -rf "$ENGINE_DIR/manifold_src"
git clone --depth 1 https://github.com/elalish/manifold.git "$ENGINE_DIR/manifold_src"
mkdir -p "$ENGINE_DIR/manifold_src/build"
( cd "$ENGINE_DIR/manifold_src/build" && \
  cmake .. -DCMAKE_BUILD_TYPE=Release -DMANIFOLD_PAR=ON -DMANIFOLD_TEST=OFF \
           -DMANIFOLD_PYBIND=OFF -DMANIFOLD_CBIND=ON && \
  make manifoldc -j"$(nproc)" )
vital "libmanifoldc.so built" "[ -f '$ENGINE_DIR/manifold_src/build/bindings/c/libmanifoldc.so' ]"
cp "$ENGINE_DIR/manifold_src/build/bindings/c/libmanifoldc.so"* "$ENGINE_DIR/"

# -- [5] Engine --------------------------------------------------------------
echo ""
echo "[step 4/5] Compiling nasscad_medusa"
cp "$HERE/nasscad_medusa.cpp" "$ENGINE_DIR/nasscad_medusa.cpp"
pkill -f 'nasscad_medusa$' 2>/dev/null && sleep 0.5 || true

# --disable-new-dtags is not cosmetic. By default ld emits a RUNPATH, and a
# RUNPATH is NOT consulted when resolving the dependencies OF the dependencies.
# With OCCT in a private prefix, libTKXCAF.so then fails to find libTKVCAF.so
# and the binary refuses to start -- "cannot open shared object file" -- even
# though it compiled and linked without a single error. This flag emits an
# RPATH instead, which is inherited. Measured: 27 libraries not found before,
# zero after. Harmless on the apt path, where nothing needs an rpath at all.
#
# -lTKVCAF is absent on purpose: it belongs to the Visualization module, which
# the parity build switches off. The MSVC build links without it too.
g++ -O2 -std=c++17 -pthread -I"$OCCT_INC" \
    -I"$ENGINE_DIR/manifold_src/bindings/c/include" \
    "$ENGINE_DIR/nasscad_medusa.cpp" -o "$ENGINE_DIR/nasscad_medusa" \
    -L"$ENGINE_DIR" -lmanifoldc \
    ${OCCT_LIB:+-L"$OCCT_LIB"} -Wl,--disable-new-dtags -Wl,-rpath,'$ORIGIN' $OCCT_RPATH \
    $STEP_LIBS $XDE_STEP_LIBS -lTKXCAF -lTKCAF -lTKLCAF \
    -lTKMesh -lTKTopAlgo -lTKGeomAlgo -lTKGeomBase \
    -lTKBRep -lTKG3d -lTKG2d -lTKMath -lTKernel
vital "nasscad_medusa binary produced" "[ -x '$ENGINE_DIR/nasscad_medusa' ]"
DEPS_MISSING=$(ldd "$ENGINE_DIR/nasscad_medusa" 2>/dev/null | grep "not found" || true)
vital "zero missing shared library (ldd)" "[ -z '$DEPS_MISSING' ]"

# -- [6] Checks --------------------------------------------------------------
echo ""
echo "[step 5/5] Verification"
cd "$ENGINE_DIR"

# Colour self-test. Milliseconds, no file, no server. 'timeout' guards the case
# of a binary built from an old .cpp: it would read --selftest-colors as a port
# number and start a server that never returns.
if timeout 30 ./nasscad_medusa --selftest-colors >/tmp/nasscad_selftest.log 2>&1 \
   && grep -q "ALL PASS" /tmp/nasscad_selftest.log; then
    sed 's/^/    /' /tmp/nasscad_selftest.log
else
    echo "    FAILED: colour self-test did not pass."
    sed 's/^/    /' /tmp/nasscad_selftest.log 2>/dev/null || true
    exit 1
fi

pkill -f 'nasscad_medusa$' 2>/dev/null && sleep 0.5 || true
./nasscad_medusa >/tmp/nasscad_medusa_smoketest.log 2>&1 &
_PID=$!
sleep 1
if kill -0 "$_PID" 2>/dev/null && curl -s -f http://127.0.0.1:8765/ping >/tmp/ping.json 2>/dev/null; then
    echo "    OK: server answers: $(cat /tmp/ping.json)"
    grep -q '"csgtree":true' /tmp/ping.json \
        && echo "    OK: native CSG tree endpoint present (parity with MSVC)." \
        || echo "    WARNING: no csgtree -- built from an outdated .cpp."
else
    echo "    FAILED: no answer -- see /tmp/nasscad_medusa_smoketest.log"
    kill "$_PID" 2>/dev/null || true
    exit 1
fi
kill "$_PID" 2>/dev/null || true
wait "$_PID" 2>/dev/null || true

echo ""
echo "==================================================="
echo "  Installed."
echo "    Engine : $ENGINE_DIR/nasscad_medusa"
echo "    Start  : bash nasscad.sh   (starts it and opens the page)"
echo "==================================================="
