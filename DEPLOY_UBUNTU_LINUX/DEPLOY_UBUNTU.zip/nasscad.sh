#!/bin/bash
# ============================================================================
# nasscad.sh -- starts the MEDUSA engine and opens NASSCAD in your browser.
#
# Native Linux counterpart of medusa.bat. Put it next to
# NASSCAD_V4_7_0_DEV.htm, or anywhere above it, and run:
#
#     bash nasscad.sh
#
#     --stop        stop the engine and exit
#     --no-browser  start the engine only, do not open a page
# ============================================================================
set -u

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENGINE="$HOME/nasscad-medusa/engine/nasscad_medusa"
PAGE_NAME="NASSCAD_V4_7_0_DEV.htm"
PORT=8765
LOG="/tmp/nasscad_medusa.log"

OPEN_BROWSER=1
BACKGROUND=0
for a in "${@:-}"; do
    case "$a" in
        --stop)
            if pkill -f 'nasscad_medusa$' 2>/dev/null; then
                echo "  MEDUSA stopped."
            else
                echo "  MEDUSA was not running."
            fi
            exit 0 ;;
        --log)
            [ -f "$LOG" ] || { echo "  No log yet: $LOG"; exit 1; }
            echo "  Following $LOG -- Ctrl+C to stop watching (the engine keeps running)."
            exec tail -f "$LOG" ;;
        --no-browser) OPEN_BROWSER=0 ;;
        --background) BACKGROUND=1 ;;
        "" ) ;;
        *) echo "Unknown option: $a"; exit 1 ;;
    esac
done

# Opens the engine in a visible terminal window, the way medusa.bat does on
# Windows. Same reasoning: you read the log live, and closing the window stops
# the engine -- no PID to hunt. Falls back to a detached process when no
# terminal emulator is available (a server, an SSH session, a bare TTY).
start_in_terminal() {
    local dir title cmd
    dir="$(dirname "$ENGINE")"
    title="NASSCAD MEDUSA Engine"
    cmd="cd '$dir'; exec ./nasscad_medusa"
    if   command -v gnome-terminal   >/dev/null 2>&1; then gnome-terminal --title="$title" -- bash -c "$cmd"
    elif command -v konsole          >/dev/null 2>&1; then konsole --hold -p tabtitle="$title" -e bash -c "$cmd"
    elif command -v xfce4-terminal   >/dev/null 2>&1; then xfce4-terminal --title="$title" -e "bash -c \"$cmd\""
    elif command -v mate-terminal    >/dev/null 2>&1; then mate-terminal --title="$title" -e "bash -c \"$cmd\""
    elif command -v tilix            >/dev/null 2>&1; then tilix -t "$title" -e bash -c "$cmd"
    elif command -v kitty            >/dev/null 2>&1; then kitty --title "$title" bash -c "$cmd"
    elif command -v alacritty        >/dev/null 2>&1; then alacritty -t "$title" -e bash -c "$cmd"
    elif command -v x-terminal-emulator >/dev/null 2>&1; then x-terminal-emulator -T "$title" -e bash -c "$cmd"
    elif command -v xterm            >/dev/null 2>&1; then xterm -T "$title" -e bash -c "$cmd"
    else return 1
    fi
    return 0
}

echo "============================================================"
echo "  NASSCAD -- launcher"
echo "============================================================"

# -- 1. Find the page --------------------------------------------------------
# By content, not by folder name: the right folder is the one holding the page.
# Looked for next to this script first, then one level up, then in the usual
# places. A renamed folder must not break the launcher.
PAGE=""
for d in "$HERE" "$HERE/.." "$HERE/../.." "$HOME/NASSCAD" "$HOME/Downloads"; do
    [ -f "$d/$PAGE_NAME" ] && { PAGE="$(cd "$d" && pwd)/$PAGE_NAME"; break; }
done
if [ -z "$PAGE" ]; then
    for d in "$HOME"/*NASSCAD*/ "$HOME"/Downloads/*NASSCAD*/; do
        [ -f "$d/$PAGE_NAME" ] && { PAGE="$(cd "$d" && pwd)/$PAGE_NAME"; break; }
    done
fi
if [ -z "$PAGE" ] && [ "$OPEN_BROWSER" = "1" ]; then
    echo "  WARNING: $PAGE_NAME not found. Starting the engine only."
    OPEN_BROWSER=0
fi
[ -n "$PAGE" ] && echo "  Page   : $PAGE"

# -- 2. Engine present? ------------------------------------------------------
if [ ! -x "$ENGINE" ]; then
    echo ""
    echo "  ERROR: engine not built."
    echo "         Expected: $ENGINE"
    echo "         Run once:  bash install-linux.sh"
    exit 1
fi
echo "  Engine : $ENGINE"

# -- 3. Already running? -----------------------------------------------------
# A second instance would die on bind() -- port already taken. Reuse it.
if curl -s -f -m 2 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then
    echo "  MEDUSA is ALREADY running -- reusing it."
else
    echo "  Starting MEDUSA..."
    VISIBLE=0
    if [ "$BACKGROUND" = "0" ] && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && start_in_terminal 2>/dev/null; then
        VISIBLE=1
        echo "  Engine window opened -- close it to stop the engine."
    else
        ( cd "$(dirname "$ENGINE")" && nohup ./nasscad_medusa >"$LOG" 2>&1 & )
        echo "  Engine started in the background -- log: $LOG"
        echo "  Follow it with: bash nasscad.sh --log"
    fi
    READY=0
    for _ in $(seq 1 20); do
        if curl -s -f -m 2 "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then READY=1; break; fi
        sleep 1
    done
    if [ "$READY" = "1" ]; then
        echo "  MEDUSA is up: $(curl -s -m 2 "http://127.0.0.1:$PORT/ping")"
    else
        echo ""
        echo "  WARNING: no answer on port $PORT after 20 seconds."
        if [ "$VISIBLE" = "1" ]; then
            echo "           Read the engine window -- the reason is in there."
        else
            echo "           Read $LOG -- the reason is in there."
        fi
        echo "           Common cause: another process already holds the port."
        echo "           NASSCAD will still open, on the in-browser engine:"
        echo "           no per-face colours, large assemblies may fail."
    fi
fi

# -- 4. Open the page --------------------------------------------------------
if [ "$OPEN_BROWSER" = "1" ]; then
    echo "  Opening $PAGE_NAME..."
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$PAGE" >/dev/null 2>&1 &
    elif command -v firefox >/dev/null 2>&1; then
        firefox "$PAGE" >/dev/null 2>&1 &
    else
        echo "  No browser launcher found. Open this by hand:"
        echo "    $PAGE"
    fi
fi

cat <<EOF

============================================================
  IMPORTANT: NASSCAD probes MEDUSA ONCE per page session.
  If the page was already open before the engine started,
  press F5 -- otherwise it keeps believing MEDUSA is absent.
  The Logs panel must show:
    "NASSCAD Engine detected (native localhost companion)"

  Stop the engine:  close its window, or  bash nasscad.sh --stop
  Watch the log:    bash nasscad.sh --log
  Headless start:   bash nasscad.sh --background
============================================================
EOF
