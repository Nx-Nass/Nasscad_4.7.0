// nasscad_medusa.cpp — NASSCAD MEDUSA ENGINE 3.1 : compagnon natif localhost (OCCT C++).
// Un seul fichier, un seul binaire — ce fichier EST le moteur (parsing STEP,
// tessellation, CSG, smoothing, repair), pas un "booster" separe greffe a
// cote : plus simple a maintenir, une seule chose a recompiler/versionner.
// Implémente le protocole NSTP v1 tel que spécifié dans step-import.js :
//   ['NSTP'|u32 ver|u32 jsonLen|u32 binLen][JSON padded%4][BIN: pos+idx par mesh]
// Endpoints :
//   GET  /ping   -> détection au boot (JSON court, latence minimale)
//   POST /step   -> body = fichier STEP brut -> réponse = buffer NSTP v1
//   OPTIONS *    -> préflight CORS (ACAO:*, Private-Network-Access)
// Bind strict 127.0.0.1 — jamais 0.0.0.0. Usage local mono-utilisateur uniquement.
// [15/08] Tessellation STEP parallélisée (pool de threads, verrou par TShape
// partagé) + logging console/fichier bufferisé (TeeStreambuf) — voir les
// commentaires datés [15/08] plus bas pour le détail des deux changements.

#include <STEPCAFControl_Reader.hxx>
#include <STEPControl_Reader.hxx>
#include <IFSelect_ReturnStatus.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFApp_Application.hxx>
#include <XCAFDoc_DocumentTool.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <XCAFDoc_ColorTool.hxx>
#include <TDF_LabelSequence.hxx>
#include <TDataStd_Name.hxx>
#include <TCollection_ExtendedString.hxx>
#include <Quantity_Color.hxx>
#include <Quantity_TypeOfColor.hxx>   // [26/08] Quantity_TOC_sRGB (explicite, cf. occtColorToSRGB)
#include <TopoDS_Shape.hxx>
#include <TopoDS_Face.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <manifold/manifoldc.h>
#include <unordered_map>
#include <unordered_set>
#include <ShapeFix_Shape.hxx>
#include <ShapeAnalysis_FreeBounds.hxx>
#include <Message_ProgressIndicator.hxx>
#include <Message_ProgressScope.hxx>
#include <cmath>
#include <thread>
#include <future>
#ifndef _WIN32
  // sys/sysinfo.h (struct sysinfo / sysinfo()) est une API glibc/Linux —
  // absente de MSVC ET de MinGW-w64. Version Windows de readAvailableRamMB()
  // plus bas : GlobalMemoryStatusEx (windows.h, inclus dans le bloc _WIN32
  // ci-dessous) n'en a de toute facon pas besoin.
  #include <sys/sysinfo.h>
#endif
#include <cstdlib>
#include <new>          // [01/09] std::bad_alloc — leve par ManifoldArena
#include <fstream>
#include <sstream>
#include <mutex>
#include <atomic>
#include <TopoDS_Compound.hxx>
#include <TopoDS_Iterator.hxx>
#include <Bnd_Box.hxx>
#include <BRepBndLib.hxx>
#include <BRep_Tool.hxx>
#include <Poly_Triangulation.hxx>
#include <TopLoc_Location.hxx>
#include <gp_Pnt.hxx>
#include <Message.hxx>
#include <Message_Messenger.hxx>
#include <Standard_Version.hxx>  // OCC_VERSION_COMPLETE -> version OCCT dans /ping

#ifdef _WIN32
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #include <windows.h>   // GlobalMemoryStatusEx (readAvailableRamMB) — inclus APRES
                          // winsock2.h/ws2tcpip.h, ordre obligatoire pour eviter le
                          // conflit de redefinition winsock.h vs winsock2.h.
  #ifndef CP_UTF8
    // [FIX compilation] Sur certains toolchains MinGW-w64, windows.h ne tire
    // pas systematiquement winnls.h (selon version du SDK/ordre d'inclusion
    // avec winsock2.h ci-dessus) : SetConsoleOutputCP() reste visible (declare
    // ailleurs) mais pas la macro CP_UTF8. 65001 est la valeur numerique fixe
    // de cette codepage, stable et documentee sur toutes les versions de
    // Windows -- ce repli compile a l'identique que la macro SDK soit
    // presente ou non (#ifndef evite toute redefinition en conflit).
    #define CP_UTF8 65001
  #endif
  #pragma comment(lib, "ws2_32.lib")
  typedef SOCKET SocketFD;
  #define NASSCAD_SOCK_INVALID INVALID_SOCKET
  static void nasscadCloseSocket(SocketFD s){ closesocket(s); }
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <netinet/tcp.h> // [PERF 18/08] TCP_NODELAY (cf. accept() dans main()) — absent de netinet/in.h
  #include <arpa/inet.h>
  #include <sys/time.h>   // [28/08 AUDIT] struct timeval — SO_RCVTIMEO/SO_SNDTIMEO (cf. accept() dans main())
  #include <unistd.h>
  #include <csignal>
  typedef int SocketFD;
  #define NASSCAD_SOCK_INVALID (-1)
  static void nasscadCloseSocket(SocketFD s){ close(s); }
#endif
#include <cstring>
#include <cstdio>
#include <cstdint>
#include <cctype>   // [28/08] std::isspace — stepHeaderInfo (parsing de l'en-tete STEP)
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <chrono>
#include <ctime>
#include <algorithm>
#include <optional>
#include <memory>

using Clock = std::chrono::high_resolution_clock;
static double ms(Clock::time_point a, Clock::time_point b) {
    return std::chrono::duration<double, std::milli>(b - a).count();
}

// [15/08] Mutex console/log unique — protège TOUTE écriture std::cerr
// atteignable depuis un thread de travail (tessellation parallèle, cf. plus
// bas) ainsi que la globale gBarActive/gLastBarLen (barres de progression)
// qu'elles mutent. Sans lui, deux threads tessellant deux pièces en parallèle
// et loggant chacun une ligne [REPAIR]/[MANIFOLD-RAW] en même temps
// corrompraient l'état interne de TeeStreambuf (course sur atLineStart_/
// ansiState_/gBarActive), pas juste l'affichage. Les points d'appel restés
// mono-thread (ConsoleProgress::Show pendant le PARSING, encodeNSTP après le
// join des threads) ne le prennent pas : aucune concurrence possible là.
static std::mutex gConsoleMutex;

// [15/08 FIX v4] Declaration anticipee — definition complete plus bas (a cote
// de drawBarLine/barPhaseStart, dont elle partage l'esprit). Necessaire ici
// car logRawManifoldCheck (juste en dessous) l'utilise avant ce point du
// fichier.
static void logFileOnly(const std::string& msg);
// [15/08 FIX v5] Compteur MANIFOLD-RAW — declare ICI (avant logRawManifoldCheck
// qui l'incremente) plutot qu'a cote de gRepairedCount (bien plus bas dans le
// fichier, apres logRawManifoldCheck). Lu par le suffixe de la barre
// TESSELLATION, cf. son commentaire pres de gRepairedCount.
static std::atomic<int> gManifoldIssueCount{0}; // reset par requete dans processStepBuffer

// ─────────────────────────────────────────────────────────────────────────
// Structures internes
// ─────────────────────────────────────────────────────────────────────────
struct MeshData {
    std::string name;
    bool hasColor = false;
    float r = 0, g = 0, b = 0;
    std::vector<float> positions;   // x,y,z interleaved
    std::vector<uint32_t> indices;
    // [27/08] Couleur PAR FACE — miroir exact de DiffuseColor de FreeCAD
    // (ViewProviderPartExt) : une entree par face topologique, dans l'ordre du
    // TopExp_Explorer, chacune pointant sa plage contigue du buffer d'index.
    //
    // Convention identique a FreeCAD : le tableau est VIDE quand le solide est
    // monochrome (equivalent d'un DiffuseColor a une seule entree), et de
    // longueur nbFaces des qu'il porte au moins deux couleurs distinctes — y
    // compris pour les faces non stylees, qui recoivent la couleur du solide.
    //
    // On garde l'identite des faces plutot que de fusionner par couleur : c'est
    // ce qui permettra de selectionner et recolorer UNE face. La fusion en
    // appels de dessin se fait cote client, a l'affichage, ou elle est gratuite
    // et reversible.
    struct FaceRange { float r, g, b; uint32_t start, count; };
    std::vector<FaceRange> faces;
};

// [27/08] Couleur resolue d'UNE face, et carte face -> couleur d'un solide.
// Cle = pointeur TShape de la face : stable a travers Moved() (qui ne change que
// la Location) et a travers l'eclatement en sous-solides, donc utilisable depuis
// la phase B parallele alors que la carte est construite en phase A, seule phase
// autorisee a toucher le document XCAF. Une face reparee par ShapeFix recoit un
// nouveau TShape : elle sort simplement de la carte et retombe sur la couleur du
// solide — degradation propre, jamais d'erreur.
struct FaceRGB { float r, g, b; };
typedef std::unordered_map<const void*, FaceRGB> FaceColorMap;

// [10/08] Diagnostic manifold sur le maillage BRUT sorti d'OCCT — AVANT toute
// reparation cote client (sewing/gap-fill/cap, qui vit dans step-import.js,
// pas ici). Repond a une question qu'on ne pouvait pas trancher jusqu'ici :
// le trou existe-t-il DEJA dans ce que MEDUSA envoie, ou apparait-il plus
// tard dans le pipeline navigateur ? Meme principe que les tests de
// hollowbox de ce soir : chaque arete = paire de sommets, compte les
// triangles qui la referencent — 2 = watertight, != 2 = arete nue/sur-valencee.
static void logRawManifoldCheck(const MeshData& md) {
    if (md.indices.size() < 3) return;
    std::unordered_map<uint64_t, int> edgeCount;
    edgeCount.reserve(md.indices.size());
    auto edgeKey = [](uint32_t a, uint32_t b) -> uint64_t {
        if (a > b) std::swap(a, b);
        return ((uint64_t)a << 32) | (uint64_t)b;
    };
    for (size_t t = 0; t + 2 < md.indices.size(); t += 3) {
        uint32_t i0 = md.indices[t], i1 = md.indices[t+1], i2 = md.indices[t+2];
        edgeCount[edgeKey(i0,i1)]++;
        edgeCount[edgeKey(i1,i2)]++;
        edgeCount[edgeKey(i2,i0)]++;
    }
    int naked = 0, overValenced = 0;
    for (const auto& kv : edgeCount) {
        if (kv.second == 1) naked++;
        else if (kv.second > 2) overValenced++;
    }
    if (naked > 0 || overValenced > 0) {
        gManifoldIssueCount++; // [15/08 FIX v5] lu par le suffixe de la barre TESSELLATION
        std::lock_guard<std::mutex> lk(gConsoleMutex); // [15/08] atteignable depuis un thread de tessellation parallèle
        // [15/08 FIX v4] fichier uniquement — la barre TESSELLATION reste
        // seule sur la console (cf. logFileOnly), le detail complet reste
        // dans medusa.log comme avant.
        std::ostringstream oss;
        oss << "[MANIFOLD-RAW] \"" << md.name.substr(0,40) << "\" ALREADY has holes as it leaves OCCT (before any browser-side repair) : "
            << naked << " naked edge(s), " << overValenced << " over-valenced edge(s), "
            << (md.indices.size()/3) << " triangle(s)\n";
        logFileOnly(oss.str());
    }
}

static std::string extendedStringToUtf8(const TCollection_ExtendedString& s) {
    char buf[4096];
    Standard_PCharacter p = buf;
    // ToUTF8CString tronque proprement au-delà de la capacité fournie ; les noms
    // de pièces STEP dépassent rarement quelques dizaines de caractères.
    s.ToUTF8CString(p);
    return std::string(buf);
}

// Tessellise une shape déjà chargée et pousse le résultat dans `out` (un mesh par shape).
// Tessellation façon occt-import-js (référence de compatibilité NASSCAD) :
// linearDeflection = ratio 0.001 × taille moyenne bbox de la shape racine,
// plancher 1 mm, angularDeflection 0.5 rad — appliquée UNE fois par racine
// (les instances répétées partagent leur TShape donc leur maillage : ne pas
// re-tesselliser par solide, c'est du calcul perdu et un compte différent).
static double rootDeflectionLikeOcctImportJs(const TopoDS_Shape& rootShape) {
    Bnd_Box bb;
    BRepBndLib::Add(rootShape, bb, false);
    double linDefl = 1.0; // plancher 1 mm (comportement occt-import-js)
    if (!bb.IsVoid()) {
        Standard_Real x0,y0,z0,x1,y1,z1;
        bb.Get(x0,y0,z0,x1,y1,z1);
        double avgSize = ((x1-x0)+(y1-y0)+(z1-z0)) / 3.0;
        double d = avgSize * 0.001;
        if (d > Precision::Confusion()) linDefl = d;
    }
    return linDefl;
}
// Application PAR SOLIDE (pas par racine) : meme deflection donc meme compte de
// triangles que le kador, mais ~2x plus rapide ici — les TShapes partages ne sont
// mailles qu'une fois de toute facon (cache Poly_Triangulation), et la passe
// unique sur la racine s'est revelee structurellement plus lente (26-28s vs 14s,
// mesure 2 runs). Compat occt-import-js = deflection identique, pas le decoupage
// interne des appels BRepMesh.
static double gRootDeflection = 1.0;
static double gDeflectionOverride = -1.0; // <=0 : auto (ratio bbox) ; >0 : force cette valeur
// ─── Réparation B-Rep ciblée (état de l'art : réparer AVANT tessellation) ───
// Détection rapide : arêtes libres (free bounds) = shells ouverts = futur
// non-manifold garanti côté mesh. Seules les pièces détectées ouvertes passent
// par ShapeFix_Shape (coûteux) — les saines (99%+) ne paient rien. C'est ce que
// Fusion/SolidWorks font en silence à l'import ; le gap-fill mesh côté NASSCAD
// reste en filet final pour ce que même ShapeFix ne recoud pas.
// [15/08] atomic : repairIfOpen est desormais appele depuis un pool de
// threads (tessellation parallele, cf. plus bas) — un int& simple ne
// survivrait pas a des increments concurrents (perte d'increments garantie).
static std::atomic<int> gRepairedCount{0}; // reset par requete dans processStepBuffer
// [15/08 FIX v5] Compteur REPAIR (reparation partielle) — meme esprit que
// gRepairedCount juste au-dessus. gManifoldIssueCount (meme famille, pour
// MANIFOLD-RAW) est declare plus haut, avant logRawManifoldCheck qui en a
// besoin. Aucun des deux ne s'affiche plus en clair sur la console
// (logFileOnly, cf. plus haut) pour ne pas interrompre la barre
// TESSELLATION, mais Nass veut quand meme un signe de vie visible pour ces
// deux evenements — pas une 2e barre a part (elle se battrait avec
// TESSELLATION pour la meme ligne, meme piege que la 1ere tentative
// RESOLUTION), mais un compteur greffe DANS le suffixe de la barre
// TESSELLATION deja existante : visible en direct, jamais de ligne en plus.
static std::atomic<int> gPartialRepairCount{0}; // reset par requete dans processStepBuffer
static bool hasOpenEdges(const TopoDS_Shape& s) {
    ShapeAnalysis_FreeBounds fb(s);
    const TopoDS_Compound& open = fb.GetOpenWires();
    if (open.IsNull()) return false;
    TopoDS_Iterator it(open);
    return it.More(); // au moins un wire ouvert
}
static TopoDS_Shape repairIfOpen(const TopoDS_Shape& part, const std::string& name, std::atomic<int>& repairedCount) {
    try {
        if (!hasOpenEdges(part)) return part;
        ShapeFix_Shape fixer(part);
        fixer.Perform();
        TopoDS_Shape fixed = fixer.Shape();
        if (!fixed.IsNull() && !hasOpenEdges(fixed)) {
            repairedCount++;
            std::lock_guard<std::mutex> lk(gConsoleMutex); // [15/08] atteignable depuis un thread de tessellation parallèle
            // [15/08 FIX v4] fichier uniquement — meme raison que MANIFOLD-RAW,
            // ne doit pas interrompre la barre TESSELLATION en console.
            logFileOnly("  REPAIR       [ok] \"" + name.substr(0,40) + "\" - shell re-sewn (B-Rep)\n");
            return fixed;
        }
        {
            gPartialRepairCount++; // [15/08 FIX v5] lu par le suffixe de la barre TESSELLATION
            std::lock_guard<std::mutex> lk(gConsoleMutex);
            logFileOnly("  REPAIR       [partial] \"" + name.substr(0,40) + "\" - residual free edges, NASSCAD gap-fill will take over\n");
        }
        return fixed.IsNull() ? part : fixed;
    } catch (...) {
        return part; // la reparation ne doit JAMAIS faire echouer un import
    }
}

// [10/08] Filet de securite par piece — BRepMesh_IncrementalMesh est le SEUL
// appel bloquant de ce fichier qui vit entierement DANS OCCT, hors de notre
// controle. Incident reel documente (orbiter_tool 53/59) + reproduit ce soir
// (Orbiter-Extruder, 5 min sans le moindre mouvement) : confirme par test
// empirique de Nass, PAS lie a l'adaptive tessellation (mecanisme JS cote
// client, pour les primitives parametriques — architecture totalement
// separee du pipeline STEP/OCCT cote serveur). Sur une geometrie
// pathologique (courbe quasi-degeneree, NURBS mal parametree), le mesher
// OCCT peut s'eterniser ou ne jamais converger, sans callback de progression
// expose pour le detecter de l'exterieur.
//
// Strategie : timeout par piece (thread detache + wait_for), repli sur une
// deflexion 20x plus grossiere (donc rapide par construction — bien moins de
// triangles a produire) plutot que bloquer tout l'import. Le thread original
// continue en arriere-plan (OCCT n'expose pas d'annulation mi-calcul,
// le tuer de force risquerait de corrompre son etat interne) — mais il ne
// bloque plus l'import, et son resultat (s'il finit un jour) sera
// simplement ignore par le destructeur du thread detache.
//
// [15/08] Ce garde-fou par piece coute un std::thread OS a CHAQUE appel, y
// compris pour les pieces qui tessellisent en 2 ms — non-optimal en theorie,
// volontairement pas retouche ici : (1) une fois la boucle appelante
// parallelisee (voir parallelForIndices plus bas), une piece pathologique ne
// bloque plus QU'UN worker parmi N au lieu de tout l'import — le "blast
// radius" du probleme historique (orbiter_tool 53/59, cf. plus haut) est deja
// bien reduit par la parallelisation elle-meme ; (2) le cout de creation d'un
// thread (~10-50us sous Linux) est negligeable face aux temps de
// tessellation reels (ms a secondes par piece) — remplacer ce mecanisme par
// un pool de watchdogs partages ajouterait de la complexite (annulation,
// cycle de vie) pour un gain marginal. A revisiter seulement si un profilage
// futur montre que la creation de threads devient mesurable.
static const int TESSELLATE_TIMEOUT_SEC = 20;
// [15/08] deflection passee EXPLICITEMENT (au lieu de lire gRootDeflection,
// une globale mutable) — necessaire des que cette fonction est appelee depuis
// plusieurs threads en parallele : gRootDeflection etait ecrite par leaf AVANT
// chaque appel dans l'ancienne boucle sequentielle, ce qui n'a plus de sens
// (et serait une course) une fois N pieces traitees simultanement. Chaque
// appelant precalcule desormais sa propre deflection (celle de SA racine) en
// phase sequentielle et la transmet ici par valeur — plus aucun etat partage
// mutable lu pendant la phase parallele (gDeflectionOverride reste global
// mais n'est plus ecrit apres le debut de la requete : lecture concurrente
// sans risque).
static void tessellateShape(const TopoDS_Shape& shape, double deflection) {
    double d = (gDeflectionOverride > 0) ? gDeflectionOverride : deflection;
    auto attempt = [&shape](double deflection) {
        BRepMesh_IncrementalMesh mesher(shape, deflection, Standard_False, 0.5, Standard_True);
    };
    std::packaged_task<void(double)> task(attempt);
    std::future<void> fut = task.get_future();
    std::thread worker(std::move(task), d);
    if (fut.wait_for(std::chrono::seconds(TESSELLATE_TIMEOUT_SEC)) == std::future_status::timeout) {
        {
            std::lock_guard<std::mutex> lk(gConsoleMutex); // [15/08] atteignable depuis un thread de tessellation parallèle
            std::cerr << "[WARN] Tessellation timeout (" << TESSELLATE_TIMEOUT_SEC
                       << "s) on this body — falling back to coarser deflection ("
                       << d << " -> " << (d * 20.0) << ").\n";
        }
        worker.detach(); // continue en arriere-plan, jamais rejoint — resultat ignore
        attempt(d * 20.0); // repli synchrone, direct : deflexion grossiere = rapide par nature
    } else {
        worker.join();
    }
}

// [PERF 18/08] reserve() par face + comptage de faces fusionne dans l'unique
// passage TopExp_Explorer(FACE) qui existait deja ici. Deux gains independants :
//  (1) reserve(taille_actuelle + nbNodes*3 / nbTris*3) AVANT de remplir CETTE
//      face — sans ca, positions/indices grandissent par la croissance geometrique
//      par defaut de std::vector, ce qui, pour une piece a plusieurs grosses faces
//      (NURBS finement tessellee), declenche plusieurs reallocations + recopies en
//      cascade au lieu de zero ; reserve() ne coute rien quand la capacite suffit
//      deja (juste une comparaison), donc aucun cout ajoute dans le cas normal.
//  (2) la fonction retourne desormais le nombre de faces topologiques rencontrees
//      (meme TopAbs_FACE, meme shape, meme ordre que l'ancienne boucle de comptage
//      separee qu'appelaient les deux sites d'appel juste apres, dans
//      processStepBuffer) — les deux appelants n'ont donc plus besoin de
//      reparcourir toute la topologie de la piece une seconde fois rien que pour
//      compter ses faces ; meme valeur obtenue, une seule traversee au lieu de deux.
// ─────────────────────────────────────────────────────────────────────────
// [26/08] occtColorToSRGB — SEUL point de sortie d'une Quantity_Color vers le
// reste du pipeline (NSTP, log [COLOR], --decode-colors). Ne jamais rappeler
// Red()/Green()/Blue() directement ailleurs dans ce fichier.
//
// Depuis OCCT 7.5, Quantity_Color stocke ses composantes en RGB LINEAIRE, et
// STEPCAFControl_Reader convertit les COLOUR_RGB du fichier (interpretes en
// sRGB) vers ce lineaire pendant Transfer(). Red()/Green()/Blue() rendent donc
// du lineaire, PAS les valeurs ecrites dans le fichier.
//
// Verifie empiriquement (OCCT 7.7, aller-retour STEP complet) :
//   fichier   COLOUR_RGB('',1.,0.4,0.)                    -> #FF6600
//   .Red()    (1.000000, 0.132868, 0.000000)              -> #FF2200   FAUX
//   Values()  (1.000000, 0.400000, 0.000000) TOC_sRGB     -> #FF6600   JUSTE
// Ecart mesure a l'affichage : -27% a -91% de luminance selon la teinte, parce
// que Three.js traite ce qu'il recoit comme du sRGB (r128 : pas de
// ColorManagement, outputEncoding = LinearEncoding — meme comportement naif
// que Coin3D cote FreeCAD). Le moteur de rendu n'est pas en cause : c'est bien
// l'accesseur utilise ici qui l'etait.
//
// Meme choix que FreeCAD, qui declare explicitement
// Mod/Import/App/ImportOCAF2.cpp : #define OCC_COLOR_SPACE Quantity_TOC_sRGB.
// L'alignement se fait donc d'un coup sur FreeCAD, Fusion et CAD Assistant.
//
// NE PAS remplacer par un gamma maison (pow 1/2.2) : la courbe sRGB a un
// segment lineaire sous 0.0031308, une approximation gamma decale les tons
// sombres — precisement la zone ou l'ecart etait le plus visible.
static void occtColorToSRGB(const Quantity_Color& c, double& r, double& g, double& b) {
    c.Values(r, g, b, Quantity_TOC_sRGB);
}

static int extractInto(const TopoDS_Shape& shape, const std::string& name,
                            std::optional<Quantity_Color> color,
                            std::vector<MeshData>& out,
                            const FaceColorMap* faceColors = nullptr) {
    MeshData md;
    md.name = name;
    if (color) {
        // [26/08] sRGB et non Red()/Green()/Blue() (lineaire) — cf. occtColorToSRGB.
        double sr, sg, sb;
        occtColorToSRGB(*color, sr, sg, sb);
        md.hasColor = true; md.r = (float)sr; md.g = (float)sg; md.b = (float)sb;
    }

    // [27/08] Une "plage" = les index produits par UNE face, avec sa couleur.
    // Enregistrees dans l'ordre des faces, puis regroupees par couleur en fin de
    // fonction. Rien n'est alloue quand faceColors est nul (solide monochrome).
    struct Run { uint32_t key; float r, g, b; uint32_t start, count; };
    std::vector<Run> runs;
    auto colorKey = [](float r, float g, float b) -> uint32_t {
        // Quantification 8 bits : c'est de toute facon la precision d'affichage,
        // et ca evite de creer deux groupes pour deux flottants qui ne different
        // qu'au-dela du millieme.
        return ((uint32_t)std::lround(r * 255.0f) << 16)
             | ((uint32_t)std::lround(g * 255.0f) << 8)
             |  (uint32_t)std::lround(b * 255.0f);
    };

    uint32_t vertexOffset = 0;
    int faceCount = 0;
    for (TopExp_Explorer faceExp(shape, TopAbs_FACE); faceExp.More(); faceExp.Next()) {
        faceCount++;
        TopoDS_Face face = TopoDS::Face(faceExp.Current());
        TopLoc_Location loc;
        Handle(Poly_Triangulation) tri = BRep_Tool::Triangulation(face, loc);
        if (tri.IsNull()) continue;

        const gp_Trsf& trsf = loc.Transformation();
        Standard_Integer nbNodes = tri->NbNodes();
        Standard_Integer nbTris = tri->NbTriangles();
        md.positions.reserve(md.positions.size() + (size_t)nbNodes * 3);
        md.indices.reserve(md.indices.size() + (size_t)nbTris * 3);
        for (Standard_Integer i = 1; i <= nbNodes; i++) {
            gp_Pnt p = tri->Node(i);
            p.Transform(trsf);
            md.positions.push_back((float)p.X());
            md.positions.push_back((float)p.Y());
            md.positions.push_back((float)p.Z());
        }
        bool reversed = (face.Orientation() == TopAbs_REVERSED);
        const uint32_t runStart = (uint32_t)md.indices.size();
        for (Standard_Integer i = 1; i <= nbTris; i++) {
            Standard_Integer n1, n2, n3;
            tri->Triangle(i).Get(n1, n2, n3);
            if (reversed) std::swap(n2, n3);
            md.indices.push_back(vertexOffset + n1 - 1);
            md.indices.push_back(vertexOffset + n2 - 1);
            md.indices.push_back(vertexOffset + n3 - 1);
        }
        vertexOffset += (uint32_t)nbNodes;

        if (faceColors) {
            // Couleur de CETTE face si le fichier en pose une, sinon celle du
            // solide — une face non stylee dans un solide multicolore rejoint
            // naturellement le groupe de la couleur dominante.
            float fr = md.r, fg = md.g, fb = md.b;
            auto it = faceColors->find(faceExp.Current().TShape().get());
            if (it != faceColors->end()) { fr = it->second.r; fg = it->second.g; fb = it->second.b; }
            const uint32_t cnt = (uint32_t)md.indices.size() - runStart;
            if (cnt) runs.push_back(Run{ colorKey(fr, fg, fb), fr, fg, fb, runStart, cnt });
        }
    }

    // [27/08] Les plages sont deja dans l'ordre des faces : AUCUN reordonnancement
    // du buffer d'index. C'est la difference avec un regroupement par couleur, et
    // c'est ce qui preserve l'identite des faces jusqu'au client — plus une
    // propriete precieuse : l'ordre des triangles sortant d'OCCT reste intact, donc
    // weldMeshLocal (remap de sommets) et smoothMeshBFSLocal (out.idx[f*3+vi], face
    // par face) le preservent aussi. Seule l'union Manifold le detruirait, et le
    // client la saute pour les corps porteurs de couleurs par face.
    //
    // Le tableau n'est rempli que s'il y a au moins DEUX couleurs distinctes :
    // un solide monochrome garde son unique champ "color", exactement comme
    // FreeCAD reduit DiffuseColor a une seule entree dans ce cas.
    if (runs.size() > 1) {
        bool multi = false;
        for (size_t i = 1; i < runs.size() && !multi; i++)
            if (runs[i].key != runs[0].key) multi = true;
        if (multi) {
            md.faces.reserve(runs.size());
            for (const Run& rn : runs)
                md.faces.push_back(MeshData::FaceRange{ rn.r, rn.g, rn.b, rn.start, rn.count });
        }
    }

    if (!md.positions.empty() && !md.indices.empty()) out.push_back(std::move(md));
    return faceCount;
}

// JSON minimal (échappement suffisant pour des noms de pièces STEP — pas de contrôle
// arbitraire attendu ici, entrée = notre propre pipeline OCCT, pas du texte utilisateur libre).
static std::string jsonEscape(const std::string& s) {
    std::string o;
    o.reserve(s.size() + 8);
    for (char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) { /* skip control chars */ }
                else o += c;
        }
    }
    return o;
}

// Barre de progression sur PLACE : retour chariot (\r) qui reecrit la meme
// ligne — technique "console classique" (celle demandee explicitement par
// Nass, cf. capture d'exemple [████...] 67%), PAS d'ANSI (ESC[1A/ESC[2K).
// [15/08 FIX v2] Remplace l'ancienne version a base d'echappements ANSI :
// ceux-ci supposent ENABLE_VIRTUAL_TERMINAL_PROCESSING actif cote console,
// jamais active ici (ce binaire est un ELF WSL, la console Windows n'est
// qu'un relais — impossible d'appeler l'API Win32 SetConsoleMode depuis ce
// process) ; en conhost.exe classique (fenetre wsl.exe, PAS Windows Terminal
// — cf. capture d'ecran de Nass) rien ne garantissait que ces sequences
// soient interpretees. \r est un controle bien plus ancien et
// universellement supporte, meme par un relais non-VT100.
// Chaque frame se termine par \r (PAS \n) et flush explicitement : la ligne
// reste "ouverte" (gBarActive=true) jusqu'a ce que barPhaseStart() la valide
// avec un vrai saut de ligne, OU qu'un log normal s'intercale — dans ce cas
// TeeStreambuf::flushBuffer ferme desormais automatiquement la ligne AVANT de
// laisser passer ce log (voir plus bas), au lieu de l'ancienne suppression
// caractere par caractere qui ne laissait passer que le \n final de chaque
// ligne supprimee -> defilement de lignes vides (la cause du bug signale par
// Nass : "tu as casse l'affichage de la console").
// [15/08 FIX v7] Largeur reduite de 40 -> 24 : libere de la place pour le
// texte (nom de piece + compteurs REPAIR/MANIFOLD-RAW) dans le budget de
// longueur de ligne desormais impose par drawBarLine (cf. son commentaire).
// [28/08] Blocs pleins facon barre de progression DOS : U+2588 FULL BLOCK pour
// le rempli, U+2591 LIGHT SHADE pour le vide (les deux etaient deja la en
// CP437 : 219 et 176 — c'est litteralement la barre des installeurs DOS).
// La console est passee en CP_UTF8 au demarrage (SetConsoleOutputCP), donc
// l'UTF-8 sort tel quel ; il faut juste une police TrueType (Consolas, Lucida),
// ce qui est le defaut de cmd.exe et de Windows Terminal depuis longtemps.
//
// ATTENTION, PIEGE : ces deux caracteres font 3 OCTETS chacun en UTF-8. Tout le
// calcul de longueur de drawBarLine (cap a 78, padding d'effacement) etait en
// octets ; laisse tel quel, une barre de 24 blocs compterait pour 72 et se
// ferait tronquer immediatement. D'ou consoleCols/consoleTruncate juste en
// dessous, et gLastBarLen qui compte desormais des COLONNES, pas des octets.
static const char* BAR_FILL  = "\xE2\x96\x88"; // U+2588 FULL BLOCK
static const char* BAR_EMPTY = "\xE2\x96\x91"; // U+2591 LIGHT SHADE
static std::string renderBar(double frac, int width = 24) {
    if (frac < 0) frac = 0;
    if (frac > 1) frac = 1;
    int filled = (int)(frac * width + 0.5);
    std::string bar = "[";
    for (int i = 0; i < width; i++) bar += (i < filled) ? BAR_FILL : BAR_EMPTY;
    bar += "]";
    return bar;
}

// Largeur d'affichage en colonnes = nombre de points de code UTF-8. On compte
// les octets qui ne sont PAS des continuations (10xxxxxx). Suffisant ici :
// tout ce qui transite par la barre est en largeur 1 (ASCII + blocs U+258x).
static size_t consoleCols(const std::string& s) {
    size_t n = 0;
    for (unsigned char c : s) if ((c & 0xC0) != 0x80) n++;
    return n;
}
// Troncature a maxCols COLONNES, jamais au milieu d'une sequence UTF-8 — un
// substr() brut sur des octets couperait un bloc en deux et enverrait un octet
// isole a la console, qui l'afficherait en caractere de remplacement.
static std::string consoleTruncate(const std::string& s, size_t maxCols) {
    size_t cols = 0, i = 0;
    while (i < s.size()) {
        size_t start = i;
        i++;
        while (i < s.size() && ((unsigned char)s[i] & 0xC0) == 0x80) i++;
        if (cols + 1 > maxCols) return s.substr(0, start);
        cols++;
    }
    return s;
}
// [14/08] gBarActive — vrai tant qu'une frame de barre est "ouverte" sur la
// console (dernier octet envoye = \r, jamais encore valide par un \n). Mis a
// jour UNIQUEMENT par TeeStreambuf::flushBuffer (plus bas), qui est la seule
// autorite sur ce qui part reellement vers la console.
static bool gBarActive = false;
static size_t gLastBarLen = 0; // largeur (EN COLONNES, pas en octets) de la derniere frame — completee au blanc pour effacer le reliquat (ex: nom de piece plus court que le precedent)
static void drawBarLine(const std::string& label, double frac, const std::string& suffix) {
    std::string line = "  " + label + " " + renderBar(frac) + " " + suffix;
    // [15/08 FIX v7] Cap dur de longueur. Une ligne plus longue que la
    // largeur du terminal force un retour a la ligne PHYSIQUE cote
    // affichage ; le \r suivant ne revient alors qu'au debut de CETTE
    // ligne physique (la 2e), pas au debut de la ligne LOGIQUE -> la barre
    // "defile" au lieu de s'ecraser sur place. Repere sur TESSELLATION des
    // que son suffixe s'est allonge (nom de piece + compteur REPAIR/
    // MANIFOLD-RAW, cf. repairManifoldSuffix) : PARSING/RESOLUTION restaient
    // courtes et s'en sortaient, TESSELLATION avec ce nouveau suffixe non.
    // Largeur de fenetre cmd.exe jamais garantie ni interrogeable de facon
    // fiable a travers le relais WSL->conhost -- plutot que parier sur une
    // largeur precise, cap volontairement prudent (80 colonnes = plus petit
    // dénominateur commun d'une fenetre console Windows) et troncature
    // propre avec "..." si depasse.
    // [28/08] Tout ce bloc compte desormais en COLONNES et non en octets — cf.
    // le commentaire de renderBar : depuis les blocs UTF-8, les deux ne sont
    // plus la meme chose. gLastBarLen suit la meme unite.
    static constexpr size_t kMaxLineLen = 78;
    size_t cols = consoleCols(line);
    if (cols > kMaxLineLen) {
        line = consoleTruncate(line, kMaxLineLen - 3) + "...";
        cols = consoleCols(line);
    }
    if (cols < gLastBarLen) { line.append(gLastBarLen - cols, ' '); cols = gLastBarLen; }
    gLastBarLen = cols;
    // [15/08 FIX v3] Le \r DOIT partir dans le MEME appel << que le reste du
    // texte. cerr est unitbuf : chaque appel << individuel se flush a lui
    // tout seul (le sentry se detruit — donc flush — a la fin de CET appel,
    // pas a la fin de toute l'expression chainee). "\r" << line << flush
    // envoyait donc le \r seul comme UN premier paquet, puis line comme un
    // SECOND paquet ne commencant plus par \r -> TeeStreambuf::flushBuffer
    // ne le reconnaissait plus comme une frame de barre (isBarFrame=false
    // pour ce second paquet), le traitait comme un log normal : horodatage
    // ajoute + \n de fermeture injecte avant, donc barre qui defile a
    // chaque frame au lieu de s'ecraser sur place — exactement le symptome
    // observe par Nass. Un seul << avec le \r deja concatene au texte =
    // un seul appel = un seul flush = un seul paquet reconnu par isBarFrame.
    std::cerr << ("\r" + line) << std::flush;
}
static void barPhaseStart() {
    if (gBarActive) std::cerr << "\n" << std::flush; // valide la derniere frame de la phase precedente sur SA propre ligne
    gLastBarLen = 0; // nouvelle phase = pas de reliquat a effacer sur la premiere frame
}

// [15/08 FIX v4] logFileOnly — meme demande que pour PARSING/TESSELLATION,
// etendue a COLOR/REPAIR/MANIFOLD-RAW : ces logs partent UN PAR PIECE
// (potentiellement des milliers), ce qui noyait la console de defilement
// exactement comme le faisait TESSELLATION avant d'avoir sa barre. Plutot
// que d'essayer de faire cohabiter un flot de texte ligne-par-ligne ET une
// barre sur la meme portion de console (les deux se marchent dessus quoi
// qu'on fasse — une nouvelle ligne de texte ferme forcement la frame de
// barre en cours), le detail complet continue d'aller VERS LE FICHIER
// (medusa.log garde tout, rien n'est perdu), et la CONSOLE ne voit plus
// qu'une barre de progression pour ces logs — comme PARSING/TESSELLATION.
//
// Marqueur '\x01' (SOH, jamais present dans du texte normal) en tete du
// message : TeeStreambuf::flushBuffer le reconnait et route TOUT le
// contenu vers le fichier uniquement, sans jamais toucher gBarActive ni la
// console — la barre de la phase en cours continue de s'ecraser sur place,
// totalement indifferente a ces logs.
//
// IMPORTANT (meme piege que drawBarLine, FIX v3) : le message DOIT arriver
// en un seul appel << (une seule chaine deja assemblee), jamais en
// plusieurs << chaines — cerr etant unitbuf, des << separes partiraient en
// paquets separes et seul le premier porterait le marqueur '\x01'.
static void logFileOnly(const std::string& msg) {
    std::cerr << ("\x01" + msg) << std::flush;
}

// [15/08 FIX v5] Petit resume REPAIR/MANIFOLD-RAW greffe dans le suffixe de
// la barre TESSELLATION (cf. les commentaires pres des 3 compteurs) — vide
// tant qu'aucun des deux ne s'est produit, pour ne pas polluer le cas normal
// (99%+ des pieces n'ont ni l'un ni l'autre).
// [15/08 FIX v7] Format compacte ("R:" / "M:" plutot que "N reparee(s)" /
// "N non-manifold") — le format verbeux d'origine, cumule a un nom de piece,
// depassait la largeur de ligne desormais imposee par drawBarLine et faisait
// a nouveau defiler la barre (cf. son commentaire).
static std::string repairManifoldSuffix() {
    int rep = gRepairedCount.load() + gPartialRepairCount.load();
    int mf = gManifoldIssueCount.load();
    std::string s;
    if (rep > 0) s += " R:" + std::to_string(rep);
    if (mf > 0) s += " M:" + std::to_string(mf);
    return s;
}

// Construit le buffer NSTP v1 complet à partir des meshes extraits.
static std::string gMetaJson; // rempli par processStepBuffer, consomme ici (mono-thread)
static std::vector<uint8_t> encodeNSTP(const std::vector<MeshData>& meshes, double totalMs) {
    barPhaseStart(); // la barre STEP->NSTP demarre sur SA propre ligne, sous celle de tessellation
    std::ostringstream json;
    json << "{\"success\":true,\"source\":\"nasscad-medusa-engine/3.1\","
         << (gMetaJson.empty() ? "" : ("\"metadata\":" + gMetaJson + ","))
         << "\"meshCount\":" << meshes.size() << ",\"tessMs\":" << totalMs << ",\"meshes\":[";

    uint32_t binLen = 0;
    std::vector<std::pair<const float*, size_t>> posRefs;   // (ptr, count floats)
    std::vector<std::pair<const uint32_t*, size_t>> idxRefs; // (ptr, count uint32)

    for (size_t i = 0; i < meshes.size(); i++) {
        const auto& m = meshes[i];
        uint32_t posOffset = binLen;
        uint32_t posBytes = (uint32_t)(m.positions.size() * sizeof(float));
        binLen += posBytes;
        uint32_t idxOffset = binLen;
        uint32_t idxBytes = (uint32_t)(m.indices.size() * sizeof(uint32_t));
        binLen += idxBytes;

        if (i) json << ",";
        json << "{\"name\":\"" << jsonEscape(m.name) << "\",";
        if (m.hasColor) {
            // step-import.js applique la couleur via mColor.r/.g/.b (objet, cf. ligne ~2244
            // du host : "if(mColor && mColor.r !== undefined)") — PAS un tableau [r,g,b].
            // Format aligné sur la sortie native occt-import-js, pas sur l'ancien _nstpEncode
            // JS (cache IDB) qui encodait en tableau — incohérence pré-existante côté cache,
            // sans impact ici puisqu'on écrit notre propre encodeur.
            json << "\"color\":{\"r\":" << m.r << ",\"g\":" << m.g << ",\"b\":" << m.b << "},";
        } else {
            json << "\"color\":null,";
        }
        // [27/08] Champ ADDITIF, absent quand le solide est monochrome : un client
        // anterieur a cette version le voit exactement comme avant. Une entree par
        // face topologique, dans l'ordre du TopExp_Explorer — l'indice dans ce
        // tableau EST le numero de face, ce qui rendra la selection par face
        // possible. Forme compacte [r,g,b,start,count] plutot qu'un objet : sur un
        // corps a quelques milliers de faces, la difference de taille JSON est
        // d'un facteur deux.
        if (!m.faces.empty()) {
            json << "\"faces\":[";
            for (size_t g = 0; g < m.faces.size(); g++) {
                if (g) json << ",";
                json << "[" << m.faces[g].r << "," << m.faces[g].g << "," << m.faces[g].b
                     << "," << m.faces[g].start << "," << m.faces[g].count << "]";
            }
            json << "],";
        }
        json << "\"posOffset\":" << posOffset << ",\"posCount\":" << m.positions.size()
             << ",\"idxOffset\":" << idxOffset << ",\"idxCount\":" << m.indices.size() << "}";

        {
            int pct = (int)(100.0 * (i + 1) / meshes.size());
            int prevPct = (int)(100.0 * i / meshes.size());
            if (pct != prevPct || i + 1 == meshes.size()) {
                drawBarLine("STEP -> NSTP",
                    (double)(i + 1) / meshes.size(),
                    std::to_string(pct) + "%  (" + std::to_string(i + 1) + "/" + std::to_string(meshes.size()) + ")");
            }
        }

        posRefs.push_back({ m.positions.data(), m.positions.size() });
        idxRefs.push_back({ m.indices.data(), m.indices.size() });
    }
    json << "]}";

    std::string jsonStr = json.str();
    // Padding à un multiple de 4 avec des espaces (0x20), comme l'encodeur JS de référence.
    size_t pad = (4 - (jsonStr.size() % 4)) % 4;
    jsonStr.append(pad, ' ');

    uint32_t jsonLen = (uint32_t)jsonStr.size();
    std::vector<uint8_t> out(16 + jsonLen + binLen);
    out[0] = 'N'; out[1] = 'S'; out[2] = 'T'; out[3] = 'P';
    auto writeU32LE = [&](size_t off, uint32_t v) {
        out[off+0] = (uint8_t)(v & 0xFF);
        out[off+1] = (uint8_t)((v >> 8) & 0xFF);
        out[off+2] = (uint8_t)((v >> 16) & 0xFF);
        out[off+3] = (uint8_t)((v >> 24) & 0xFF);
    };
    writeU32LE(4, 1);
    writeU32LE(8, jsonLen);
    writeU32LE(12, binLen);
    std::memcpy(out.data() + 16, jsonStr.data(), jsonLen);

    size_t off = 16 + jsonLen;
    for (size_t i = 0; i < meshes.size(); i++) {
        std::memcpy(out.data() + off, posRefs[i].first, posRefs[i].second * sizeof(float));
        off += posRefs[i].second * sizeof(float);
        std::memcpy(out.data() + off, idxRefs[i].first, idxRefs[i].second * sizeof(uint32_t));
        off += idxRefs[i].second * sizeof(uint32_t);
    }

    return out;
}

// ─────────────────────────────────────────────────────────────────────────
// Récursion dans l'arbre d'assemblage XCAF : GetFreeShapes() ne renvoie que
// les racines (ex: 1 seul assemblage englobant, jamais les 198 composants
// feuilles). Il faut descendre à travers assemblages/sous-assemblages en
// composant les TopLoc_Location à chaque niveau (chaque instance porte SA
// propre position relative à son parent immédiat, pas la position globale).
// ─────────────────────────────────────────────────────────────────────────
static Handle(XCAFDoc_ColorTool) gColorTool;
// [13/08] gShapeTool ajoute — necessaire pour FindSubShape (methode d'INSTANCE,
// pas statique, verifie dans le vrai header XCAFDoc_ShapeTool.hxx avant d'ecrire
// cette ligne). Sert a resoudre la couleur d'un sous-solide par LABEL explicite
// plutot que par hash de forme (GetColor(TopoDS_Shape) direct) — ce dernier
// s'est avere retourner la mauvaise couleur pour 620/1297 solides sur
// Scania-Engine-V8-XT-Turbo.step, diagnostique via colPath dans cette meme
// session. Meme fragilite documentee qu'ailleurs (recherche du 13/08 sur
// GetColor casse depuis 7.4.0) — FindSubShape+label evite le hash, comme
// resolvedLabel l'evite deja au niveau du leaf entier.
//
// ══ [31/08] CORRECTION : GetColor(TopoDS_Shape) n'etait pas casse. ═══════════
//
// Le paragraphe ci-dessus reste, c'est l'historique — mais son diagnostic est
// faux, et le croire coute cher : il pousse a contourner un bug d'OCCT qui
// n'existe pas.
//
// Preuve, medusa.log du 31/08 (import Scania complet, 1295 corps). Les 113
// lignes [COLOR-KEPT-LEAF] disent quelle couleur l'etage sous-solide proposait
// avant d'etre ignore. Elles ne contiennent que QUATRE valeurs :
//     67 x #DDDD0D    32 x #5A6266    8 x #BEBCBA    6 x #CB9A3B
// Or la lecture directe du Part21 donne la liste des couleurs que le fichier
// pose au niveau MANIFOLD_SOLID_BREP :
//     #5A6266 (134 corps), #DDDD0D (53), #BEBCBA (38), #CB9A3B (9),
//     #CF4F00 (8), #F4F4F4 (8), #404040 (3), #5A5B5B (1)
// Les quatre valeurs proposees sont toutes, et uniquement, des couleurs de
// niveau SOLIDE. Aucune valeur aberrante, aucune couleur de face, aucune
// couleur empruntee a une autre piece. Un hash mal apparie rendrait n'importe
// quoi ; celui-ci rend exactement ce que le fichier ecrit sur le solide.
//
// Ce qu'on prenait pour une fragilite de GetColor etait donc la BONNE valeur au
// MAUVAIS NIVEAU : ce fichier (Inventor via ST-Developer) pose une couleur sur
// le solide ET des couleurs sur ses faces, et la regle OCCT veut que la face
// gagne (XCAFPrs::CollectStyleSettings : le style d'une sous-forme ecrase celui
// de son parent). C'est corrige en amont depuis le 31/08, dans decideBodyColor().
//
// FindSubShape+label reste utile et reste en place : resoudre par label plutot
// que par hash est plus direct et plus lisible. Mais ce n'est pas un
// contournement de bug, et il ne faut pas le traiter comme tel.
// ════════════════════════════════════════════════════════════════════════════
static Handle(XCAFDoc_ShapeTool) gShapeTool;
// [10/08] Filet de dernier recours par NOM — proposé par Nass après que
// l'heritage d'assemblage (v2.8) se soit revele insuffisant sur des pieces
// lourdement reparees (Orbiter-Extruder). Diagnostic : ligne ~575, la
// resolution par SOLIDE individuel ECRASE sans condition ce que
// leaf.color (v2.8) avait correctement resolu — si cette resolution par
// identite de forme echoue silencieusement sur un solide issu d'un
// remaillage/reparation lourd, l'heritage n'a jamais sa chance de s'exprimer.
// Principe : coupler par NOM plutot que par identite de forme (qui peut se
// briser apres decoupage/reparation), en dernier recours seulement — jamais
// prioritaire sur une resolution par identite reussie. Rempli au fil de
// l'eau (chaque succes alimente la table), consulte seulement a l'echec.
// Sur, meme pour des instances repetees du meme prototype (nom partage) :
// deux instances d'une meme vis M3x6 partagent presque certainement la
// meme couleur reelle, donc reutiliser celle d'une instance-soeur deja
// resolue est correct, pas une approximation hasardeuse.

// [14/08] ConsoleProgress — barre de progression PARSING dans la console
// MEDUSA, distincte de la barre TESSELLATION deja existante par ailleurs.
// Piste ouverte hier : sur un fichier de 1,3 Go (Dante.step), "reading..."
// restait affiche 12+ minutes sans aucun signe d'activite visible — impossible
// de distinguer "ca travaille encore" de "c'est bloque". API verifiee dans le
// vrai header Message_ProgressIndicator.hxx avant d'ecrire cette classe (pas
// de memoire) : Show() est pur virtuel, appele par l'algorithme lui-meme
// pendant Transfer() — throttle par instance (pas static/partage) pour ne
// pas noyer la console a chaque micro-increment.
class ConsoleProgress : public Message_ProgressIndicator {
public:
    virtual void Show(const Message_ProgressScope& theScope, const Standard_Boolean isForce) override {
        double maxV = theScope.MaxValue();
        if (maxV <= 0) return;
        double pct = (theScope.Value() / maxV) * 100.0;
        const char* nm = theScope.Name();
        std::string key = nm ? nm : "STEP";

        // [14/08 FIX v3] isForce retire de la decision — log reel (Voron
        // 2.4r2, 195 000 lignes generees) montre que meme le mute par nom
        // (v2) ne suffisait pas : OCCT appelle Show() avec isForce=true pour
        // chaque micro-completion interne, ce qui contournait le "!isForce"
        // du throttle et laissait TOUT passer. Decision desormais basee
        // uniquement sur pourcentage + nom, jamais sur ce que l'appelant
        // pretend forcer.
        //
        // [FIX AUDIT 18/08] Bug rapporte par Nass : la barre PARSING ne
        // reflete pas la vraie progression sur un gros assemblage. Cause
        // trouvee ici : theScope.Name() est REUTILISE a chaque piece/root
        // transfere(e) (pas un nom unique par piece). L'ancienne regle
        // "si le tout premier echantillon vu pour ce nom est deja >=95%,
        // blacklister ce nom EN PERMANENCE" (myMutedNames) partait d'une
        // bonne intention (ne pas dessiner un evenement deja termine, rien
        // a montrer) mais avait un effet de bord severe : si la toute
        // premiere piece rencontree se transfere quasi instantanement
        // (petite piece simple), son echantillon initial est deja >=95% ->
        // le nom de scope est mute a vie, et TOUTES les pieces suivantes
        // qui reutilisent ce meme nom — y compris des pieces bien plus
        // grosses/lentes sur un gros assemblage — n'apparaissent plus JAMAIS,
        // meme si OCCT continue a reporter une vraie progression 0->100 pour
        // chacune. Resultat : la barre semble figee/muette pendant l'essentiel
        // du travail, exactement le symptome que cette classe visait a
        // l'origine a corriger (cf. commentaire Dante.step plus haut).
        //
        // Nouveau comportement : on saute seulement l'echantillon instantane
        // (rien d'interessant a dessiner CETTE occurrence-la), sans jamais
        // blacklister le nom pour les occurrences futures — et on detecte la
        // REPRISE d'un nom (pct qui redescend sous la derniere valeur dessinee
        // = une nouvelle piece reutilise ce nom de scope depuis le debut) pour
        // ne pas laisser le throttle delta ci-dessous, calibre pour un pourcentage
        // croissant, avaler a tort le debut de cette nouvelle piece parce qu'il
        // le comparerait a l'ancienne fin (souvent 100%) de la piece precedente.
        auto itSeen = mySeenNames.find(key);
        if (itSeen == mySeenNames.end()) {
            mySeenNames.insert(key);
            if (pct >= 95.0) return; // rien a montrer cette fois — le nom reste actif pour la suite
        }

        double& lastForKey = myLastPctByName[key];
        bool isRestart = pct < lastForKey; // meme nom, nouvelle piece repartant de zero
        if (!isRestart) {
            if ((pct - lastForKey) < 2.0 && pct < 100.0) return;
            // Un 100% deja imprime pour ce nom ne se reimprime plus (lastForKey
            // deja a 100 -> diff=0, coupe par la ligne au-dessus) — seul le
            // PREMIER 100% authentique d'une progression legitime passe. Garde
            // explicite ici pour le cas d'egalite exacte.
            if (pct >= 100.0 && lastForKey >= 100.0) return;
        }
        lastForKey = pct;
        // [14/08] \r plutot que \n — reecrit la meme ligne a chaque mise a
        // jour (comme une barre de telechargement classique) plutot que d'en
        // empiler une nouvelle par appel.
        // [14/08 FIX v4] A l'epoque, un \r "nu" (v3, tantot) sans passer par
        // TeeStreambuf avait semble rester bufferise a travers le relais
        // WSL->console — remplace alors par une redraw ANSI (\x1b[1A\x1b[2K).
        // [15/08 FIX v2] Retour au \r EXPLICITEMENT demande par Nass (barre
        // "console classique") apres que l'ANSI se soit revele lui-meme non
        // fiable en conhost.exe classique (pas de ENABLE_VIRTUAL_TERMINAL_
        // PROCESSING, jamais actionnable depuis ce binaire WSL). Cette fois
        // le \r passe PAR drawBarLine -> TeeStreambuf::flushBuffer, avec un
        // std::flush explicite a chaque frame : le probleme de bufferisation
        // de 14/08 n'a jamais ete confirme venir du \r lui-meme plutot que de
        // l'absence de flush a l'epoque. Si la barre PARSING ne s'anime
        // toujours pas en direct malgre ce changement, ce sera un signal fort
        // que le relais WSL->conhost bufferise reellement tout ce qui n'est
        // pas termine par \n, independamment du \r — prochaine etape dans ce
        // cas : revenir a des lignes pleines (\n) mais throttlees, sans
        // pretention a l'ecrasement sur place.
        if (!myPhaseStarted) { barPhaseStart(); myPhaseStarted = true; }
        drawBarLine("PARSING", pct / 100.0, std::to_string((int)pct) + "%  " + key);
    }
private:
    std::unordered_map<std::string, double> myLastPctByName;
    std::unordered_set<std::string> mySeenNames;
    // [FIX AUDIT 18/08] myMutedNames (blacklist permanente par nom) supprime —
    // cf. commentaire dans Show() : cause du bug de barre figee sur gros assemblage.
    bool myPhaseStarted = false;
};

struct LeafShape {
    std::string name;
    std::optional<Quantity_Color> color;
    double deflection = 1.0; // deflection de SA racine (multi-racines : chaque racine a la sienne)
    TopoDS_Shape shape;    // repositionnée dans le repère racine (transform composé appliqué)
    TopoDS_Shape rawShape; // prototype NON déplacé — SEULE forme que le ColorTool sait
                           // retrouver (il indexe par shape+location d'origine ; Moved()
                           // casse la correspondance — vérifié empiriquement : 106/198
                           // via shape déplacée, 198/198 via prototype)
    // [27/08] Carte face -> couleur du solide, construite en phase A (seul
    // endroit ou le ColorTool est accessible), consommee en phase B par
    // extractInto. shared_ptr : une seule carte par leaf, partagee sans copie
    // par tous ses sous-solides. Nulle quand le solide est monochrome.
    std::shared_ptr<FaceColorMap> faceColors;
    TDF_Label resolvedLabel; // [13/08] label du prototype (rawShape) — necessaire pour
                              // FindSubShape en aval, resolution couleur par label plutot
                              // que par hash de forme au niveau sous-solide.
    // [31/08] Comment la couleur de CE leaf a ete obtenue (sortie de
    // decideBodyColor). Sans ce champ, le log [COLOR] n'imprimait que le chemin
    // du niveau SOUS-SOLIDE (partColPath) : quand le leaf gagne — c'est-a-dire
    // presque toujours — la ligne disait "tierA-leaf" sans jamais dire comment
    // ce leaf avait ete resolu. Consequence vecue le 31/08 : le correctif
    // "face-uniform-override" tournait et faisait son travail, mais restait
    // totalement invisible dans medusa.log, au point de faire croire qu'il ne
    // se declenchait pas. Un chemin de decision qu'on ne peut pas observer est
    // un chemin qu'on ne peut pas debugger.
    const char* colPath = "none";
};

// [31/08] Resultat du balayage des couleurs de face d'un PROTOTYPE, memorise
// pour ses instances. Voir le bloc commente dans collectLeaves pour le pourquoi
// et pour la garantie de mono-thread qui dispense de verrou.
struct FaceScan {
    std::shared_ptr<FaceColorMap> map;    // nulle si aucune face stylee
    std::optional<Quantity_Color> first;  // 1re couleur de face rencontree
    bool   uniform = true;                // toutes les faces stylees identiques
    size_t nFaces  = 0;                   // faces topologiques du prototype
    size_t nStyled = 0;                   // dont celles portant un style propre
};
static std::unordered_map<const void*, FaceScan> gFaceScanCache;

// [31/08] La decision couleur d'un corps, isolee en fonction PURE : elle ne lit
// que son balayage de faces et la couleur de solide deja resolue, ne touche a
// aucun etat global, et ne depend d'aucun objet OCCT lourd. C'est ce qui la rend
// verifiable sans document XCAF ni fichier STEP — cf. runColorSelfTestCli(),
// "--selftest-colors", qui l'exerce sur les cas limites reels du Scania.
//
// Regle implementee, celle d'OCCT (XCAFPrs::CollectStyleSettings) : le style
// d'une sous-forme ecrase celui de son parent ; la couleur du solide ne vaut que
// pour les faces qui n'ont pas la leur.
struct ColorDecision {
    std::optional<Quantity_Color> col;
    bool        useFaceMap = false;  // transmettre la carte face -> couleur
    const char* path       = "none"; // trace colPath, pour le log [COLOR]
};

static ColorDecision decideBodyColor(const FaceScan& scan,
                                     const std::optional<Quantity_Color>& labelColor,
                                     const char* labelPath) {
    ColorDecision d{ labelColor, false, labelPath };
    // Aucune couleur de face : la couleur du solide gouverne.
    if (scan.nStyled == 0) return d;
    // Toutes les faces s'accordent sur UNE couleur : elle ecrase celle du solide.
    // Un seul materiau suffit, aucun groupe a produire — donc pas de carte.
    if (scan.uniform && scan.nStyled == scan.nFaces) {
        d.path = labelColor ? "face-uniform-override" : "face-uniform";
        d.col  = scan.first;
        return d;
    }
    // Melange : plusieurs couleurs, ou faces stylees et nues cote a cote.
    // extractInto produira les groupes, les faces nues heritant du solide.
    d.useFaceMap = true;
    if (!labelColor) { d.col = scan.first; d.path = "face-first"; }
    return d;
}

static void collectLeaves(const Handle(XCAFDoc_ShapeTool)& shapeTool,
                           const Handle(XCAFDoc_ColorTool)& colorTool,
                           const TDF_Label& label,
                           const TopLoc_Location& parentLoc,
                           std::vector<LeafShape>& out,
                           int depth) {
    if (depth > 64) return; // garde-fou anti-cycle (arbre malformé)

    TDF_Label resolvedLabel = label;
    TopLoc_Location myLoc; // identité par défaut (label non-référence : pas de placement propre)
    if (shapeTool->IsReference(label)) {
        TDF_Label referred;
        if (XCAFDoc_ShapeTool::GetReferredShape(label, referred)) resolvedLabel = referred;
        myLoc = XCAFDoc_ShapeTool::GetLocation(label);
    }
    TopLoc_Location accumLoc = parentLoc * myLoc;

    if (shapeTool->IsAssembly(resolvedLabel)) {
        TDF_LabelSequence components;
        shapeTool->GetComponents(resolvedLabel, components);
        for (Standard_Integer i = 1; i <= components.Length(); i++) {
            collectLeaves(shapeTool, colorTool, components.Value(i), accumLoc, out, depth + 1);
        }
        return;
    }

    // Feuille : shape "prototype" (repère local), on applique le transform composé
    // accumulé depuis la racine pour obtenir sa position réelle dans l'assemblage.
    TopoDS_Shape rawShape = XCAFDoc_ShapeTool::GetShape(resolvedLabel);
    if (rawShape.IsNull()) return;
    TopoDS_Shape placed = rawShape.Moved(accumLoc);

    // Nom : celui de l'INSTANCE (label) est souvent plus parlant que celui du
    // prototype partagé (ex: une vis M3x6 répétée 17 fois garde le même nom
    // prototype "M3x6 FHCS" — c'est déjà le comportement attendu ici, cf. NASSCAD
    // WASM qui affiche aussi les noms de prototype répétés).
    std::string name = "Body";
    Handle(TDataStd_Name) nameAttr;
    if (resolvedLabel.FindAttribute(TDataStd_Name::GetID(), nameAttr)) {
        std::string n = extendedStringToUtf8(nameAttr->Get());
        if (!n.empty()) name = n;
    }

    // Couleur : essayer d'abord au niveau de l'INSTANCE (override possible par
    // usage dans l'assemblage), puis au niveau du PROTOTYPE si rien à l'instance.
    // [13/08] ColorCurv ajoute au chainage — absent avant, alors que la doc
    // officielle OCCT (XCAFDoc_ColorTool) liste explicitement 3 types
    // (Gen/Surf/Curv), pas 2. Reste sur le lookup par LABEL (pas
    // CollectStyleSettings/shape+location) — c'est deja le choix qui evite le
    // bug de correspondance documente ci-dessus, ne pas y toucher.
    std::optional<Quantity_Color> col;
    Quantity_Color qc;
    const char* colPath = "none";
    std::shared_ptr<FaceColorMap> faceMap;
    if (colorTool->GetColor(label, XCAFDoc_ColorSurf, qc)) { col = qc; colPath = "label-inst-Surf"; }
    else if (colorTool->GetColor(label, XCAFDoc_ColorGen, qc)) { col = qc; colPath = "label-inst-Gen"; }
    else if (colorTool->GetColor(label, XCAFDoc_ColorCurv, qc)) { col = qc; colPath = "label-inst-Curv"; }
    else if (colorTool->GetColor(resolvedLabel, XCAFDoc_ColorSurf, qc)) { col = qc; colPath = "label-proto-Surf"; }
    else if (colorTool->GetColor(resolvedLabel, XCAFDoc_ColorGen, qc)) { col = qc; colPath = "label-proto-Gen"; }
    else if (colorTool->GetColor(resolvedLabel, XCAFDoc_ColorCurv, qc)) { col = qc; colPath = "label-proto-Curv"; }

    // [13/08] Repli niveau FACE — certains fichiers STEP (pieces multicolores,
    // couleurs par face plutot que par solide) ne posent JAMAIS de couleur au
    // niveau du solide/label. Premiere face coloree trouvee = couleur du solide.
    // [27/08] Balayage COMPLET des faces au lieu de s'arreter a la premiere :
    // les suivantes alimentent la carte face -> couleur que extractInto
    // transformera en groupes.
    //
    // ══ [31/08] CE BLOC N'EST PLUS DANS UN `else`. ═══════════════════════════
    //
    // Il l'etait, et le commentaire du 27/08 justifiait ainsi son cout : "cette
    // branche n'est atteinte QUE par les solides dont aucun label ne porte de
    // couleur, c'est-a-dire exactement les multicolores. Les solides monochromes
    // n'y passent jamais."
    //
    // Cette hypothese — un solide qui porte une couleur de label n'a pas de
    // couleurs de face — est FAUSSE. Autodesk Inventor, via ST-Developer,
    // exporte les deux a la fois : une couleur sur le MANIFOLD_SOLID_BREP *et*
    // des couleurs sur les ADVANCED_FACE. Mesure sur le Part21 brut de
    // Scania-Engine-V8-XT-Turbo.step (374 Mo) :
    //   - 15 176 STYLED_ITEM, dont 14 921 visent une FACE et 254 un solide ;
    //   - les 254 corps ont TOUS une couleur de label, donc les 6 lookups
    //     ci-dessus reussissaient toujours et ce balayage n'etait JAMAIS
    //     execute : aucun corps du fichier n'a jamais recu de tableau `faces` ;
    //   - 98 corps sur 254 ont une couleur de solide qui differe de la couleur
    //     dominante de leurs faces — ils s'affichaient donc faux ;
    //   - 41 d'entre eux ont un solide jaune #DDDD0D sans qu'AUCUNE de leurs
    //     faces ne soit jaune : c'est le jaune vif observe a l'ecran, absent de
    //     FreeCAD qui lit correctement les couleurs de face.
    //
    // La regle appliquee ci-dessous est celle d'OCCT, pas une convention maison :
    // dans XCAFPrs::CollectStyleSettings, le style d'une sous-forme est ecrit
    // dans la map des styles et ECRASE celui de son parent. La couleur du solide
    // ne vaut que pour les faces qui n'ont pas la leur.
    //
    // Cout : le parcours tourne maintenant pour TOUS les solides et plus
    // seulement pour ceux sans couleur de label. C'est un TopExp_Explorer et un
    // lookup de label par face — negligeable devant la tessellation, qui
    // parcourt deja exactement les memes faces juste apres (extractInto).
    // ════════════════════════════════════════════════════════════════════════
    //
    // [31/08 — perf] Le balayage est MEMORISE PAR PROTOTYPE. rawShape sort de
    // GetShape(resolvedLabel) : c'est la forme du prototype, dans son repere
    // local, partagee telle quelle par toutes ses instances (le placement est
    // applique apres, sur `placed`). Deux instances d'une meme piece voient donc
    // exactement les memes TopoDS_Face, les memes TShape, et produisent le meme
    // resultat de balayage — le recalculer par instance etait du travail pur.
    // Sur le Scania : 1295 instances pour 254 prototypes, soit 5x moins d'appels.
    //
    // Ce qui N'EST PAS mis en cache : la couleur du SOLIDE. Elle se resout au
    // niveau de l'INSTANCE (ligne ~998, `label` avant `resolvedLabel`) parce
    // qu'un assemblage peut surcharger la couleur d'une occurrence precise.
    // Seul le balayage des faces, qui ne depend que du prototype, est memorise.
    //
    // Thread-safety : collectLeaves s'execute en PHASE A, mono-thread par
    // construction — c'est la meme garantie qui autorise deja gColorTool et
    // gShapeTool a etre lus sans verrou ici (cf. le commentaire de la boucle
    // phase A, ligne ~1288). Le cache est vide a chaque import (gFaceScanCache
    // .clear(), a cote de gRepairedCount).
    const void* protoKey = rawShape.TShape().get();
    auto itScan = gFaceScanCache.find(protoKey);
    if (itScan == gFaceScanCache.end()) {
        FaceScan sc;
        sc.map = std::make_shared<FaceColorMap>();
        Quantity_Color fqc;
        for (TopExp_Explorer fe(rawShape, TopAbs_FACE); fe.More(); fe.Next()) {
            sc.nFaces++;
            bool got = false;
            // fqc et non qc : qc porte deja la couleur du solide resolue plus
            // haut, l'ecraser ici la perdrait pour les faces non stylees.
            if (colorTool->GetColor(fe.Current(), XCAFDoc_ColorSurf, fqc)) got = true;
            else if (colorTool->GetColor(fe.Current(), XCAFDoc_ColorGen, fqc)) got = true;
            else if (colorTool->GetColor(fe.Current(), XCAFDoc_ColorCurv, fqc)) got = true;
            if (!got) continue;
            sc.nStyled++;
            if (!sc.first) sc.first = fqc;
            else if (sc.uniform && !sc.first->IsEqual(fqc)) sc.uniform = false;
            double fr, fg, fb;
            occtColorToSRGB(fqc, fr, fg, fb);
            (*sc.map)[fe.Current().TShape().get()] = FaceRGB{ (float)fr, (float)fg, (float)fb };
        }
        if (sc.nStyled == 0) sc.map.reset();
        itScan = gFaceScanCache.emplace(protoKey, std::move(sc)).first;
    }
    const FaceScan& scan = itScan->second;

    // La decision elle-meme vit dans decideBodyColor() — fonction pure, testee
    // par "--selftest-colors". La carte est partagee entre instances d'un meme
    // prototype : elle n'est jamais ecrite en aval, donc le partage est sur.
    const ColorDecision dec = decideBodyColor(scan, col, colPath);
    col     = dec.col;
    colPath = dec.path;
    faceMap = dec.useFaceMap ? scan.map : nullptr;
    // Note : le `if (faceMap->size() < 2) faceMap.reset()` d'avant a saute. Il
    // jetait la carte quand une SEULE face etait stylee — or ce cas porte
    // desormais de l'information : une face coloree parmi 500 grises doit donner
    // deux groupes, pas un corps uniforme.

    out.push_back({name, col, gRootDeflection, placed, rawShape, faceMap, resolvedLabel, colPath});
}

// ─────────────────────────────────────────────────────────────────────────
// Pipeline STEP : ReadStream en mémoire -> XCAF (noms/couleurs) -> tessellation
// Fallback sur STEPControl_Reader simple (un seul mesh, sans nom/couleur) si
// le fichier n'a pas de structure XCAF exploitable (STEP minimal/AP203 basique).
// ─────────────────────────────────────────────────────────────────────────
// Extrait une valeur du header Part21 (FILE_NAME / FILE_DESCRIPTION) par simple scan
// texte de la zone HEADER (avant DATA;) — meme approche que le panneau proprietes
// d'Autodesk Viewer / FreeCAD : ces champs sont informatifs, pas geometriques.
static std::string headerField(const std::string& head, const std::string& entity, int argIndex){
    size_t p = head.find(entity + "(");
    if(p == std::string::npos) return "";
    size_t end = head.find(";", p);
    if(end == std::string::npos) return "";
    std::string args = head.substr(p, end - p);
    // recupere la argIndex-ieme chaine quotee '...'
    int idx = -1; size_t i = 0;
    while(i < args.size()){
        if(args[i] == '\''){
            size_t close = args.find('\'', i + 1);
            if(close == std::string::npos) break;
            idx++;
            if(idx == argIndex) return args.substr(i + 1, close - i - 1);
            i = close + 1;
        } else i++;
    }
    return "";
}

#include <functional>

// ─────────────────────────────────────────────────────────────────────────
// [15/08] Parallélisation de la tessellation STEP.
// ─────────────────────────────────────────────────────────────────────────
// Constat : BRepMesh_IncrementalMesh est déjà appelé avec son flag de
// parallélisme interne actif (5e argument Standard_True, cf. tessellateShape)
// — mais ce parallélisme n'exploite que les faces D'UNE SEULE shape. Sur un
// assemblage à centaines/milliers de petits corps (vis, plaques, PCB...),
// chaque pièce individuelle a trop peu de faces pour saturer les cœurs, et
// l'ancienne boucle traitait les pièces UNE PAR UNE (séquentiel) : la
// majorité des cœurs restait inactive pendant tout l'import — exactement le
// cas documenté comme goulot (Scania 1449 corps, Voron 195k lignes). Ici :
// même pattern "pull" déjà utilisé pour /smooth et /repair (compteur
// atomique partagé, un thread par cœur), appliqué à la tessellation STEP
// elle-même, sur des JOBS déjà résolus (couleur/nom/déflection) — voir
// processStepBuffer plus bas pour le découpage en deux phases (phase A
// séquentielle = tout ce qui touche le document XCAF partagé ; phase B
// parallèle = repair + tessellation + extraction, qui ne touche plus jamais
// le document XCAF).
template <class F>
static void parallelForIndices(size_t count, unsigned maxThreads, F&& fn) {
    if (count == 0) return;
    unsigned nThreads = std::thread::hardware_concurrency();
    if (nThreads == 0) nThreads = 4; // hardware_concurrency() peut renvoyer 0, filet de secu (meme choix que /smooth et /repair)
    nThreads = (unsigned)std::min((size_t)nThreads, count);
    if (maxThreads > 0) nThreads = std::min(nThreads, maxThreads);
    if (nThreads <= 1) {
        for (size_t i = 0; i < count; i++) fn(i);
        return;
    }
    std::atomic<size_t> next{0};
    std::vector<std::thread> pool;
    pool.reserve(nThreads);
    std::exception_ptr firstErr = nullptr;
    std::mutex errMx;
    for (unsigned t = 0; t < nThreads; t++) {
        pool.emplace_back([&]() {
            for (;;) {
                size_t i = next.fetch_add(1);
                if (i >= count) break;
                try {
                    fn(i);
                } catch (...) {
                    std::lock_guard<std::mutex> lk(errMx);
                    if (!firstErr) firstErr = std::current_exception();
                }
            }
        });
    }
    for (auto& th : pool) th.join();
    if (firstErr) std::rethrow_exception(firstErr); // apres le join COMPLET de tous les threads — jamais d'arret en plein calcul des autres
}

// [15/08] Verrou par identité de TShape — nécessaire dès que la tessellation
// passe en parallèle : BRepMesh_IncrementalMesh écrit sa triangulation dans
// le cache interne du TShape (Poly_Triangulation), cache PARTAGÉ entre toutes
// les instances d'un même prototype (cf. commentaire plus haut sur le
// partage de TShape entre instances répétées — "17 vis M3x6 identiques").
// Deux threads tessellant simultanément deux INSTANCES du MÊME prototype
// écriraient concurremment dans ce même cache → course. Un mutex PAR TShape
// (alloué paresseusement, clé = pointeur brut du TShape) isole uniquement les
// pièces qui partagent réellement leur géométrie, sans jamais sérialiser des
// pièces indépendantes entre elles.
struct ShapeLockTable {
    std::mutex mapMx;
    std::unordered_map<const void*, std::unique_ptr<std::mutex>> locks;
    std::mutex& forShape(const TopoDS_Shape& s) {
        const void* key = s.TShape().get();
        std::lock_guard<std::mutex> lk(mapMx);
        auto it = locks.find(key);
        if (it == locks.end()) it = locks.emplace(key, std::make_unique<std::mutex>()).first;
        return *it->second;
    }
};

static std::vector<uint8_t> processStepBuffer(const std::string& body, double deflectionOverride,
                                               double& outTessMs, int& outFaceCount,
                                               std::function<void(const MeshData&)> sink = nullptr) {
    auto t0 = Clock::now();

    // deflectionOverride > 0 = valeur EXPLICITE (?deflection= dans l'URL) : prioritaire
    // sur le ratio bbox — pour les tests comparatifs (ex: hypothese deflection vs
    // non-manifold). Sentinel <= 0 = mode auto (ratio bbox occt-import-js, defaut).
    gDeflectionOverride = deflectionOverride;
    // Metadonnees header (zone HEADER seulement, max 8KB — jamais la zone DATA)
    std::string head = body.substr(0, std::min<size_t>(body.size(), 8192));
    std::string metaName      = headerField(head, "FILE_NAME", 0);
    std::string metaTimestamp = headerField(head, "FILE_NAME", 1);
    std::string metaAuthor    = headerField(head, "FILE_NAME", 2);
    std::string metaOrg       = headerField(head, "FILE_NAME", 3);
    std::string metaSystem    = headerField(head, "FILE_NAME", 5);
    std::string metaSchema    = headerField(head, "FILE_SCHEMA", 0);

    std::istringstream stream(body, std::ios::binary);

    Handle(XCAFApp_Application) app = XCAFApp_Application::GetApplication();
    Handle(TDocStd_Document) doc;
    app->NewDocument("MDTV-XCAF", doc);

    // [FIX memoire] XCAFApp_Application::GetApplication() renvoie TOUJOURS la
    // meme instance (singleton process-wide) — et NewDocument() enregistre
    // chaque document cree dans la liste INTERNE de cette instance, qui n'est
    // jamais videe tant qu'on n'appelle pas explicitement Close(doc). Le
    // Handle local `doc` sortant de portee en fin de fonction ne libere donc
    // RIEN : le document (geometrie + couleurs + noms XCAF complets) reste
    // vivant pour le reste de la vie du process. Chaque requete /step ou
    // /stepstream (des dizaines par seconde possibles, cf. medusa.log) en
    // laissait fuiter un -> explosion memoire progressive jusqu'a l'OOM.
    // RAII : ferme automatiquement sur CHAQUE sortie de la fonction, retour
    // normal comme exception (ex: les throw "STEP parsing failed" /
    // "STEP: no shape transferred" / "STEP: no tessellable geometry found"
    // plus bas) — pas besoin de dupliquer l'appel a chaque point de sortie.
    struct DocGuard {
        Handle(XCAFApp_Application) app;
        Handle(TDocStd_Document) doc;
        ~DocGuard() { if (!doc.IsNull()) app->Close(doc); }
    } docGuard{app, doc};

    STEPCAFControl_Reader caf;
    caf.SetNameMode(Standard_True);
    caf.SetColorMode(Standard_True);
    caf.SetLayerMode(Standard_False);
    caf.SetGDTMode(Standard_False);

    IFSelect_ReturnStatus stat = caf.ChangeReader().ReadStream("medusa_input.step", stream);
    std::vector<MeshData> meshes;
    outFaceCount = 0;

    bool cafOk = false;
    if (stat == IFSelect_RetDone) {
        Handle(ConsoleProgress) parseProgress = new ConsoleProgress();
        cafOk = caf.Transfer(doc, parseProgress->Start()) != Standard_False;
    }

    if (cafOk) {
        Handle(XCAFDoc_ShapeTool) shapeTool = XCAFDoc_DocumentTool::ShapeTool(doc->Main());
        Handle(XCAFDoc_ColorTool) colorTool = XCAFDoc_DocumentTool::ColorTool(doc->Main());
        gColorTool = colorTool; // publie pour la resolution couleur par solide (voir boucle)
        gShapeTool = shapeTool; // idem, pour FindSubShape (resolution par label, pas par hash)
        gFaceScanCache.clear(); // [31/08] cache de balayage par prototype — un document XCAF par import
        gRepairedCount = 0;
        gPartialRepairCount = 0; // [15/08 FIX v5]
        gManifoldIssueCount = 0; // [15/08 FIX v5]
        TDF_LabelSequence freeShapes;
        shapeTool->GetFreeShapes(freeShapes);

        std::vector<LeafShape> leaves;
        for (Standard_Integer i = 1; i <= freeShapes.Length(); i++) {
            // Déflection bbox-ratio de la racine — identique occt-import-js.
            TopoDS_Shape rootShape = XCAFDoc_ShapeTool::GetShape(freeShapes.Value(i));
            if (!rootShape.IsNull()) gRootDeflection = rootDeflectionLikeOcctImportJs(rootShape);
            collectLeaves(shapeTool, colorTool, freeShapes.Value(i), TopLoc_Location(), leaves, 0);
        }


        // Éclatement par solide individuel : une étiquette XCAF nommée peut contenir
        // plusieurs solides disjoints (ex: un PCB avec composants = 14 solides sous UN
        // seul nom) — occt-import-js les compte comme autant de mesh séparés. Validé
        // empiriquement : total solides == total mesh(es) rapporté par NASSCAD (198/198).
        //
        // Progression en direct : sur un gros assemblage (Scania 1449 corps, plusieurs
        // minutes), rester muet jusqu'au resultat final ressemble a un blocage — meme
        // s'il n'y en a pas. Une ligne qui s'auto-met a jour (retour chariot \r, pas de
        // saut de ligne) confirme visuellement que ca avance, sans polluer le terminal
        // de milliers de lignes.
        // [15/08] PHASE A (séquentielle) — explosion en solides/shells + résolution
        // couleur/nom : tout ce qui lit gColorTool/gShapeTool (document XCAF
        // partagé, non prouvé thread-safe en lecture concurrente) reste ICI, sur
        // le thread principal, EXACTEMENT comme avant. Le seul changement : au
        // lieu de tesselliser/extraire immédiatement, chaque pièce résolue devient
        // un "PartJob" autonome (shape déjà positionnée + couleur déjà résolue +
        // déflection déjà choisie) empilé dans `jobs` — plus aucun de ces jobs ne
        // touchera le document XCAF ensuite, ce qui rend la PHASE B (plus bas)
        // parallélisable sans risque sur le document.
        struct PartJob {
            TopoDS_Shape part;
            std::string name;
            std::optional<Quantity_Color> color;
            double deflection;
            std::shared_ptr<FaceColorMap> faceColors; // [27/08] cf. LeafShape
        };
        std::vector<PartJob> jobs;
        jobs.reserve(leaves.size());

        // [15/08 FIX v4] Phase A a de nouveau sa barre ("RESOLUTION"), demandee
        // explicitement par Nass ("pareil pour color... tu comprends??"). Le
        // premier essai (FIX v1) avait echoue car [COLOR] restait imprime EN
        // CLAIR sur la console entre deux frames de barre — chaque ligne
        // [COLOR] fermait la frame precedente (comportement normal et voulu,
        // cf. TeeStreambuf::flushBuffer) puis la barre suivante repartait sur
        // une NOUVELLE ligne -> defilement, pas d'ecrasement sur place.
        // Cette fois, [COLOR] part en FICHIER UNIQUEMENT (logFileOnly, cf. sa
        // definition) — plus aucun texte ne s'intercale sur la console entre
        // deux frames RESOLUTION, qui peuvent donc s'ecraser proprement sur
        // place, exactement comme PARSING/TESSELLATION. Rien n'est perdu :
        // medusa.log recoit toujours le detail complet, [COLOR] y compris.
        barPhaseStart();
        size_t resolveLeafIdx = 0;
        for (const auto& leaf : leaves) {
            std::vector<TopoDS_Shape> parts, rawParts;
            {
                // Enumeration a la occt-import-js : solides, PUIS shells hors solides
                // (TopAbs_SHELL avec avoid TopAbs_SOLID) — une piece mixte (1 solide +
                // 1 shell libre) sort en 2 meshes chez le kador, idem ici desormais.
                // Moved() ne change pas l'ordre topologique : explorations paralleles sures.
                TopExp_Explorer sp(leaf.shape, TopAbs_SOLID), sr(leaf.rawShape, TopAbs_SOLID);
                for (; sp.More() && sr.More(); sp.Next(), sr.Next()) {
                    parts.push_back(sp.Current()); rawParts.push_back(sr.Current());
                }
                TopExp_Explorer hp(leaf.shape, TopAbs_SHELL, TopAbs_SOLID),
                                hr(leaf.rawShape, TopAbs_SHELL, TopAbs_SOLID);
                for (; hp.More() && hr.More(); hp.Next(), hr.Next()) {
                    parts.push_back(hp.Current()); rawParts.push_back(hr.Current());
                }
            }
            if (parts.empty()) { parts.push_back(leaf.shape); rawParts.push_back(leaf.rawShape); }

            for (size_t pi = 0; pi < parts.size(); pi++) {
                const auto& part = parts[pi];
                const auto& rawPart = rawParts[pi];
                // Couleur : priorite au SOLIDE individuel (cas multi-solides type PCB :
                // chaque composant electronique porte SA couleur, le label parent n'en a
                // aucune — verifie empiriquement : 12 pieces / 92 solides concernes sur
                // le Stealthburner, 100% des couleurs retrouvees a ce niveau). Fallback :
                // couleur du label parent (cas classique mono-solide), puis premiere face
                // coloree (filet, jamais vu necessaire sur les fichiers testes).
                //
                // [13/08] partColPath ajoute — diagnostic suite a une divergence visuelle
                // NASSCAD vs Fusion/FreeCAD sur Scania-Engine-V8-XT-Turbo (meme fichier,
                // export Fusion) : seulement 12/1297 pieces resolues en teinte orange,
                // 620/1297 en gris-bleu fonce, alors que Fusion/FreeCAD affichent une
                // masse orange dominante. Hypothese non tranchee : la priorite
                // solide-avant-label (correcte sur Stealthburner) pourrait attraper une
                // couleur materiau generique au niveau du solide qui masque la VRAIE
                // teinte cosmetique posee au niveau assemblage/label sur CE fichier
                // precis. Ce marqueur permet de le confirmer ou l'infirmer avec le
                // prochain log, plutot que de deviner une nouvelle fois.
                // [13/08 — neuro-chir] partColPath : diagnostic complet du 13/08 a montre
                // 100% des resolutions (bonnes ET mauvaises) passant par tierB-solid-Surf —
                // pas un probleme de PRIORITE entre etages, mais GetColor(TopoDS_Shape)
                // lui-meme qui retourne parfois la mauvaise couleur au niveau sous-solide.
                // Mecanisme : GetColor hash l'identite exacte de la forme : rien ne garantit
                // qu'un sous-solide extrait via TopExp_Explorer(leaf.rawShape) corresponde
                // hash-pour-hash a ce que le ColorTool a enregistre en interne — meme classe
                // de fragilite documentee (recherche du 13/08 : GetColor casse depuis 7.4.0 ;
                // CollectStyleSettings, l'alternative "officielle", a son propre bug connu sur
                // les assemblages a instances repetees). resolvedLabel avait deja contourne ce
                // probleme au niveau du LEAF entier (198/198 vs 106/198) ; meme logique
                // appliquee ici au niveau SOUS-solide : FindSubShape donne un LABEL explicite
                // pour ce sous-solide precis, GetColor(label) evite alors le hash de forme —
                // tente EN PREMIER, avant le hash direct qui reste en repli (rien retire).
                // [27/08] PRIORITE INVERSEE — la couleur du LEAF gagne quand elle existe.
                //
                // Preuve (Scania-Engine-V8-XT-Turbo, 1170 pieces) : --decode-colors, qui
                // resout au niveau leaf, ne rend le jaune #DDDD0D que 4 fois sur tout le
                // fichier. L'import, lui, l'appliquait 565 fois. Deux pieces nommees le
                // montrent sans ambiguite :
                //     "Oil Pump V8-XT-11"  leaf = #BEBCBA (gris)  -> import = #DDDD0D
                //     "Engine V8-XT-11"    leaf = #5A6266 (gris)  -> import = #DDDD0D
                // Les deux etages d'ecrasement (FindSubShape par label, puis GetColor par
                // hash de forme) rendaient donc une couleur qui n'appartient pas a ce
                // sous-solide. FreeCAD et Fusion affichent le gris : c'est le leaf qui a
                // raison.
                //
                // Ces deux etages restent indispensables, mais UNIQUEMENT quand le leaf n'a
                // aucune couleur — c'est exactement le cas PCB du Stealthburner valide le
                // 13/08 ("chaque composant porte SA couleur, le label parent n'en a
                // aucune"). Ce cas passe toujours par le sous-solide, sans regression.
                //
                // ══ [31/08] La regle est bonne, l'explication ne l'etait pas. ═══════
                //
                // Le 27/08 attribuait le jaune a un ecrasement fautif : "les deux etages
                // rendaient une couleur qui n'appartient pas a ce sous-solide". Le log du
                // 31/08 montre le contraire — cf. la correction detaillee au-dessus de
                // gShapeTool. #DDDD0D appartient bel et bien a ce solide : c'est la
                // couleur que le fichier pose sur son MANIFOLD_SOLID_BREP. Ce qui ne lui
                // appartenait pas, c'etait la PRIORITE : les faces de ce meme solide
                // portent leur propre couleur, et la regle OCCT veut qu'elle gagne.
                //
                // "Le leaf gagne" tombait donc juste pour la mauvaise raison. Depuis le
                // 31/08 la raison est la bonne : leaf.color est desormais resolu par
                // decideBodyColor(), qui applique explicitement la precedence face >
                // solide. Cette garde continue de faire exactement ce qu'il faut — ne pas
                // la retirer — mais elle n'est plus un pansement sur un bug suppose
                // d'OCCT : elle propage une couleur de leaf deja correcte.
                //
                // Chiffres du meme log : 1255 corps sur 1295 passent par tierA-leaf, 40
                // par subshape-label-Surf (leaf sans couleur, le cas PCB). Le jaune tombe
                // de 53 prototypes a 2 corps.
                // ═══════════════════════════════════════════════════════════════════
                std::optional<Quantity_Color> partCol = leaf.color;
                const char* partColPath = leaf.color ? "tierA-leaf" : "tierB-none";
                Quantity_Color qc;
                TDF_Label subLabel;
                if (!partCol && gShapeTool && gShapeTool->FindSubShape(leaf.resolvedLabel, rawPart, subLabel)) {
                    if (gColorTool && gColorTool->GetColor(subLabel, XCAFDoc_ColorSurf, qc)) {
                        partCol = qc; partColPath = "subshape-label-Surf";
                    } else if (gColorTool && gColorTool->GetColor(subLabel, XCAFDoc_ColorGen, qc)) {
                        partCol = qc; partColPath = "subshape-label-Gen";
                    } else if (gColorTool && gColorTool->GetColor(subLabel, XCAFDoc_ColorCurv, qc)) {
                        partCol = qc; partColPath = "subshape-label-Curv";
                    }
                }
                // [27/08] Meme garde : ce repli par hash de forme (le plus fragile des
                // trois, cf. la recherche du 13/08) ne doit jamais ecraser une couleur de
                // leaf existante. Il ne sert plus que de dernier recours.
                if (!partCol) {
                if (gColorTool && gColorTool->GetColor(rawPart, XCAFDoc_ColorSurf, qc)) {
                    partCol = qc; partColPath = "tierB-solid-Surf";
                } else if (gColorTool && gColorTool->GetColor(rawPart, XCAFDoc_ColorGen, qc)) {
                    partCol = qc; partColPath = "tierB-solid-Gen";
                } else if (gColorTool && gColorTool->GetColor(rawPart, XCAFDoc_ColorCurv, qc)) {
                    partCol = qc; partColPath = "tierB-solid-Curv";
                } else if (!partCol && gColorTool) {
                    for (TopExp_Explorer fe(rawPart, TopAbs_FACE); fe.More(); fe.Next()) {
                        if (gColorTool->GetColor(fe.Current(), XCAFDoc_ColorSurf, qc)) { partCol = qc; partColPath = "tierB-face-Surf"; break; }
                        if (gColorTool->GetColor(fe.Current(), XCAFDoc_ColorGen, qc)) { partCol = qc; partColPath = "tierB-face-Gen"; break; }
                        if (gColorTool->GetColor(fe.Current(), XCAFDoc_ColorCurv, qc)) { partCol = qc; partColPath = "tierB-face-Curv"; break; }
                    }
                }
                } // ferme le bloc "if (!partCol)" ouvert plus haut [27/08]
                // [10/08] Log couleur COMPLET — chaque piece, pas seulement les
                // echecs (demande explicite : donnees d'analyse, pas juste alerte).
                // Va dans medusa.log via le Tee — permanent, relisible apres coup.
                // [15/08 FIX v4] logFileOnly plutot que cerr direct — voir le
                // commentaire au-dessus de la boucle (barre RESOLUTION). Reste
                // NON verrouille par gConsoleMutex : phase A est mono-thread par
                // construction (aucun worker demarre avant la fin de cette
                // boucle), donc pas de concurrence a proteger ici.
                // [27/08] Trace de ce que l'ANCIENNE priorite aurait applique : si un
                // etage inferieur porte une couleur DIFFERENTE de celle du leaf, la ligne
                // ci-dessous le dit. Sur le Scania elle doit sortir ~565 fois avec le
                // jaune #DDDD0D face au gris du leaf — c'est la preuve que l'ecrasement
                // etait bien la cause, conservee pour le jour ou un fichier posera la
                // question inverse.
                if (partCol && gColorTool) {
                    Quantity_Color dq;
                    bool got = false;
                    TDF_Label dLab;
                    if (gShapeTool && gShapeTool->FindSubShape(leaf.resolvedLabel, rawPart, dLab))
                        got = gColorTool->GetColor(dLab, XCAFDoc_ColorSurf, dq)
                           || gColorTool->GetColor(dLab, XCAFDoc_ColorGen,  dq)
                           || gColorTool->GetColor(dLab, XCAFDoc_ColorCurv, dq);
                    if (!got) got = gColorTool->GetColor(rawPart, XCAFDoc_ColorSurf, dq);
                    if (got && !dq.IsEqual(*partCol)) {
                        double lr, lg, lb, dr, dg, db;
                        occtColorToSRGB(*partCol, lr, lg, lb);
                        occtColorToSRGB(dq, dr, dg, db);
                        std::ostringstream od;
                        od << "[COLOR-KEPT-LEAF] \"" << leaf.name.substr(0,40) << "\" leaf=("
                           << lr << "," << lg << "," << lb << ") ignored subshape=("
                           << dr << "," << dg << "," << db << ")\n";
                        logFileOnly(od.str());
                    }
                }

                if (partCol) {
                    // [26/08] log en sRGB = valeurs du fichier : medusa.log devient
                    // directement comparable a FreeCAD / Fusion / CAD Assistant.
                    double lr, lg, lb;
                    occtColorToSRGB(*partCol, lr, lg, lb);
                    std::ostringstream oss;
                    // [31/08] DEUX chemins imprimes, pas un. `path` est celui du
                    // niveau SOUS-SOLIDE ; `leafpath` dit comment la couleur du
                    // leaf a ete obtenue en amont. Quand path=tierA-leaf — le cas
                    // ordinaire — c'est leafpath qui porte toute l'information, et
                    // il manquait. Chercher "leafpath=face-uniform-override" pour
                    // voir les corps ou la couleur des faces a ecrase celle du
                    // solide ; "faces=oui" pour ceux qui partent en multi-groupes.
                    oss << "[COLOR] \"" << leaf.name.substr(0,40) << "\" RGB("
                        << lr << "," << lg << "," << lb
                        << ") path=" << partColPath
                        << " leafpath=" << leaf.colPath
                        << " faces=" << (leaf.faceColors ? "yes" : "no") << "\n";
                    logFileOnly(oss.str());
                } else {
                    logFileOnly("[COLOR] \"" + leaf.name.substr(0,40) + "\" none found (leaf/solid/face all empty)\n");
                }
                jobs.push_back({part, leaf.name, partCol, leaf.deflection, leaf.faceColors});
            }

            // Barre RESOLUTION — throttlee par LEAF (pas par solide individuel :
            // le nombre total de solides n'est connu qu'a la fin de cette boucle,
            // impossible a utiliser comme denominateur pendant qu'elle tourne).
            // Granularite legerement plus grossiere que TESSELLATION mais suffit
            // a donner un signe de vie continu sur un gros assemblage (Scania
            // 1449 corps) — plus aucun [COLOR] en clair pour l'interrompre.
            resolveLeafIdx++;
            if (!leaves.empty()) {
                int pct = (int)(100.0 * resolveLeafIdx / leaves.size());
                int prevPct = (int)(100.0 * (resolveLeafIdx - 1) / leaves.size());
                if (pct != prevPct || resolveLeafIdx == leaves.size()) {
                    std::string shortName = leaf.name.substr(0, 18);
                    drawBarLine("RESOLUTION",
                        (double)resolveLeafIdx / leaves.size(),
                        std::to_string(pct) + "%  (" + std::to_string(resolveLeafIdx) + "/" + std::to_string(leaves.size()) + ")  " + shortName);
                }
            }
        }

        // [15/08] PHASE B (parallèle) — repair + tessellation + extraction, un
        // thread par cœur (parallelForIndices, défini plus haut). Chaque job est
        // 100% autonome (shape + couleur + déflection déjà résolues en phase A) :
        // aucun accès au document XCAF ici, donc aucun risque sur gColorTool/
        // gShapeTool. `jobResults[i]` reçoit 0 ou 1 MeshData (extractInto peut ne
        // rien produire sur une géométrie dégénérée, comme avant) ; l'ordre de
        // `jobs` — donc l'ordre final de `meshes` — est préservé par la
        // compaction séquentielle après le join, même si les threads terminent
        // dans un ordre différent. Pour /stepstream, le sink() est appelé DANS
        // l'ordre de complétion (pas l'ordre des jobs) — sans impact : le but du
        // streaming est un affichage progressif côté client, pas un ordre garanti.
        std::vector<std::vector<MeshData>> jobResults(jobs.size());
        std::atomic<size_t> tessDone{0};
        std::atomic<int> faceCounter{0};
        size_t lastDrawnTess = 0;
        ShapeLockTable shapeLocks;
        std::mutex sinkMx; // protege les ecritures socket du sink /stepstream (frames NSTS non-entrelacables)
        barPhaseStart();
        parallelForIndices(jobs.size(), 0, [&](size_t i) {
            const PartJob& job = jobs[i];
            TopoDS_Shape workPart = repairIfOpen(job.part, job.name, gRepairedCount);
            {
                // [15/08] Verrou par TShape : seule la tessellation ecrit dans le cache
                // OCCT partage entre instances d'un meme prototype — repair/extract
                // travaillent sur des donnees locales au job, pas de verrou necessaire.
                std::lock_guard<std::mutex> lk(shapeLocks.forShape(workPart));
                tessellateShape(workPart, job.deflection);
            }
            // [PERF 18/08] faces deja compte PAR extractInto pendant son propre
            // parcours TopExp_Explorer(FACE) de workPart — plus besoin de reparcourir
            // la meme topologie une 2e fois rien que pour ce compteur (cf. son
            // commentaire). Valeur identique, une seule traversee au lieu de deux.
            int faces = extractInto(workPart, job.name, job.color, jobResults[i], job.faceColors.get());
            faceCounter.fetch_add(faces);
            if (!jobResults[i].empty()) {
                logRawManifoldCheck(jobResults[i].back());
                if (sink) {
                    std::lock_guard<std::mutex> lk(sinkMx);
                    sink(jobResults[i].back());
                }
            }

            // Barre TESSELLATION : granularité par PART (plus fine que l'ancienne
            // granularité par LEAF), throttlée aux paliers de 1% comme avant. Le nom
            // affiché est celui de la pièce qui VIENT de finir sur ce thread — avec N
            // pièces en vol simultanément, il n'y a plus une seule "pièce en cours",
            // donc on affiche la dernière complétion plutôt qu'une fausse impression
            // de séquentialité. `lastDrawnTess` (sous gConsoleMutex) garantit que le
            // pourcentage affiché ne recule jamais malgré l'ordre de complétion non
            // déterministe entre threads.
            size_t done = tessDone.fetch_add(1) + 1;
            std::lock_guard<std::mutex> lk(gConsoleMutex);
            if (done > lastDrawnTess) {
                int pct = (int)(100.0 * done / jobs.size());
                int prevPct = (int)(100.0 * lastDrawnTess / jobs.size());
                if (pct != prevPct || done == jobs.size()) {
                    std::string shortName = job.name.substr(0, 18);
                    drawBarLine("TESSELLATION",
                        (double)done / jobs.size(),
                        std::to_string(pct) + "%  (" + std::to_string(done) + "/" + std::to_string(jobs.size()) + ")  " + shortName + repairManifoldSuffix());
                }
                lastDrawnTess = done;
            }
        });

        outFaceCount += faceCounter.load();
        for (auto& jr : jobResults) for (auto& md : jr) meshes.push_back(std::move(md));
    }

    // Fallback : XCAF vide (0 free shape, ou aucune feuille trouvée) -> lecture
    // brute avec le reader simple (un seul mesh, sans nom/couleur).
    if (meshes.empty()) {
        STEPControl_Reader reader;
        std::istringstream stream2(body, std::ios::binary);
        IFSelect_ReturnStatus stat2 = reader.ReadStream("medusa_input.step", stream2);
        if (stat2 != IFSelect_RetDone) throw std::runtime_error("STEP parsing failed (native reader)");
        reader.TransferRoots();
        TopoDS_Shape shape = reader.OneShape();
        if (shape.IsNull()) throw std::runtime_error("STEP: no shape transferred");
        gRootDeflection = rootDeflectionLikeOcctImportJs(shape);
        double fbDeflection = gRootDeflection; // [15/08] capture par valeur — voir commentaire tessellateShape
        // Meme enumeration multi-corps que le chemin XCAF : solides -> shells hors
        // solides -> shape entiere en dernier recours. Sans ca, tout fichier passant
        // par le fallback (AP203 minimal, chunk degrade, XCAF en echec) ressortait
        // FUSIONNE en un seul mesh — la regression corrigee en v1.1 ressurgissait
        // par cette porte-la.
        std::vector<TopoDS_Shape> fbParts;
        for (TopExp_Explorer se(shape, TopAbs_SOLID); se.More(); se.Next()) fbParts.push_back(se.Current());
        for (TopExp_Explorer he(shape, TopAbs_SHELL, TopAbs_SOLID); he.More(); he.Next()) fbParts.push_back(he.Current());
        if (fbParts.empty()) fbParts.push_back(shape);

        // [15/08] Meme parallelisation que le chemin XCAF (voir PHASE B plus haut) —
        // pas de document XCAF ici (fallback = pas de nom/couleur), donc pas de
        // phase sequentielle separee necessaire : chaque partie est deja autonome.
        std::vector<std::vector<MeshData>> fbResults(fbParts.size());
        std::atomic<size_t> fbDone{0};
        std::atomic<int> fbFaceCounter{0};
        size_t lastDrawnFb = 0;
        ShapeLockTable shapeLocks;
        std::mutex sinkMx;
        barPhaseStart();
        parallelForIndices(fbParts.size(), 0, [&](size_t i) {
            std::string name = "Body_" + std::to_string(i + 1);
            TopoDS_Shape workPart = repairIfOpen(fbParts[i], name, gRepairedCount);
            {
                std::lock_guard<std::mutex> lk(shapeLocks.forShape(workPart));
                tessellateShape(workPart, fbDeflection);
            }
            // [PERF 18/08] meme fusion que dans la boucle PHASE B ci-dessus — voir
            // le commentaire pres de extractInto().
            int faces = extractInto(workPart, name, std::nullopt, fbResults[i]);
            fbFaceCounter.fetch_add(faces);
            if (!fbResults[i].empty() && sink) {
                std::lock_guard<std::mutex> lk(sinkMx);
                sink(fbResults[i].back());
            }

            size_t done = fbDone.fetch_add(1) + 1;
            std::lock_guard<std::mutex> lk(gConsoleMutex);
            if (done > lastDrawnFb) {
                int pct = (int)(100.0 * done / fbParts.size());
                int prevPct = (int)(100.0 * lastDrawnFb / fbParts.size());
                if (pct != prevPct || done == fbParts.size()) {
                    drawBarLine("TESSELLATION", (double)done / fbParts.size(),
                        std::to_string(pct) + "%  (" + std::to_string(done) + "/" + std::to_string(fbParts.size()) + ")  " + name + repairManifoldSuffix());
                }
                lastDrawnFb = done;
            }
        });
        outFaceCount += fbFaceCounter.load();
        for (auto& jr : fbResults) for (auto& md : jr) meshes.push_back(std::move(md));
    }

    if (meshes.empty()) throw std::runtime_error("STEP: no tessellable geometry found");

    {
        std::ostringstream mj;
        mj << "{\"file\":\"" << jsonEscape(metaName) << "\","
           << "\"timestamp\":\"" << jsonEscape(metaTimestamp) << "\","
           << "\"author\":\"" << jsonEscape(metaAuthor) << "\","
           << "\"organization\":\"" << jsonEscape(metaOrg) << "\","
           << "\"originatingSystem\":\"" << jsonEscape(metaSystem) << "\","
           << "\"schema\":\"" << jsonEscape(metaSchema) << "\"}";
        gMetaJson = mj.str();
    }
    gColorTool.Nullify(); // fin de requete : ne pas garder le doc precedent en vie
    gShapeTool.Nullify();

    auto t1 = Clock::now();
    outTessMs = ms(t0, t1);
    if (sink) return {}; // mode streaming : tout est deja parti par le sink, pas de bloc final
    return encodeNSTP(meshes, outTessMs);
}

// ─────────────────────────────────────────────────────────────────────────
// Serveur HTTP minimal (POSIX sockets, mono-thread, séquentiel — usage local
// mono-utilisateur, pas de charge concurrente attendue).
// ─────────────────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════
// ── Lissage BFS natif — portage FIDELE de _ppSmooth (Postprocess Worker
// JS, NASSCAD_V4_7_0_DEV.htm) ─────────────────────────────────────────────
// But : deporter le goulot mesure sur import STEP multi-corps (~7 min de
// silence sur 1449 corps, cf. session precedente) — un seul Worker JS
// traitait chaque corps SEQUENTIELLEMENT. Ici : N corps independants,
// traites EN PARALLELE (thread par coeur), chacun avec l'algorithme exact
// du JS (meme tolerance de weld 1e-4, meme ponderation par angle au coin
// Thurmer & Wuthrich 1998, meme sortie non-indexee).
// ═══════════════════════════════════════════════════════════════════════

// Weld par position — DUPLIQUE depuis weldMeshForCSG (/csg) plutot que
// factorise : /csg est deja livre et teste, on ne le touche pas pour ce
// nouvel endpoint. Meme tolerance (1e-4), meme hash open-addressing.
static void weldMeshLocal(std::vector<float>& pos, std::vector<uint32_t>& idx) {
    const double tol = 1e-4;
    size_t nVert = pos.size() / 3;
    auto quant = [&](float v){ return (int32_t)std::llround((double)v / tol); };
    std::vector<int32_t> qx(nVert), qy(nVert), qz(nVert);
    for (size_t i = 0; i < nVert; i++) {
        qx[i] = quant(pos[i*3]); qy[i] = quant(pos[i*3+1]); qz[i] = quant(pos[i*3+2]);
    }
    size_t cap = 1; while (cap < nVert * 2) cap <<= 1;
    size_t mask = cap - 1;
    std::vector<int32_t> table(cap, -1);
    std::vector<uint32_t> remap(nVert);
    std::vector<float> welded; welded.reserve(pos.size());
    for (size_t i = 0; i < nVert; i++) {
        size_t h = ((uint32_t)qx[i]*73856093u ^ (uint32_t)qy[i]*19349663u ^ (uint32_t)qz[i]*83492791u) & mask;
        for (;;) {
            int32_t s = table[h];
            if (s == -1) {
                table[h] = (int32_t)i;
                remap[i] = (uint32_t)(welded.size() / 3);
                welded.push_back(pos[i*3]); welded.push_back(pos[i*3+1]); welded.push_back(pos[i*3+2]);
                break;
            }
            if (qx[s]==qx[i] && qy[s]==qy[i] && qz[s]==qz[i]) { remap[i] = remap[s]; break; }
            h = (h + 1) & mask;
        }
    }
    for (auto& v : idx) v = remap[v];
    pos = std::move(welded);
}

// Normales de face — produit vectoriel normalise (identique a _ppFN).
static std::vector<float> computeFaceNormalsLocal(const std::vector<float>& pos, const std::vector<uint32_t>& idx) {
    size_t nF = idx.size() / 3;
    std::vector<float> fn(nF * 3);
    for (size_t f = 0; f < nF; f++) {
        uint32_t a = idx[f*3], b = idx[f*3+1], c = idx[f*3+2];
        float ax=pos[a*3], ay=pos[a*3+1], az=pos[a*3+2];
        float bx=pos[b*3], by=pos[b*3+1], bz=pos[b*3+2];
        float cx=pos[c*3], cy=pos[c*3+1], cz=pos[c*3+2];
        float e1x=bx-ax, e1y=by-ay, e1z=bz-az;
        float e2x=cx-ax, e2y=cy-ay, e2z=cz-az;
        float nx=e1y*e2z-e1z*e2y, ny=e1z*e2x-e1x*e2z, nz=e1x*e2y-e1y*e2x;
        float L = std::sqrt(nx*nx+ny*ny+nz*nz); if (L < 1e-20f) L = 1.0f;
        fn[f*3]=nx/L; fn[f*3+1]=ny/L; fn[f*3+2]=nz/L;
    }
    return fn;
}

// Angle au coin (poids de la normale lissee) — identique a cornerAngle() JS.
static inline double cornerAngleLocal(const std::vector<float>& pos, const std::vector<uint32_t>& idx,
                                       uint32_t af, uint32_t v) {
    uint32_t a = idx[af*3], b = idx[af*3+1], c = idx[af*3+2];
    uint32_t p, q;
    if (v == a) { p = b; q = c; } else if (v == b) { p = c; q = a; } else { p = a; q = b; }
    double vx=pos[v*3], vy=pos[v*3+1], vz=pos[v*3+2];
    double e1x=pos[p*3]-vx, e1y=pos[p*3+1]-vy, e1z=pos[p*3+2]-vz;
    double e2x=pos[q*3]-vx, e2y=pos[q*3+1]-vy, e2z=pos[q*3+2]-vz;
    double l1 = std::sqrt(e1x*e1x+e1y*e1y+e1z*e1z); if (l1 < 1e-20) l1 = 1.0;
    double l2 = std::sqrt(e2x*e2x+e2y*e2y+e2z*e2z); if (l2 < 1e-20) l2 = 1.0;
    double d = (e1x*e2x+e1y*e2y+e1z*e2z) / (l1*l2);
    if (d > 1.0) d = 1.0; else if (d < -1.0) d = -1.0;
    return std::acos(d);
}

struct SmoothResult { std::vector<float> pos, nrm; std::vector<uint32_t> idx; };
// [11/08] Repair natif (/repair) — cf. RepairResult plus bas dans le handler HTTP ;
// declaree ici pour la meme raison que SmoothResult (portee fichier, style existant).
struct RepairResult { std::vector<float> pos; std::vector<uint32_t> idx; bool repaired; };

// Pipeline complet pour UN mesh : weld -> normales de face -> ilots BFS
// (angle diedre < crease) -> normales ponderees par angle au coin, PUIS
// regroupement par (vertex soude, ilot) -> sortie INDEXEE (cf. commentaire
// detaille dans le corps de la fonction). Un vertex touche par plusieurs
// ilots differents (vraie arete vive) recoit une copie par ilot ; sinon,
// une seule copie partagee par toutes les faces de son ilot.
static SmoothResult smoothMeshBFSLocal(std::vector<float> pos, std::vector<uint32_t> idx, double cosCrease) {
    weldMeshLocal(pos, idx);
    auto fn = computeFaceNormalsLocal(pos, idx);
    size_t nV = pos.size() / 3, nF = idx.size() / 3;

    // v -> f (CSR)
    std::vector<uint32_t> cnt(nV, 0);
    for (size_t i = 0; i < idx.size(); i++) cnt[idx[i]]++;
    std::vector<uint32_t> voff(nV + 1, 0);
    for (size_t v = 0; v < nV; v++) voff[v+1] = voff[v] + cnt[v];
    std::vector<uint32_t> lst(voff[nV]);
    std::vector<uint32_t> fil(nV, 0);
    for (size_t f = 0; f < nF; f++)
        for (int vi = 0; vi < 3; vi++) { uint32_t v = idx[f*3+vi]; lst[voff[v]+fil[v]++] = (uint32_t)f; }

    // edge -> faces (cle numerique a*nV+b, comme EK() en JS)
    std::unordered_map<uint64_t, std::vector<uint32_t>> e2f;
    e2f.reserve(nF * 2);
    auto EK = [nV](uint64_t a, uint64_t b) -> uint64_t { return a < b ? a*(uint64_t)nV+b : b*(uint64_t)nV+a; };
    for (size_t f = 0; f < nF; f++) {
        uint32_t a = idx[f*3], b = idx[f*3+1], c = idx[f*3+2];
        uint64_t pairs[3][2] = {{a,b},{b,c},{c,a}};
        for (auto& pr : pairs) e2f[EK(pr[0], pr[1])].push_back((uint32_t)f);
    }

    // BFS ilots par angle diedre
    std::vector<int32_t> f2i(nF, -1);
    std::vector<uint8_t> vis(nF, 0);
    int32_t nI = 0;
    std::vector<uint32_t> Q;
    for (size_t sF = 0; sF < nF; sF++) {
        if (vis[sF]) continue;
        int32_t iId = nI++;
        Q.clear(); Q.push_back((uint32_t)sF); vis[sF] = 1; f2i[sF] = iId;
        size_t h = 0;
        while (h < Q.size()) {
            uint32_t f = Q[h++];
            uint32_t fa = idx[f*3], fb = idx[f*3+1], fc = idx[f*3+2];
            float fx = fn[f*3], fy = fn[f*3+1], fz = fn[f*3+2];
            uint64_t pairs[3][2] = {{fa,fb},{fb,fc},{fc,fa}};
            for (auto& pr : pairs) {
                auto it = e2f.find(EK(pr[0], pr[1]));
                if (it == e2f.end()) continue;
                for (uint32_t nf : it->second) {
                    if (vis[nf]) continue;
                    double dot = (double)fx*fn[nf*3] + (double)fy*fn[nf*3+1] + (double)fz*fn[nf*3+2];
                    if (dot >= cosCrease) { vis[nf] = 1; f2i[nf] = iId; Q.push_back(nf); }
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // Sortie INDEXÉE, regroupée par (vertex soudé, îlot) — pas par (face,
    // coin). Preuve : la normale calculée pour (v, iId) ne dépend QUE de
    // v et iId, jamais de quelle face a déclenché le calcul — deux faces
    // du MÊME îlot touchant le MÊME vertex soudé obtiennent, par construction
    // de la formule, exactement la même normale, à chaque fois.
    //
    // [PERF 07/08] Deux passes sur des buffers PLATS pré-dimensionnés, au
    // lieu d'un std::vector<std::vector<...>> par vertex — mesuré : la V1
    // (un vector separe par vertex, potentiellement des millions de petites
    // allocations heap individuelles) montrait un passage ×6 de temps pour
    // ×4 de travail (non-lineaire) entre 500x500 et 1000x1000 vertices.
    // Cette version : compter d'abord (aucune allocation), prefix-sum pour
    // connaitre la position exacte de chaque vertex dans UN SEUL buffer
    // final, puis remplir directement — deux allocations totales au lieu
    // de potentiellement des millions.
    // ─────────────────────────────────────────────────────────────────────

    // Passe 1 : compter les ilots distincts par vertex (aucune allocation,
    // juste des compteurs).
    std::vector<uint32_t> islCountPerVert(nV, 0);
    for (size_t v = 0; v < nV; v++) {
        for (uint32_t j = voff[v]; j < voff[v+1]; j++) {
            int32_t iId = f2i[lst[j]];
            bool already = false;
            for (uint32_t j2 = voff[v]; j2 < j; j2++) if (f2i[lst[j2]] == iId) { already = true; break; }
            if (!already) islCountPerVert[v]++;
        }
    }

    // Prefix-sum : ou commence la plage de chaque vertex dans le buffer plat.
    std::vector<uint32_t> vOff2(nV + 1, 0);
    for (size_t v = 0; v < nV; v++) vOff2[v+1] = vOff2[v] + islCountPerVert[v];
    uint32_t totalOutV = vOff2[nV];

    // Passe 2 : remplir directement les buffers finaux (position, normale)
    // ET le buffer plat de correspondance (ilot -> index de sortie), a la
    // bonne position, sans jamais reallouer.
    SmoothResult out;
    out.pos.resize(totalOutV * 3);
    out.nrm.resize(totalOutV * 3);
    out.idx.resize(nF * 3);
    std::vector<int32_t> flatIslandIds(totalOutV);   // ilot pour chaque entree plate
    std::vector<uint32_t> fillCursor(nV, 0);          // combien deja rempli pour ce vertex

    for (size_t v = 0; v < nV; v++) {
        for (uint32_t j = voff[v]; j < voff[v+1]; j++) {
            int32_t iId = f2i[lst[j]];
            bool already = false;
            for (uint32_t k = vOff2[v]; k < vOff2[v] + fillCursor[v]; k++)
                if (flatIslandIds[k] == iId) { already = true; break; }
            if (already) continue;

            double nx = 0, ny = 0, nz = 0;
            for (uint32_t j2 = voff[v]; j2 < voff[v+1]; j2++) {
                uint32_t af = lst[j2];
                if (f2i[af] == iId) {
                    double w = cornerAngleLocal(pos, idx, af, (uint32_t)v);
                    nx += fn[af*3] * w; ny += fn[af*3+1] * w; nz += fn[af*3+2] * w;
                }
            }
            double L = std::sqrt(nx*nx+ny*ny+nz*nz); if (L < 1e-20) L = 1.0;
            uint32_t slot = vOff2[v] + fillCursor[v];
            out.pos[slot*3]=pos[v*3]; out.pos[slot*3+1]=pos[v*3+1]; out.pos[slot*3+2]=pos[v*3+2];
            out.nrm[slot*3]=(float)(nx/L); out.nrm[slot*3+1]=(float)(ny/L); out.nrm[slot*3+2]=(float)(nz/L);
            flatIslandIds[slot] = iId;
            fillCursor[v]++;
        }
    }

    // Buffer d'index : chaque coin de triangle référence le vertex de
    // sortie partagé correspondant à (son vertex soudé, l'îlot de SA face).
    for (size_t f = 0; f < nF; f++) {
        int32_t iId = f2i[f];
        for (int vi = 0; vi < 3; vi++) {
            uint32_t v = idx[f*3+vi];
            for (uint32_t k = vOff2[v]; k < vOff2[v+1]; k++) {
                if (flatIslandIds[k] == iId) { out.idx[f*3+vi] = k; break; }
            }
        }
    }
    return out;
}

static int platformRecv(SocketFD fd, char* buf, size_t len) {
#ifdef _WIN32
    return recv(fd, buf, (int)len, 0);
#else
    return (int)recv(fd, buf, len, 0);
#endif
}
static int platformSend(SocketFD fd, const char* buf, size_t len) {
#ifdef _WIN32
    return send(fd, buf, (int)len, 0);
#else
    return (int)send(fd, buf, len, 0);
#endif
}
static bool readAll(SocketFD fd, char* buf, size_t n) {
    size_t got = 0;
    while (got < n) {
        int r = platformRecv(fd, buf + got, n - got);
        if (r <= 0) return false;
        got += (size_t)r;
    }
    return true;
}
static void writeAll(SocketFD fd, const char* buf, size_t n) {
    size_t sent = 0;
    while (sent < n) {
        int w = platformSend(fd, buf + sent, n - sent);
        if (w <= 0) return;
        sent += (size_t)w;
    }
}

struct HttpRequest {
    std::string method, path;
    size_t contentLength = 0;
    std::string body;
};

// Lit une requête HTTP/1.1 simple : ligne de méthode, headers jusqu'à \r\n\r\n,
// puis Content-Length octets de corps si présent. Suffisant pour GET/OPTIONS/POST
// sans corps chunké (fetch() du navigateur envoie un Content-Length explicite).
static bool readHttpRequest(SocketFD fd, HttpRequest& req) {
    std::string buf;
    // [PERF 18/08] 8 Ko -> 64 Ko : sur une grosse requete POST (STEP volumineux),
    // le debut du body arrive tres souvent dans le meme paquet/recv() que la fin
    // des headers — un chunk plus large capture plus de body des le premier tour
    // de cette boucle, moins de recv() au total. Comportement identique (simple
    // buffer de scan), juste moins de syscalls.
    char chunk[65536];
    size_t headerEnd = std::string::npos;
    while (headerEnd == std::string::npos) {
        int r = platformRecv(fd, chunk, sizeof(chunk));
        if (r <= 0) return false;
        buf.append(chunk, r);
        headerEnd = buf.find("\r\n\r\n");
        if (buf.size() > 16 * 1024 * 1024 && headerEnd == std::string::npos) return false; // headers déraisonnables
    }
    std::string headerPart = buf.substr(0, headerEnd);
    std::string already = buf.substr(headerEnd + 4);

    std::istringstream hs(headerPart);
    std::string line;
    std::getline(hs, line);
    if (!line.empty() && line.back() == '\r') line.pop_back();
    {
        std::istringstream ls(line);
        std::string httpver;
        ls >> req.method >> req.path >> httpver;
    }
    size_t contentLength = 0;
    while (std::getline(hs, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty()) continue;
        auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        std::string key = line.substr(0, colon);
        std::transform(key.begin(), key.end(), key.begin(), ::tolower);
        if (key == "content-length") {
            std::string val = line.substr(colon + 1);
            size_t p = val.find_first_not_of(" \t");
            // [28/08 AUDIT] Parsing manuel plutot que std::stoul, pour deux raisons.
            // (1) std::stoul LEVE (std::invalid_argument) sur un Content-Length non
            //     numerique. Cette exception remontait jusqu'a la boucle d'accept de
            //     main(), qui ne l'attrape pas -> std::terminate : le moteur
            //     s'eteignait sur une seule requete malformee. Un scan de port ou un
            //     client HTTP mal lune suffisait a tuer le process.
            // (2) std::stoul retourne un unsigned long, soit 32 BITS sous MSVC : un
            //     corps de plus de 4 Gio etait tronque silencieusement (le fichier
            //     documente lui-meme un cas reel a 1,3 Go, on n'est pas si loin).
            // Ici : aucune exception possible, size_t plein, arret propre au premier
            // caractere non numerique, et refus explicite en cas de debordement.
            if (p != std::string::npos) {
                size_t cl = 0; bool ok = false;
                for (size_t k = p; k < val.size(); k++) {
                    unsigned char c = (unsigned char)val[k];
                    if (c < '0' || c > '9') break;
                    size_t d = (size_t)(c - '0');
                    if (cl > (SIZE_MAX - d) / 10) { ok = false; break; }
                    cl = cl * 10 + d;
                    ok = true;
                }
                if (ok) contentLength = cl;
            }
        }
    }
    req.contentLength = contentLength;
    // [PERF 18/08] Lecture du reste du body DIRECTEMENT dans req.body — l'ancienne
    // version lisait dans un std::vector<char> rest temporaire PUIS le recopiait
    // via append(). Sur un gros STEP (le fichier documente lui-meme un cas reel a
    // 1,3 Go, Dante.step), ca faisait exister le corps en double en memoire (rest
    // ET req.body) le temps de l'append, plus un memcpy complet du corps entier.
    // resize() porte req.body a sa taille finale d'un coup, puis readAll() ecrit
    // directement dans son buffer interne (&req.body[haveSize]) — plus aucune
    // copie intermediaire, un seul exemplaire du corps a tout instant.
    req.body = std::move(already);
    if (req.body.size() < contentLength) {
        size_t haveSize = req.body.size();
        req.body.resize(contentLength);
        if (!readAll(fd, &req.body[haveSize], contentLength - haveSize)) return false;
    }
    return true;
}

static const char* CORS_HEADERS =
    "Access-Control-Allow-Origin: *\r\n"
    "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
    "Access-Control-Allow-Headers: *\r\n"
    "Access-Control-Allow-Private-Network: true\r\n";

// ─── Streaming HTTP chunked (Transfer-Encoding: chunked, RFC 7230) ───
// Permet d'émettre les meshes AU FIL de la tessellation, sans connaître la
// taille totale à l'avance : chaque chunk = taille hex + CRLF + data + CRLF,
// fin = "0\r\n\r\n". Le navigateur (fetch + ReadableStream) reçoit et peut
// afficher progressivement — supprime le "trou noir" entre la fin du calcul
// et l'arrivée du bloc NSTP complet, et le pic mémoire du gros buffer unique.
static void writeChunk(SocketFD fd, const uint8_t* data, size_t len) {
    if (len == 0) return;
    char head[32];
    int n = snprintf(head, sizeof(head), "%zx\r\n", len);
    writeAll(fd, head, n);
    writeAll(fd, (const char*)data, len);
    writeAll(fd, "\r\n", 2);
}
static void writeChunkStr(SocketFD fd, const std::string& s) {
    writeChunk(fd, (const uint8_t*)s.data(), s.size());
}
static void endChunks(SocketFD fd) { writeAll(fd, "0\r\n\r\n", 5); }

// Frame du protocole NSTS (NSTP-Stream) v1, émise par mesh :
//   [u32 jsonLen][json meta][pos float32...][idx uint32...]
// meta = {"name","color","posCount","idxCount"} ; frame finale = {"end":true,...}
// (jsonLen seul, sans binaire). Little-endian, comme NSTP.
static void writeMeshFrame(SocketFD fd, const MeshData& m) {
    std::ostringstream j;
    j << "{\"name\":\"" << jsonEscape(m.name) << "\",";
    if (m.hasColor) j << "\"color\":{\"r\":" << m.r << ",\"g\":" << m.g << ",\"b\":" << m.b << "},";
    else j << "\"color\":null,";
    // [27/08] Identique a encodeNSTP : les deux chemins (/step et /stepstream)
    // doivent emettre le meme champ, sinon le streaming perdrait les couleurs
    // par face que le mode classique conserve.
    if (!m.faces.empty()) {
        j << "\"faces\":[";
        for (size_t g = 0; g < m.faces.size(); g++) {
            if (g) j << ",";
            j << "[" << m.faces[g].r << "," << m.faces[g].g << "," << m.faces[g].b
              << "," << m.faces[g].start << "," << m.faces[g].count << "]";
        }
        j << "],";
    }
    j << "\"posCount\":" << m.positions.size() << ",\"idxCount\":" << m.indices.size() << "}";
    std::string js = j.str();
    uint32_t jl = (uint32_t)js.size();
    std::vector<uint8_t> frame(4 + jl + m.positions.size()*4 + m.indices.size()*4);
    frame[0]=jl&0xFF; frame[1]=(jl>>8)&0xFF; frame[2]=(jl>>16)&0xFF; frame[3]=(jl>>24)&0xFF;
    std::memcpy(frame.data()+4, js.data(), jl);
    std::memcpy(frame.data()+4+jl, m.positions.data(), m.positions.size()*4);
    std::memcpy(frame.data()+4+jl+m.positions.size()*4, m.indices.data(), m.indices.size()*4);
    writeChunk(fd, frame.data(), frame.size());
}
static void writeJsonFrame(SocketFD fd, const std::string& js) {
    uint32_t jl = (uint32_t)js.size();
    std::vector<uint8_t> frame(4 + jl);
    frame[0]=jl&0xFF; frame[1]=(jl>>8)&0xFF; frame[2]=(jl>>16)&0xFF; frame[3]=(jl>>24)&0xFF;
    std::memcpy(frame.data()+4, js.data(), jl);
    writeChunk(fd, frame.data(), frame.size());
}

static void sendResponse(SocketFD fd, int code, const char* status, const std::string& contentType,
                          const char* body, size_t bodyLen) {
    std::ostringstream head;
    head << "HTTP/1.1 " << code << " " << status << "\r\n"
         << CORS_HEADERS
         << "Content-Type: " << contentType << "\r\n"
         << "Content-Length: " << bodyLen << "\r\n"
         << "Connection: close\r\n\r\n";
    std::string h = head.str();
    writeAll(fd, h.data(), h.size());
    if (bodyLen) writeAll(fd, body, bodyLen);
}

// [v2.6] RAM VRAIMENT disponible, pas juste "libre". sysinfo().freeram sous
// Linux exclut le cache disque, que le noyau utilise agressivement mais
// recupere instantanement sous pression memoire — l'utiliser sous-estime
// gravement ce qui est reellement allouable. MemAvailable dans /proc/meminfo
// est calcule par le noyau lui-meme pour repondre exactement a cette
// question. Repli sur sysinfo().freeram si le fichier est illisible
// (non-Linux, conteneur restreint) — jamais d'echec silencieux total.
static long readAvailableRamMB() {
#ifdef _WIN32
    // Windows : GlobalMemoryStatusEx calcule deja, cote OS, l'equivalent exact
    // de MemAvailable (memoire physique reellement allouable, cache compris) —
    // pas besoin du double repli /proc/meminfo + sysinfo() de la branche Linux.
    MEMORYSTATUSEX statex;
    statex.dwLength = sizeof(statex);
    if (GlobalMemoryStatusEx(&statex))
        return (long)(statex.ullAvailPhys / (1024ULL*1024ULL));
    return 0; // aucune source disponible — le client doit gerer 0/absent proprement
#else
    // [v2.6] RAM VRAIMENT disponible, pas juste "libre". sysinfo().freeram sous
    // Linux exclut le cache disque, que le noyau utilise agressivement mais
    // recupere instantanement sous pression memoire — l'utiliser sous-estime
    // gravement ce qui est reellement allouable. MemAvailable dans /proc/meminfo
    // est calcule par le noyau lui-meme pour repondre exactement a cette
    // question. Repli sur sysinfo().freeram si le fichier est illisible
    // (non-Linux, conteneur restreint) — jamais d'echec silencieux total.
    std::ifstream f("/proc/meminfo");
    if (f) {
        std::string line;
        while (std::getline(f, line)) {
            if (line.rfind("MemAvailable:", 0) == 0) {
                std::istringstream iss(line.substr(13));
                long kb = 0;
                if (iss >> kb) return kb / 1024;
            }
        }
    }
    struct sysinfo si;
    if (sysinfo(&si) == 0) return (long)((si.freeram * (unsigned long long)si.mem_unit) / (1024ULL*1024ULL));
    return 0; // aucune source disponible — le client doit gerer 0/absent proprement
#endif
}

// [10/08] Journalisation fichier — sur demande de Nass : pouvoir interrompre un
// chargement qui bloque SANS perdre les infos de debogage precedant le blocage.
// Duplique chaque caractere ecrit sur std::cerr vers un fichier EN PLUS de la
// console — flush() a chaque sync() (donc a chaque endl/flush explicite deja
// present dans tout le code existant) pour que meme un arret brutal (Ctrl+C,
// fermeture de fenetre, kill) laisse les dernieres lignes intactes sur disque.
// Aucun appel std::cerr existant a modifier : rediriger UNE FOIS le streambuf
// de cerr au tout debut de main() suffit a capturer tout le fichier, present
// et futur.
// [12/08] Couleurs ANSI console — sur demande Nass, suite au rendu maquette
// (bandeau titre encadré + tags colorés) valide dans le chat. Detection isatty :
// jamais de code ANSI si stderr n'est pas un vrai terminal (redirection vers
// fichier/pipe) — comportement standard (git, ls --color=auto, etc.), evite de
// polluer une sortie non-interactive avec des sequences de controle illisibles.
// gUseColor determine UNE FOIS au demarrage (voir main()), jamais recalcule
// par ligne — cout nul en usage normal.
static bool gUseColor = false;
static const char* cOk()    { return gUseColor ? "\033[92m" : ""; }  // vert vif
// [28/08] Magenta vif reserve au NOM DU FICHIER importe, et a rien d'autre.
// Toutes les autres couleurs de ce fichier portent deja un STATUT (vert=ok,
// cyan=info/route, jaune=avertissement, rouge=erreur) : reutiliser l'une
// d'elles pour un nom de fichier lui ferait dire quelque chose de faux. Le
// magenta n'etait pas pris — il ne signifie donc que "c'est le fichier".
static const char* cFile()  { return gUseColor ? "\033[1;95m" : ""; } // magenta vif gras
static const char* cInfo()  { return gUseColor ? "\033[96m" : ""; }  // cyan vif
static const char* cWarn()  { return gUseColor ? "\033[93m" : ""; }  // jaune vif
static const char* cErr()   { return gUseColor ? "\033[91m" : ""; }  // rouge vif
static const char* cDim()   { return gUseColor ? "\033[90m" : ""; }  // gris
static const char* cBold()  { return gUseColor ? "\033[1;97m" : ""; }// blanc gras
static const char* cReset() { return gUseColor ? "\033[0m" : ""; }

// [14/08] gBarActive : declare plus haut (avant drawBarLine), gere par
// flushBuffer plus bas (voir son commentaire pour le mecanisme [15/08 FIX v2]
// a base de \r qui a remplace la coupure caractere par caractere d'origine).
// [15/08] Bufferisation — l'implementation d'origine n'appelait jamais setp(),
// donc CHAQUE caractere ecrit sur cerr declenchait un appel virtuel a
// overflow() (aucune zone tampon a remplir directement). Sur un gros
// assemblage multi-corps avec logging [COLOR]/[REPAIR] par piece, ca
// representait des dizaines de milliers d'appels virtuels rien que pour le
// logging. Ici : un vrai put-area (setp/pptr/epptr) de kBufSize octets ;
// overflow() n'est plus appele qu'une fois le tampon plein (ou a chaque sync,
// note : cerr est unitbuf par defaut, donc un sync implicite suit chaque
// operation << — le gain reel est proportionnel a la longueur moyenne d'un
// operande << , pas a kBufSize, mais reste un facteur x5 a x40 typique sur
// les lignes de ce fichier), avec une seule écriture groupee (sputn) par
// destination et par flush plutot qu'un sputc() par caractere.
// [15/08] mu_ ajoute — la tessellation STEP tourne desormais sur un pool de
// threads (cf. parallelForIndices plus bas) ; TOUS les points d'appel cerr
// atteignables depuis ces threads sont deja serialises via gConsoleMutex
// (verrouille AVANT que cerr ne soit touché), mais ce mutex interne est un
// filet de securite supplementaire — rend la classe sure par construction
// meme si un futur appel cerr oubliait gConsoleMutex, sans cout mesurable en
// usage normal (mutex non conteste = quelques dizaines de ns).
class TeeStreambuf : public std::streambuf {
public:
    TeeStreambuf(std::streambuf* console, std::streambuf* file)
        : console_(console), file_(file), atLineStart_(true), ansiState_(0) {
        setp(buffer_, buffer_ + kBufSize);
    }
protected:
    virtual int overflow(int c) override {
        std::lock_guard<std::mutex> lk(mu_);
        if (pptr() > pbase()) {
            flushBuffer(pbase(), pptr());
            setp(buffer_, buffer_ + kBufSize);
        }
        if (c == EOF) return !EOF;
        *pptr() = (char)c;
        pbump(1);
        return c;
    }
    virtual int sync() override {
        std::lock_guard<std::mutex> lk(mu_);
        if (pptr() > pbase()) {
            flushBuffer(pbase(), pptr());
            setp(buffer_, buffer_ + kBufSize);
        }
        int r1 = console_->pubsync();
        int r2 = file_->pubsync();
        return (r1 == 0 && r2 == 0) ? 0 : -1;
    }
private:
    static constexpr std::streamsize kBufSize = 4096;
    std::streambuf* console_;
    std::streambuf* file_;
    bool atLineStart_;
    int ansiState_;
    char buffer_[kBufSize];
    std::mutex mu_;

    // [15/08 FIX v2] Reecrit pour la barre a base de \r (plus d'ANSI). Applique
    // la logique caractere-par-caractere sur TOUT le tampon [first,last),
    // accumule le resultat par destination, puis n'ecrit qu'UNE fois par
    // destination (sputn groupe).
    //
    // Principe cle : cerr etant unitbuf, un sync() (donc UN appel a
    // flushBuffer) couvre exactement le contenu d'UN "std::cerr << ..."
    // complet — jamais un melange de deux appels distincts. drawBarLine()
    // commence TOUJOURS par '\r' ; aucun autre point d'appel de ce fichier
    // n'ecrit de \r sur cerr. Le premier octet du tampon suffit donc a
    // distinguer fiablement "ceci est une frame de barre" de "ceci est un log
    // normal" pour CET appel.
    //
    // Ancien mecanisme (jusqu'au 15/08) : pendant qu'une barre tournait,
    // gBarActive supprimait caractere par caractere tout log normal sur la
    // CONSOLE, sauf son \n final — qui, lui, passait toujours. Resultat :
    // chaque log supprime laissait une ligne vide sur la console (rien de
    // perdu dans medusa.log, mais l'affichage EN DIRECT se remplissait de
    // lignes vides des qu'une barre restait active pendant plusieurs logs
    // consecutifs — exactement le bug signale par Nass).
    //
    // Nouveau mecanisme : rien n'est jamais supprime. Si une frame de barre
    // est "ouverte" (gBarActive) au moment ou un log NORMAL arrive, on ferme
    // proprement cette ligne avec un vrai '\n' AVANT de laisser passer le
    // log — la barre reprendra sur sa propre ligne a la frame suivante. Le
    // log lui-meme part en entier, comme n'importe quel autre log.
    void flushBuffer(const char* first, const char* last) {
        if (first == last) return;

        // [15/08 FIX v4] Marqueur '\x01' = ecriture FICHIER UNIQUEMENT (voir
        // logFileOnly plus haut) — court-circuite tout le reste : jamais
        // touche a la console, jamais touche a gBarActive. Une barre en
        // cours sur la console continue de s'ecraser sur place sans se
        // soucier une seconde de ce que ce log envoie au fichier.
        if (*first == '\x01') {
            std::string fileOnlyAcc;
            fileOnlyAcc.reserve((size_t)(last - first) + 16);
            for (const char* p = first + 1; p != last; ++p) { // +1 : saute le marqueur
                char c = *p;
                if (atLineStart_) {
                    fileOnlyAcc += timestamp();
                    atLineStart_ = false;
                }
                fileOnlyAcc += c;
                if (c == '\n') atLineStart_ = true;
            }
            if (!fileOnlyAcc.empty()) file_->sputn(fileOnlyAcc.data(), (std::streamsize)fileOnlyAcc.size());
            return;
        }

        std::string consoleAcc, fileAcc;
        consoleAcc.reserve((size_t)(last - first) + 16);
        fileAcc.reserve((size_t)(last - first) + 16);

        bool isBarFrame = (*first == '\r');

        // Ferme une frame de barre restee ouverte avant tout contenu qui n'en
        // est pas une nouvelle. Cas particulier : le '\n' isole emis par
        // barPhaseStart() EST deja cette fermeture — pas de doublon dans ce cas.
        if (gBarActive && !isBarFrame) {
            if (!(last - first == 1 && *first == '\n')) {
                consoleAcc += '\n';
                fileAcc += '\n';
                atLineStart_ = true;
            }
            gBarActive = false;
        }

        for (const char* p = first; p != last; ++p) {
            char c = *p;

            if (isBarFrame && c == '\r') {
                // Debut/reecriture d'une frame : la console recoit le \r brut (le
                // mecanisme d'ecrasement sur place lui-meme, aucun ANSI requis) ;
                // le fichier recoit une NOUVELLE ligne horodatee a la place — une
                // ligne par frame, lisible dans medusa.log, comme avant le passage
                // au \r (aucune trace de \r cru dans le fichier).
                consoleAcc += '\r';
                atLineStart_ = true; // force l'horodatage FICHIER ci-dessous pour cette frame
                continue;
            }
            // [10/08] Horodatage automatique en tete de ligne — meme format que
            // NASSCAD ([HH:MM:SS]) pour permettre une analyse comparative directe
            // entre les deux logs. Pour une frame de barre, seul le FICHIER recoit
            // l'horodatage (la console redessine trop souvent pour que ce soit
            // lisible en direct — pur bruit visuel a chaque \r).
            if (atLineStart_) {
                std::string ts = timestamp();
                if (isBarFrame) fileAcc += '\n';
                fileAcc += ts;
                if (!isBarFrame) consoleAcc += ts;
                atLineStart_ = false;
            }
            // [12/08] Filtrage ANSI pour le fichier UNIQUEMENT — la console recoit
            // les couleurs (cOk/cInfo/cWarn/cErr, cf. plus haut : bandeau de
            // demarrage), mais medusa.log doit rester du texte brut lisible dans
            // Notepad. N'entre en jeu que pour les logs normaux : une frame de
            // barre ne contient jamais de sequence ANSI desormais.
            bool toFile = true;
            if (!isBarFrame) {
                if (ansiState_ == 0) {
                    if ((unsigned char)c == 0x1B) { ansiState_ = 1; toFile = false; }
                } else if (ansiState_ == 1) {
                    toFile = false;
                    ansiState_ = (c == '[') ? 2 : 0; // sequence non reconnue -> repli normal
                } else if (ansiState_ == 2) {
                    toFile = false;
                    if (c >= 0x40 && c <= 0x7E) ansiState_ = 0; // octet final CSI (ex: 'm')
                }
            }
            consoleAcc += c;
            if (toFile) fileAcc += c;
            if (c == '\n') atLineStart_ = true;
        }

        if (isBarFrame) gBarActive = true; // ligne encore "ouverte" sur la console jusqu'a la prochaine frame/fermeture

        if (!consoleAcc.empty()) console_->sputn(consoleAcc.data(), (std::streamsize)consoleAcc.size());
        if (!fileAcc.empty()) file_->sputn(fileAcc.data(), (std::streamsize)fileAcc.size());
    }
    static std::string timestamp() {
        auto now = std::chrono::system_clock::now();
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tmBuf{};
#ifdef _WIN32
        localtime_s(&tmBuf, &t); // Windows — equivalent thread-safe, ordre d'arguments inverse de localtime_r
#else
        localtime_r(&t, &tmBuf); // WSL/Linux — localtime_r thread-safe
#endif
        char buf[16];
        std::strftime(buf, sizeof(buf), "[%H:%M:%S]", &tmBuf);
        return std::string(buf);
    }
};

// [10/08] Detection dynamique du dossier Telechargements Windows, depuis WSL —
// sur demande de Nass (log accessible directement, pas enfoui dans WSL).
// JAMAIS de nom d'utilisateur code en dur (lecon apprise plusieurs fois cette
// nuit sur d'autres scripts) : interroge %USERPROFILE% via cmd.exe (toujours
// present sur Windows, aucun paquet WSL supplementaire requis), puis convertit
// en chemin WSL via wslpath (utilitaire natif WSL, pas un ajout externe).
// Repli sur chemin relatif (comportement precedent) si l'interop echoue pour
// N'IMPORTE QUELLE raison (interop desactive, cmd.exe introuvable, etc.) —
// jamais de log perdu, juste moins pratique a trouver dans ce cas.
// ═══════════════════════════════════════════════════════════════════════════
// [28/08] stepHeaderInfo — nom du fichier STEP importe, lu dans l'EN-TETE du
// fichier lui-meme.
//
// POURQUOI PAS LE VRAI NOM DE FICHIER. Le protocole ne le transporte pas : le
// client POSTe le buffer STEP brut, sans metadonnee. Le faire remonter aurait
// demande de propager le nom depuis le selecteur de fichier a travers
// _readStepFileOffloaded -> _readStepFileViaBooster(Stream) -> query string,
// donc modifier le client ET le serveur pour une ligne de log. Alors que
// l'information est DEJA dans les octets recus : tout fichier ISO 10303-21
// commence par un en-tete qui porte son propre nom.
//
//   ISO-10303-21;
//   HEADER;
//   FILE_DESCRIPTION((''),'2;1');
//   FILE_NAME('Scania-Engine-V8-XT-Turbo.step','2026-08-20T09:12:44',('Nasser'),
//             (''),'Open CASCADE STEP processor 7.7','SolidWorks 2023','');
//
// Arguments de FILE_NAME selon la norme : 1=name, 2=time_stamp, 3=author,
// 4=organization, 5=preprocessor_version, 6=originating_system, 7=authorisation.
// On prend le 1 (le nom) et le 6 (le logiciel d'origine — gratuit une fois
// qu'on parse, et il explique souvent les conventions de couleur du fichier).
//
// LIMITE ASSUMEE : c'est le nom AU MOMENT DE L'EXPORT, pas celui du fichier sur
// le disque. Un fichier renomme depuis affichera son ancien nom. C'est le prix
// du zero-changement-de-protocole, et ca reste plus informatif que rien.
//
// Robustesse : bornee aux premiers 64 Ko (l'en-tete est toujours en tete), ne
// leve jamais, rend des champs vides si le corps n'est pas du STEP (buffer
// compresse .stpz, POST hostile) — l'appelant affiche alors juste la taille.
// ═══════════════════════════════════════════════════════════════════════════
struct StepHeaderInfo { std::string name; std::string system; };

// [28/08 FIX] Deux corrections apres le premier fichier Inventor reel.
//
// (1) COMMENTAIRES ISO 10303-21. Part 21 autorise /* ... */ N'IMPORTE OU dans
//     la structure d'echange, et Autodesk Inventor annote chaque champ :
//        FILE_NAME('x.step','2018-..',(''),(''),'pp',/*originating_system*/'Inventor 2018','');
//     Le parseur accumulait ces commentaires dans la valeur, d'ou l'affichage
//     "/*originating_system*/Autodesk Inventor 2018". Il faut donc les sauter —
//     et les sauter VRAIMENT, avec un etat dedie : un commentaire peut contenir
//     une apostrophe (/* export de Nasser's */) qui ferait basculer l'etat
//     "chaine" et decalerait tous les arguments suivants.
//
// (2) RETOURS LIGNE DANS UNE CHAINE. Certains exporteurs cassent mecaniquement
//     les lignes d'en-tete a une colonne fixe, AU MILIEU du nom de fichier. Le
//     \n brut atterrissait dans la valeur, partait sur la console, et
//     TeeStreambuf — qui horodate en debut de ligne — coupait le nom en deux
//     avec un second horodatage ("[FILE] Engi" / "[..]ne V8-XT Turbo.step").
//     Regle generale qui en decoule : une valeur destinee a une ligne de log ne
//     doit JAMAIS contenir de caractere de controle. On les retire, et on borne
//     la longueur — un champ pathologique ne doit pas noyer la console.
//
// REGLE D'ACCUMULATION SIMPLIFIEE au passage : seul ce qui vient de l'INTERIEUR
// d'une chaine entre apostrophes, au niveau 0 de parenthesage, entre dans une
// valeur. Tout jeton nu ($, *, commentaire, espace) est ignore par construction
// — c'est ce qui rend (1) robuste plutot que rustine.

// Retire les caracteres de controle et borne la longueur, pour affichage.
static std::string sanitizeForLog(const std::string& in, size_t maxLen = 120) {
    std::string out;
    out.reserve(in.size());
    for (unsigned char c : in) {
        if (c < 0x20 || c == 0x7F) continue;   // \n, \r, \t, ESC...
        out += (char)c;
    }
    // "..." en ASCII plutot que l'ellipse U+2026 : \u2026 dans un litteral
    // etroit depend du jeu d'execution du compilateur (MSVC sans /utf-8 rale),
    // et une troncature de log ne merite pas ce risque.
    if (out.size() > maxLen) out = out.substr(0, maxLen - 3) + "...";
    return out;
}

static StepHeaderInfo stepHeaderInfo(const std::string& body) {
    StepHeaderInfo out;
    const size_t scan = std::min<size_t>(body.size(), 64 * 1024);
    size_t p = body.find("FILE_NAME", 0);
    if (p == std::string::npos || p >= scan) return out;
    p = body.find('(', p);
    if (p == std::string::npos) return out;
    p++;

    enum { CODE, STR, COMMENT } st = CODE;
    std::vector<std::string> args;
    std::string cur;
    int depth = 0;

    for (; p < scan && args.size() < 7; p++) {
        char c = body[p];

        if (st == COMMENT) {
            if (c == '*' && p + 1 < scan && body[p + 1] == '/') { st = CODE; p++; }
            continue;
        }
        if (st == STR) {
            if (c == '\'') {
                if (p + 1 < scan && body[p + 1] == '\'') { if (depth == 0) cur += '\''; p++; } // '' echappe
                else st = CODE;
            } else if (depth == 0) cur += c;   // contenu de chaine, niveau 0 uniquement
            continue;
        }
        // st == CODE
        if (c == '/' && p + 1 < scan && body[p + 1] == '*') { st = COMMENT; p++; continue; }
        if (c == '\'') { st = STR; continue; }
        if (c == '(') { depth++; continue; }
        if (c == ')') {
            if (depth == 0) { args.push_back(cur); break; }   // fin de FILE_NAME(...)
            depth--; continue;
        }
        if (c == ',' && depth == 0) { args.push_back(cur); cur.clear(); continue; }
        // Tout le reste au niveau 0 hors chaine ($, *, espaces) : ignore.
    }

    if (!args.empty()) {
        std::string n = sanitizeForLog(args[0]);
        // Certains exporteurs ecrivent un chemin complet : on ne garde que le
        // nom de base, seule partie utile dans une ligne de log.
        size_t slash = n.find_last_of("/\\");
        if (slash != std::string::npos) n = n.substr(slash + 1);
        out.name = n;
    }
    if (args.size() >= 6) out.system = sanitizeForLog(args[5], 60);
    return out;
}

// Taille lisible — evite "365572 KB" quand "357.0 MB" dit la meme chose.
static std::string humanBytes(size_t n) {
    char buf[64];
    if (n >= 1024ull * 1024 * 1024) std::snprintf(buf, sizeof(buf), "%.2f GB", n / (1024.0 * 1024 * 1024));
    else if (n >= 1024ull * 1024)   std::snprintf(buf, sizeof(buf), "%.1f MB", n / (1024.0 * 1024));
    else if (n >= 1024)             std::snprintf(buf, sizeof(buf), "%.1f KB", n / 1024.0);
    else                            std::snprintf(buf, sizeof(buf), "%zu B", n);
    return std::string(buf);
}

// Ligne d'annonce commune a /step et /stepstream, emise DES l'arrivee de la
// requete — donc juste sous "Ready." au premier import, avant la barre PARSING.
static void logStepFileBanner(const std::string& body, const char* route) {
    StepHeaderInfo h = stepHeaderInfo(body);
    std::ostringstream oss;
    oss << cInfo() << "[FILE]" << cReset() << " "
        << cFile() << (h.name.empty() ? "(nom absent de l'en-tete STEP)" : h.name) << cReset()
        << cDim() << "  " << humanBytes(body.size());
    if (!h.system.empty()) oss << "  |  " << h.system;
    oss << "  |  " << route << cReset() << "\n";
    std::cerr << oss.str();
}

// [28/08] Horodatage pour NOM DE FICHIER : YYYY-MM-DD_HH-MM-SS, heure locale.
// Strictement le meme format que _fmtLogFilename() dans nasscad_logs.js — les
// deux journaux d'une session doivent porter le meme cachet.
static std::string logFileStamp() {
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    std::tm tmBuf{};
#ifdef _WIN32
    localtime_s(&tmBuf, &t);
#else
    localtime_r(&t, &tmBuf);
#endif
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d_%H-%M-%S", &tmBuf);
    return std::string(buf);
}

static std::string getWindowsDownloadsPath() {
#ifdef _WIN32
    // Windows natif : %USERPROFILE% est deja un chemin Windows direct — le
    // detour cmd.exe + wslpath de la branche ci-dessous n'existe que pour
    // traverser la frontiere WSL->Windows, inutile ici (meme demarche que
    // l'ancien "echo %USERPROFILE%", juste sans le relais de sous-systeme).
    const char* profile = std::getenv("USERPROFILE");
    if (!profile || !*profile) return "";
    return std::string(profile) + "\\Downloads";
#else
    FILE* pipe1 = popen("cmd.exe /c \"echo %USERPROFILE%\" 2>/dev/null", "r");
    if (!pipe1) return "";
    char buf[512];
    std::string winPath;
    if (fgets(buf, sizeof(buf), pipe1)) winPath = buf;
    pclose(pipe1);
    while (!winPath.empty() && (winPath.back()=='\n' || winPath.back()=='\r')) winPath.pop_back();
    if (winPath.empty() || winPath.find("%USERPROFILE%") != std::string::npos) return ""; // echo non substitue = echec

    std::string cmd2 = "wslpath \"" + winPath + "\" 2>/dev/null";
    FILE* pipe2 = popen(cmd2.c_str(), "r");
    if (!pipe2) return "";
    std::string wslPath;
    if (fgets(buf, sizeof(buf), pipe2)) wslPath = buf;
    pclose(pipe2);
    while (!wslPath.empty() && (wslPath.back()=='\n' || wslPath.back()=='\r')) wslPath.pop_back();
    if (wslPath.empty()) return "";

    return wslPath + "/Downloads";
#endif
}

// [15/08] Mode diagnostic CLI "--decode-colors fichier.step" -- reutilise
// collectLeaves(), LA MEME fonction qu'utilise processStepBuffer() pour
// resoudre les couleurs d'une vraie requete /step : donc AUCUN risque de
// divergence entre ce que ce mode affiche et ce que le serveur fera
// reellement, aujourd'hui et apres n'importe quelle future modification de
// collectLeaves() -- contrairement a un outil standalone separe (teste le
// 15/08, voir decode_couleurs_step.cpp) qui doit etre maintenu a la main en
// parallele.
// [CORRIGE 26/08] L'ancien commentaire affirmait ici que "les composantes
// renvoyees par Quantity_Color sont deja celles qu'OCCT a resolues depuis le
// fichier" : c'etait faux depuis OCCT 7.5 (stockage lineaire), et ce mode
// diagnostic affichait donc des valeurs qui n'etaient pas celles du fichier --
// ce qui a valide plusieurs fausses pistes. La sortie passe desormais par
// occtColorToSRGB() (cf. sa doc), comme le reste du pipeline. Usage :
//   ./nasscad_medusa --decode-colors fichier.step
// Lit le fichier sur disque (pas depuis une requete HTTP), n'ouvre PAS le
// port serveur, n'ecrit PAS medusa.log — juste la resolution, puis quitte.
static int runDecodeColorsCli(const std::string& stepPath) {
    std::ifstream f(stepPath, std::ios::binary);
    if (!f) {
        std::cerr << cWarn() << "[ERROR]" << cReset() << " file not found: " << stepPath << "\n";
        return 1;
    }
    std::ostringstream ss;
    ss << f.rdbuf();
    std::string body = ss.str();

    Handle(XCAFApp_Application) app = XCAFApp_Application::GetApplication();
    Handle(TDocStd_Document) doc;
    app->NewDocument("MDTV-XCAF", doc);

    STEPCAFControl_Reader caf;
    caf.SetNameMode(Standard_True);
    caf.SetColorMode(Standard_True);
    caf.SetLayerMode(Standard_False);
    caf.SetGDTMode(Standard_False);

    std::istringstream stream(body, std::ios::binary);
    IFSelect_ReturnStatus stat = caf.ChangeReader().ReadStream("decode_input.step", stream);
    if (stat != IFSelect_RetDone) {
        std::cerr << cWarn() << "[ERROR]" << cReset() << " STEP read failed (corrupted or non-STEP file?)\n";
        return 1;
    }
    if (!caf.Transfer(doc)) {
        std::cerr << cWarn() << "[ERROR]" << cReset() << " XCAF transfer failed\n";
        return 1;
    }

    Handle(XCAFDoc_ShapeTool) shapeTool = XCAFDoc_DocumentTool::ShapeTool(doc->Main());
    Handle(XCAFDoc_ColorTool) colorTool = XCAFDoc_DocumentTool::ColorTool(doc->Main());
    TDF_LabelSequence freeShapes;
    shapeTool->GetFreeShapes(freeShapes);

    std::vector<LeafShape> leaves;
    for (Standard_Integer i = 1; i <= freeShapes.Length(); i++) {
        collectLeaves(shapeTool, colorTool, freeShapes.Value(i), TopLoc_Location(), leaves, 0);
    }

    std::cerr << cBold() << "--- " << stepPath << " : " << leaves.size() << " part(s) ---" << cReset() << "\n";
    int nColored = 0;
    char line[256];
    for (auto& leaf : leaves) {
        if (leaf.color) {
            // [26/08] sRGB : ces valeurs doivent maintenant correspondre EXACTEMENT
            // au COLOUR_RGB lisible en clair dans le fichier STEP. C'est le critere
            // de validation de toute la chaine couleur.
            double r, g, b;
            occtColorToSRGB(*leaf.color, r, g, b);
            int r255 = (int)std::lround(r * 255.0), g255 = (int)std::lround(g * 255.0), b255 = (int)std::lround(b * 255.0);
            std::snprintf(line, sizeof(line),
                "  \"%.60s\" : floats=(%.6f, %.6f, %.6f)  RGB=(%d,%d,%d)  #%02X%02X%02X",
                leaf.name.c_str(), r, g, b, r255, g255, b255, r255, g255, b255);
            std::cerr << cOk() << line << cReset() << "\n";
            nColored++;
        } else {
            std::snprintf(line, sizeof(line), "  \"%.60s\" : no color found (label/proto/face all empty)", leaf.name.c_str());
            std::cerr << cWarn() << line << cReset() << "\n";
        }
    }
    std::cerr << cBold() << "--- " << nColored << "/" << leaves.size() << " part(s) colored ---" << cReset() << "\n";
    return 0;
}

// ═══════════════════════════════════════════════════════════════════════════
// [27/08] CSG — soudure des vertices par position, HISSEE au scope fichier.
// Etait une lambda locale au handler POST /csg ; /csgtree (juste en dessous)
// en a besoin sur chaque feuille de l arbre, et dupliquer 35 lignes d open
// addressing quantifie serait le meilleur moyen de laisser les deux copies
// diverger au prochain reglage de tolerance. Corps INCHANGE, seule la portee
// change — /csg appelle desormais cette fonction au lieu de sa lambda.
//
// Necessaire car les geometries THREE.js (SphereGeometry, CylinderGeometry...)
// dupliquent des vertices geometriquement identiques a la couture UV (indices
// differents, meme position) pour porter des coordonnees de texture distinctes.
// Manifold verifie le manifold par ADJACENCE D INDEX, pas par coincidence de
// position -- la couture non soudee ressemble alors a une frontiere d aretes
// nues -> MANIFOLD_NOT_MANIFOLD systematique sur toute sphere/cylindre envoye
// tel quel. Meme technique que le weld deja optimise cote NASSCAD (open
// addressing + comparaison EXACTE des coordonnees quantifiees, pas le hash
// seul comme cle -- evite les faux-positifs de collision).
// ═══════════════════════════════════════════════════════════════════════════
static void weldMeshForCSG(std::vector<float>& pos, std::vector<uint32_t>& idx) {
    const double tol = 1e-4;
    size_t nVert = pos.size() / 3;
    auto quant = [&](float v){ return (int32_t)std::llround((double)v / tol); };
    std::vector<int32_t> qx(nVert), qy(nVert), qz(nVert);
    for (size_t i = 0; i < nVert; i++) {
        qx[i] = quant(pos[i*3]); qy[i] = quant(pos[i*3+1]); qz[i] = quant(pos[i*3+2]);
    }
    size_t cap = 1; while (cap < nVert * 2) cap <<= 1;
    size_t mask = cap - 1;
    std::vector<int32_t> table(cap, -1);
    std::vector<uint32_t> remap(nVert);
    std::vector<float> welded; welded.reserve(pos.size());
    for (size_t i = 0; i < nVert; i++) {
        size_t h = ((uint32_t)qx[i]*73856093u ^ (uint32_t)qy[i]*19349663u ^ (uint32_t)qz[i]*83492791u) & mask;
        for (;;) {
            int32_t s = table[h];
            if (s == -1) {
                table[h] = (int32_t)i;
                remap[i] = (uint32_t)(welded.size() / 3);
                welded.push_back(pos[i*3]); welded.push_back(pos[i*3+1]); welded.push_back(pos[i*3+2]);
                break;
            }
            if (qx[s]==qx[i] && qy[s]==qy[i] && qz[s]==qz[i]) { remap[i] = remap[s]; break; }
            h = (h + 1) & mask;
        }
    }
    for (auto& v : idx) v = remap[v];
    pos = std::move(welded);
}

// ═══════════════════════════════════════════════════════════════════════════
// [27/08] ARBRE CSG NATIF — support de POST /csgtree.
//
// RAISON D ETRE. Le Deep Re-run cote client (_deepRerunNode) ne produit pas
// une liste plate d operandes mais un ARBRE : chaque noeud est un booleen dont
// les enfants peuvent etre eux-memes des booleens. Jusqu ici cet arbre partait
// au Worker Manifold WASM (_workerCSGTree), seul chemin capable de garder les
// objets Manifold VIVANTS entre deux niveaux. Le deporter naivement sur /csg
// aurait impose un aller-retour HTTP par noeud, et surtout un cycle
// extract-meshgl -> re-weld -> reconstruction Manifold a CHAQUE niveau : sur un
// arbre a N noeuds internes, N-1 allers-retours ET N-1 reconstructions
// inutiles — exactement ce que la fusion cote WASM avait supprime.
//
// Ici le meme principe, en natif : l arbre entier arrive en UNE requete, est
// evalue en post-ordre, et les ManifoldManifold* intermediaires restent en
// memoire d un niveau au suivant. Un seul manifold_get_meshgl, a la racine.
//
// PROTOCOLE (little-endian, meme esprit binaire que /csg) :
//   [u32 magic 'CTRE' = 0x45525443][u32 version = 1] puis UN noeud recursif :
//   NOEUD = [u32 kind]
//     kind 0 (feuille)  : [u32 nVert][u32 nTri][f32 nVert*3][u32 nTri*3]
//     kind 1 (interne)  : [u32 opType 0=union/1=subtract/2=intersect]
//                         [u32 solidsCount][u32 childCount] puis childCount NOEUDs
//   solidsCount : nombre d enfants EN TETE a unioner entre eux pour former la
//   cible avant soustraction — meme semantique exacte que le champ du meme nom
//   dans /csg (le client reordonne les enfants solides-d abord quand hasMix).
// Reponse : STRICTEMENT le meme cadre que /csg (u32 jsonLen + JSON + positions
// f32 + indices u32) — le decodeur client est partage, rien a ecrire en plus.
// ═══════════════════════════════════════════════════════════════════════════
struct CsgTreeNode {
    bool leaf = true;
    std::vector<float>    pos;      // feuille uniquement
    std::vector<uint32_t> idx;      // feuille uniquement
    uint32_t opType = 0;            // noeud interne uniquement
    uint32_t solidsCount = 1;       // noeud interne uniquement
    std::vector<CsgTreeNode> children;
};

// Garde-fous de PARSING (pas des limites metier) : un arbre legitime issu de
// _buildTreePayload est borne par la profondeur d imbrication CSG reelle et par
// le nombre d objets de la scene. Ces bornes ne sont la que pour qu un u32
// corrompu ne fasse pas exploser la pile ni allouer a l infini — meme role que
// le "operandCount > bodySize/8" de /csg.
static const uint32_t CSGTREE_MAX_DEPTH = 256;
static const uint32_t CSGTREE_MAX_NODES = 1000000;

static void parseCsgTreeNode(const std::string& b, size_t& off, CsgTreeNode& out,
                             uint32_t depth, uint32_t& nodeCount, uint32_t& leafCount) {
    if (depth > CSGTREE_MAX_DEPTH) throw std::runtime_error("/csgtree: tree deeper than 256 levels (corrupt payload?)");
    if (++nodeCount > CSGTREE_MAX_NODES) throw std::runtime_error("/csgtree: node count out of bounds (corrupt payload?)");
    auto rdU32 = [&]()->uint32_t{
        if (off + 4 > b.size()) throw std::runtime_error("/csgtree: out-of-bounds read");
        uint32_t v; std::memcpy(&v, b.data()+off, 4); off += 4; return v;
    };
    uint32_t kind = rdU32();
    if (kind == 0) {
        leafCount++;
        out.leaf = true;
        uint32_t nVert = rdU32(), nTri = rdU32();
        size_t vBytes = (size_t)nVert * 3 * 4, iBytes = (size_t)nTri * 3 * 4;
        if (off + vBytes + iBytes > b.size()) throw std::runtime_error("/csgtree: truncated leaf mesh");
        const float* vp = reinterpret_cast<const float*>(b.data() + off); off += vBytes;
        const uint32_t* ip = reinterpret_cast<const uint32_t*>(b.data() + off); off += iBytes;
        out.pos.assign(vp, vp + (size_t)nVert * 3);
        out.idx.assign(ip, ip + (size_t)nTri * 3);
        return;
    }
    if (kind != 1) throw std::runtime_error("/csgtree: unknown node kind (corrupt payload?)");
    out.leaf = false;
    out.opType = rdU32();
    if (out.opType > 2) throw std::runtime_error("/csgtree: invalid opType");
    out.solidsCount = rdU32();
    uint32_t childCount = rdU32();
    if (childCount < 1) throw std::runtime_error("/csgtree: internal node with no child");
    // Chaque enfant occupe au minimum 4 octets (son champ kind) : un childCount
    // superieur au reste du corps est forcement un u32 corrompu.
    if ((size_t)childCount > (b.size() - off) / 4 + 1) throw std::runtime_error("/csgtree: childCount inconsistent with request size");
    if (out.opType == 1 && childCount >= 2 && (out.solidsCount < 1 || out.solidsCount >= childCount))
        throw std::runtime_error("/csgtree: invalid solidsCount for subtract (must be in [1, childCount-1])");
    out.children.resize(childCount);
    for (uint32_t i = 0; i < childCount; i++)
        parseCsgTreeNode(b, off, out.children[i], depth + 1, nodeCount, leafCount);
}

// Collecte a plat les feuilles (pointeurs dans l arbre) — permet de souder en
// parallele avant toute construction Manifold. La soudure est du C++ pur sur
// des buffers disjoints : parallelisable sans partage d etat. La construction
// Manifold elle-meme reste sequentielle (comme dans /csg), et le parallelisme
// des booleens vient de manifold_batch_boolean (TBB interne, MANIFOLD_PAR=1) —
// pas de threads imbriques, pas de sur-souscription.
static void collectCsgTreeLeaves(CsgTreeNode& n, std::vector<CsgTreeNode*>& out) {
    if (n.leaf) { out.push_back(&n); return; }
    for (auto& c : n.children) collectCsgTreeLeaves(c, out);
}

// ─────────────────────────────────────────────────────────────────────────
// [01/09] ManifoldArena — proprietaire unique des buffers Manifold d'une
// requete. Remplace les std::vector<void*> + boucles de free() manuelles, qui
// avaient deux defauts distincts :
//
//  (1) FUITE SUR CHEMIN D'ERREUR. Les free() etaient les dernieres instructions
//      DANS le try. Toute exception levee avant eux les sautait et abandonnait
//      l'arene entiere. Un destructeur, lui, s'execute pendant le depilage : il
//      n'existe plus de sortie de bloc sans liberation.
//
//  (2) DESTRUCTEUR JAMAIS APPELE — et celui-la fuyait AUSSI en cas de succes.
//      L'API C construit par placement (manifoldc.cpp : new (mem) Manifold(m)),
//      donc free(mem) rend la coquille mais n'execute pas ~Manifold() : les
//      vecteurs internes (positions, index, halfedges) restaient alloues. Le
//      plus couteux etait memOut : manifold_get_meshgl() COPIE tout le maillage
//      resultat dans un MeshGL, dont on ne relachait que l'enveloppe — soit la
//      taille du resultat perdue a chaque /csg reussi. manifold_destruct_*()
//      existe exactement pour ca (manifoldc.cpp:1104, from_c(m)->~Manifold())
//      et n'etait appele nulle part dans ce fichier.
//
// L'ORDRE COMPTE. Construction d'abord, prise de propriete ENSUITE. Un
// constructeur qui leve — manifold_of_meshgl() fait une copie de Manifold, donc
// il le peut — laisserait sinon dans l'arene un buffer non construit, sur
// lequel ~Manifold() irait dereferencer des pointeurs au hasard : on aurait
// troque une fuite contre un plantage. make() impose cet ordre par
// construction : le buffer est d'abord enregistre en BRUT (free seul, toujours
// sur), et n'est arme du bon destructeur qu'au retour du constructeur.
//
// Le destructeur a appeler n'est pas choisi a la main : la surcharge de
// dtorFor() l'apparie au type de retour du constructeur, donc c'est le
// compilateur qui garantit qu'un ManifoldMeshGL ne recevra jamais
// ~Manifold(). Liberation en ordre inverse de creation.
class ManifoldArena {
public:
    ManifoldArena() = default;
    ManifoldArena(const ManifoldArena&)            = delete;
    ManifoldArena& operator=(const ManifoldArena&) = delete;
    ~ManifoldArena() { reset(); }

    // Buffer brut, sans destructeur : les tableaux de float/uint32 remplis par
    // manifold_meshgl_vert_properties() & co sont du POD, free() suffit.
    void* raw(size_t bytes) {
        // bytes == 0 est LEGITIME ici : un resultat vide (subtract qui consomme
        // entierement la cible — cas explicitement journalise "isEmpty") demande
        // un tampon de zero octet, jamais lu ensuite. malloc(0) a le droit de
        // rendre NULL ; le refuser ferait echouer en 500 une requete valide.
        void* p = malloc(bytes);
        if (!p && bytes) throw std::bad_alloc();
        slots_.push_back(Slot{ p, nullptr });
        return p;
    }

    // Alloue `bytes`, appelle `ctor(buffer)`, prend possession du resultat.
    template <class Ctor>
    auto make(size_t bytes, Ctor ctor) -> decltype(ctor((void*)nullptr)) {
        void* p = malloc(bytes);
        if (!p) throw std::bad_alloc();   // ici bytes = manifold_*_size(), jamais 0
        slots_.push_back(Slot{ p, nullptr });
        const size_t idx = slots_.size() - 1;
        auto* obj = ctor(p);           // peut lever : le slot reste "brut", donc
        slots_[idx].dtor = dtorFor(obj); // simplement free() — jamais ~T() sur du vide.
        return obj;
    }

    void reset() {
        for (size_t i = slots_.size(); i-- > 0; ) {
            if (slots_[i].dtor) slots_[i].dtor(slots_[i].p);
            free(slots_[i].p);   // free(NULL) est un no-op — cf. raw(0)
        }
        slots_.clear();
    }

private:
    typedef void (*DtorFn)(void*);
    struct Slot { void* p; DtorFn dtor; };
    std::vector<Slot> slots_;

    static void dtorManifold(void* p)    { manifold_destruct_manifold((ManifoldManifold*)p); }
    static void dtorManifoldVec(void* p) { manifold_destruct_manifold_vec((ManifoldManifoldVec*)p); }
    static void dtorMeshGL(void* p)      { manifold_destruct_meshgl((ManifoldMeshGL*)p); }

    static DtorFn dtorFor(ManifoldManifold*)    { return &dtorManifold; }
    static DtorFn dtorFor(ManifoldManifoldVec*) { return &dtorManifoldVec; }
    static DtorFn dtorFor(ManifoldMeshGL*)      { return &dtorMeshGL; }
};

// Evaluation post-ordre. Retourne un ManifoldManifold* dont la duree de vie est
// celle de `mem` (libere par l appelant en fin de requete). Les intermediaires
// ne sont JAMAIS extraits en meshgl : c est tout l interet de l endpoint.
static ManifoldManifold* evalCsgTreeNode(CsgTreeNode& n, ManifoldArena& mem) {
    if (n.leaf) {
        ManifoldMeshGL* mg = mem.make(manifold_meshgl_size(), [&](void* p){
            return manifold_meshgl(p, n.pos.data(), n.pos.size()/3, 3,
                                   n.idx.data(), n.idx.size()/3); });
        return mem.make(manifold_manifold_size(), [&](void* p){
            return manifold_of_meshgl(p, mg); });
    }

    std::vector<ManifoldManifold*> kids;
    kids.reserve(n.children.size());
    for (auto& c : n.children) kids.push_back(evalCsgTreeNode(c, mem));

    // Un seul enfant : rien a combiner, le noeud est transparent. Cas produit
    // par un sous-arbre dont les freres ont ete absorbes par le bypass
    // trivial-union cote client.
    if (kids.size() == 1) return kids[0];

    ManifoldOpType mop = n.opType == 0 ? MANIFOLD_ADD : n.opType == 1 ? MANIFOLD_SUBTRACT : MANIFOLD_INTERSECT;

    if (n.opType == 1) {
        // Subtract : non-commutatif, manifold_batch_boolean ne le supporte pas.
        // Meme identite ensembliste que dans /csg : (S1 u S2 u ..) - (H1 u H2 u ..).
        size_t sc = (size_t)n.solidsCount;
        if (sc < 1) sc = 1;
        if (sc >= kids.size()) sc = kids.size() - 1;
        ManifoldManifold* target;
        if (sc > 1) {
            ManifoldManifoldVec* solidVec = mem.make(manifold_manifold_vec_size(),
                [&](void* p){ return manifold_manifold_empty_vec(p); });
            for (size_t i = 0; i < sc; i++) manifold_manifold_vec_push_back(solidVec, kids[i]);
            target = mem.make(manifold_manifold_size(), [&](void* p){
                return manifold_batch_boolean(p, solidVec, MANIFOLD_ADD); });
        } else {
            target = kids[0];
        }
        ManifoldManifoldVec* subVec = mem.make(manifold_manifold_vec_size(),
            [&](void* p){ return manifold_manifold_empty_vec(p); });
        for (size_t i = sc; i < kids.size(); i++) manifold_manifold_vec_push_back(subVec, kids[i]);
        ManifoldManifold* subtrahends = mem.make(manifold_manifold_size(), [&](void* p){
            return manifold_batch_boolean(p, subVec, MANIFOLD_ADD); });
        return mem.make(manifold_manifold_size(), [&](void* p){
            return manifold_boolean(p, target, subtrahends, MANIFOLD_SUBTRACT); });
    }

    // Union / Intersect : commutatifs -> batch natif (tri par taille + TBB).
    ManifoldManifoldVec* vec = mem.make(manifold_manifold_vec_size(),
        [&](void* p){ return manifold_manifold_empty_vec(p); });
    for (auto* k : kids) manifold_manifold_vec_push_back(vec, k);
    return mem.make(manifold_manifold_size(), [&](void* p){
        return manifold_batch_boolean(p, vec, mop); });
}

// ─────────────────────────────────────────────────────────────────────────
// [31/08] Mode "--selftest-colors" — banc d'essai de decideBodyColor().
//
//     ./nasscad_medusa --selftest-colors
//
// Ni fichier, ni document XCAF, ni serveur : quelques millisecondes, et ca dit
// si un remaniement a casse la table de decision couleur. Les cas ne sont pas
// inventes — ce sont les configurations reellement relevees dans
// Scania-Engine-V8-XT-Turbo.step par lecture directe du Part21 :
//   15 176 STYLED_ITEM, dont 14 921 sur des ADVANCED_FACE et 254 sur des
//   solides ; 98 corps sur 254 avec une couleur de solide en contradiction
//   avec celle de leurs faces, dont 53 en jaune #DDDD0D — le jaune vif observe
//   a l'ecran et absent de FreeCAD.
//
// Le premier cas verifie aussi l'aller-retour sRGB d'occtColorToSRGB : si un
// jour quelqu'un remplace la courbe par un gamma maison, il tombe ici.
// ─────────────────────────────────────────────────────────────────────────
static std::string colorToHex(const Quantity_Color& c) {
    double v[3];
    occtColorToSRGB(c, v[0], v[1], v[2]);
    static const char* H = "0123456789ABCDEF";
    std::string s = "#";
    for (int i = 0; i < 3; i++) {
        int n = (int)std::lround(v[i] * 255.0);
        if (n < 0) n = 0;
        if (n > 255) n = 255;
        s += H[n >> 4];
        s += H[n & 15];
    }
    return s;
}

static int runColorSelfTestCli() {
    const Quantity_Color JAUNE (0.866667, 0.866667, 0.050980, Quantity_TOC_sRGB); // #DDDD0D
    const Quantity_Color GRIS  (0.352941, 0.384314, 0.400000, Quantity_TOC_sRGB); // #5A6266
    const Quantity_Color ORANGE(0.811765, 0.309804, 0.000000, Quantity_TOC_sRGB); // #CF4F00

    int fails = 0;
    auto pad = [](std::string s, size_t n) { while (s.size() < n) s += ' '; return s; };

    auto scanOf = [](size_t nFaces, size_t nStyled, bool uniform,
                     std::optional<Quantity_Color> first) {
        FaceScan s;
        s.nFaces = nFaces; s.nStyled = nStyled; s.uniform = uniform; s.first = first;
        if (nStyled) s.map = std::make_shared<FaceColorMap>();
        return s;
    };
    auto check = [&](const char* nom, const ColorDecision& d,
                     const char* attCol, bool attMap, const char* attPath) {
        std::string got = d.col ? colorToHex(*d.col) : "(none)";
        bool ok = got == attCol && d.useFaceMap == attMap && std::string(d.path) == attPath;
        if (!ok) fails++;
        std::cout << (ok ? " ok  " : "FAIL ") << pad(nom, 46)
                  << " colour=" << pad(got, 9)
                  << " map=" << (d.useFaceMap ? "yes" : "no")
                  << " path=" << d.path << "\n";
        if (!ok) std::cout << "        expected : colour=" << attCol
                           << " map=" << (attMap ? "yes" : "no")
                           << " path=" << attPath << "\n";
    };

    std::cout << "\n[selftest] sRGB round-trip (occtColorToSRGB)\n";
    for (auto& p : { std::make_pair(&JAUNE, "#DDDD0D"), std::make_pair(&GRIS, "#5A6266"),
                     std::make_pair(&ORANGE, "#CF4F00") }) {
        std::string got = colorToHex(*p.first);
        bool ok = got == p.second;
        if (!ok) fails++;
        std::cout << (ok ? " ok  " : "FAIL ") << pad(got, 9) << " expected " << p.second << "\n";
    }

    std::cout << "\n[selftest] decision table (decideBodyColor)\n";
    const char* LBL = "label-inst-Surf";

    check("no styled face, yellow solid",
          decideBodyColor(scanOf(3, 0, true, {}), JAUNE, LBL),
          "#DDDD0D", false, LBL);

    // LE cas du bug : brep#3328 — 649 faces grises sous un solide jaune.
    check("all faces grey, yellow solid (the bug)",
          decideBodyColor(scanOf(649, 649, true, GRIS), JAUNE, LBL),
          "#5A6266", false, "face-uniform-override");

    // brep#2950 — 1751 faces orange + 22 autres, solide jaune : multicolore.
    check("faces orange+grey, yellow solid (brep#2950)",
          decideBodyColor(scanOf(1773, 1773, false, ORANGE), JAUNE, LBL),
          "#DDDD0D", true, LBL);

    // Une seule face stylee parmi 500 nues : la carte doit survivre.
    check("1 grey face / 500 bare, yellow solid",
          decideBodyColor(scanOf(500, 1, true, GRIS), JAUNE, LBL),
          "#DDDD0D", true, LBL);

    check("no solid colour, uniform faces",
          decideBodyColor(scanOf(12, 12, true, ORANGE), {}, "none"),
          "#CF4F00", false, "face-uniform");

    // Cas PCB (Stealthburner, valide le 13/08) : le label parent n'a pas de
    // couleur, chaque sous-solide porte la sienne. Comportement d'avant, intact.
    check("no solid colour, mixed faces (PCB)",
          decideBodyColor(scanOf(10, 10, false, ORANGE), {}, "none"),
          "#CF4F00", true, "face-first");

    check("no colour anywhere",
          decideBodyColor(scanOf(2, 0, true, {}), {}, "none"),
          "(none)", false, "none");

    // Surcharge d'instance : meme prototype, couleur d'instance differente.
    // La regle des faces uniformes doit gagner dans les deux cas.
    check("instance override + uniform faces",
          decideBodyColor(scanOf(30, 30, true, GRIS), ORANGE, LBL),
          "#5A6266", false, "face-uniform-override");

    std::cout << "\n" << (fails ? "FAILED" : "ALL PASS") << " — " << fails << " failure(s)\n\n";
    return fails ? 1 : 0;
}

int main(int argc, char** argv) {
#ifdef _WIN32
    // [FIX affichage] Le fichier source est en UTF-8 (tirets cadratins —,
    // accents dans les commentaires/logs francais). cmd.exe/PowerShell
    // demarrent par defaut sur la codepage OEM (CP850/CP437 en France), pas
    // UTF-8 : chaque sequence UTF-8 multi-octets (ex: E2 80 94 pour "—") est
    // alors reinterpretee octet par octet via cette codepage -> mojibake
    // ("ÔÇö" au lieu de "—"). SetConsoleOutputCP(CP_UTF8) fait comprendre a
    // la console que les octets qu'on lui envoie SONT de l'UTF-8 -- meme
    // combinaison std::cerr/std::cout + UTF-8 litteral que sous WSL, ou le
    // terminal Linux est deja nativement en UTF-8 (d'ou l'absence du
    // probleme la-bas). Doit etre fait ICI, avant la toute premiere ligne
    // ecrite (banniere comprise).
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
#ifdef _WIN32
    // [MSVC] Couleurs ANSI via SetConsoleMode (Windows 10 build 1511+).
    // GetConsoleMode echoue si stderr est redirige vers un fichier/pipe —
    // dans ce cas gUseColor reste false, comportement correct.
    {
        HANDLE hErr = GetStdHandle(STD_ERROR_HANDLE);
        DWORD  mode = 0;
        if (hErr != INVALID_HANDLE_VALUE && GetConsoleMode(hErr, &mode)) {
            if (SetConsoleMode(hErr, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING))
                gUseColor = true;
        }
    }
#else
    // [12/08] Couleur console UNIQUEMENT si stderr est un vrai terminal (pas une
    // redirection vers fichier/pipe) — determine une seule fois, ici, avant la
    // toute premiere ligne de log.
    gUseColor = isatty(fileno(stderr)) != 0;
#endif
    // [15/08] Mode diagnostic "--decode-colors" -- AVANT toute autre
    // initialisation (pas de medusa.log, pas de socket) : c'est une commande
    // ponctuelle, pas un demarrage de serveur. Voir runDecodeColorsCli().
    if (argc > 1 && std::string(argv[1]) == "--decode-colors") {
        if (argc < 3) {
            std::cerr << "Usage: " << argv[0] << " --decode-colors file.step\n";
            return 1;
        }
        return runDecodeColorsCli(argv[2]);
    }
    // [31/08] Idem, sans fichier : banc d'essai de la table de decision couleur.
    if (argc > 1 && std::string(argv[1]) == "--selftest-colors") {
        return runColorSelfTestCli();
    }
    // [10/08] Log fichier dans Telechargements si detectable dynamiquement
    // (voir getWindowsDownloadsPath, aucun nom d'utilisateur en dur) — repli
    // sur chemin relatif (medusa.log, dossier courant) si l'interop Windows
    // echoue. Tronque a chaque demarrage (pas d'ajout indefini entre sessions).
    // [28/08] Meme formalisme que l'export de logs NASSCAD, a la demande :
    //     nasscad-logs-2026-08-28_16-21-52.txt   (client, logExport())
    //     medusa-logs-2026-08-28_16-28-49.txt    (ici)
    // Horodate a la SECONDE et en heure LOCALE — comme _fmtLogFilename() cote
    // client, pour que les deux journaux d'une meme session se rangent cote a
    // cote et se lisent en parallele.
    //
    // CONSEQUENCE ASSUMEE : un fichier par demarrage, au lieu d'un medusa.log
    // unique tronque a chaque fois. C'est le prix du formalisme demande — plus
    // rien n'est ecrase, mais le dossier se remplit si le moteur est relance
    // souvent. Aucune retention automatique pour l'instant.
    std::string downloadsDir = getWindowsDownloadsPath();
    std::string logName = "medusa-logs-" + logFileStamp() + ".txt";
    std::string logPath = !downloadsDir.empty() ? (downloadsDir + "/" + logName) : logName;
    static std::ofstream gLogFile(logPath, std::ios::trunc);
    static TeeStreambuf gTeeBuf(std::cerr.rdbuf(), gLogFile.rdbuf());
    // [FIX AUDIT 18/08 — demande Nass] La redirection cerr->fichier doit rester ICI,
    // tot, pour que TOUT (banniere comprise) finisse aussi dans medusa.log — mais
    // l'ANNONCE console "[OK] Log file: ..." est desormais differee (cf. plus bas,
    // juste apres la ligne "native /repair") : affichage seulement, la capture
    // fichier elle-meme n'attend pas et ne perd donc aucune ligne.
    if (gLogFile.is_open()) std::cerr.rdbuf(&gTeeBuf);

#ifndef _WIN32
    // SIGPIPE : si le navigateur coupe la connexion PENDANT que le serveur ecrit la
    // reponse (gros buffer NSTP de 60+ Mo = fenetre de plusieurs secondes — onglet
    // recharge, timeout cote JS, F5...), le comportement POSIX par defaut TUE le
    // process entier, sans exception, sans passer par aucun catch. C'est la cause
    // la plus probable des arrets fantomes constates ("MEDUSA arrete" apres un gros
    // import sans que personne n'ait rien ferme). Ignore : send() retourne alors
    // une erreur normale, geree par writeAll qui abandonne proprement CETTE reponse.
    signal(SIGPIPE, SIG_IGN);
#endif
    int port = (argc > 1) ? std::atoi(argv[1]) : 8765;
    // argv[2] : deflection FORCEE pour toute la session (test A/B non-manifold vs
    // finesse). Absent = auto (ratio bbox, comportement normal).
    double defaultDeflection = (argc > 2) ? std::atof(argv[2]) : -1.0;
    if (defaultDeflection > 0) gDeflectionOverride = defaultDeflection;

    // OCCT peut être verbeux sur stderr (warnings de reconstruction topologique) —
    // on garde les messages d'erreur mais on coupe le bruit trace/info par défaut.
    Message::DefaultMessenger()->RemovePrinters(STANDARD_TYPE(Message_Printer));

#ifdef _WIN32
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed\n";
        return 1;
    }
#endif

    SocketFD srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv == NASSCAD_SOCK_INVALID) { std::cerr << "socket() failed\n"; return 1; }
    int opt = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((u_short)port);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // bind STRICT localhost — jamais 0.0.0.0

    if (bind(srv, (sockaddr*)&addr, sizeof(addr)) < 0) {
        std::cerr << "bind() failed on 127.0.0.1:" << port << " — port already in use?\n";
        return 1;
    }
    if (listen(srv, 16) < 0) { std::cerr << "listen() failed\n"; return 1; }

    {
        const std::string title = "=== NASSCAD MEDUSA ENGINE 3.1 ===";
        const std::string border(title.size(), '=');
        std::cerr << cDim() << border << cReset() << "\n";
        std::cerr << cBold() << title << cReset() << "\n";
        std::cerr << cDim() << border << cReset() << "\n";
    }
    {
        // [FIX diagnostic] Un process 32-bit sur Windows est plafonne a ~2-4 Go
        // d'espace d'adressage, QUELLE QUE SOIT la RAM physique de la machine
        // (meme a 64 Go) -- symptome indiscernable d'un vrai manque de memoire
        // vu du process (allocation qui echoue / OOM) mais cause radicalement
        // differente (mauvais toolchain de compilation, pas un vrai probleme
        // memoire). _WIN64 n'est defini QUE pour une compilation 64-bit (meme
        // sous _WIN32, qui couvre les deux) -- verifiable ici sans avoir a
        // ouvrir le Gestionnaire des taches a temps avant un crash.
#if defined(_WIN64)
        std::cerr << cDim() << "[INFO] Architecture: x64 (64-bit)" << cReset() << "\n";
#elif defined(_WIN32)
        std::cerr << cWarn() << "[INFO] Architecture: x86 (32-bit) -- address space capped at ~2-4 GB regardless of physical RAM !" << cReset() << "\n";
#else
        std::cerr << cDim() << "[INFO] Architecture: " << (sizeof(void*) == 8 ? "64-bit" : "32-bit") << cReset() << "\n";
#endif
    }
    std::cerr << cDim() << "native /repair (batch, parallel, mirror of /smooth) — STEP tessellation now parallel too (pool size = " << std::thread::hardware_concurrency() << " threads)" << cReset() << "\n";
    // [FIX AUDIT 18/08 — demande Nass] Annonce differee ici (redirection reelle faite
    // bien plus haut, cf. commentaire pres de gTeeBuf) — ordre d'affichage demande :
    // apres la ligne "native /repair", avant "Listening on".
    if (gLogFile.is_open())
        std::cerr << cOk() << "[OK]" << cReset() << " Log file: " << logPath << (downloadsDir.empty() ? " (Downloads detection failed, using local fallback)" : "") << "\n";
    else
        std::cerr << cWarn() << "[WARN]" << cReset() << " " << logPath << " could not be opened — console only, no file backup this session.\n";
    std::cerr << cOk() << "[OK]" << cReset() << " Listening on http://127.0.0.1:" << port << " (strict localhost bind)\n";
    if (gDeflectionOverride > 0)
        std::cerr << "Deflection: FORCED to " << gDeflectionOverride << " mm (CLI argument - test mode)\n";
    else
        std::cerr << cInfo() << "[INFO]" << cReset() << " Deflection: auto (0.1% bbox, floor 1 mm)\n";
    std::cerr << cInfo() << "[INFO]" << cReset() << " Endpoints: GET /ping | POST /step | POST /stepstream | POST /csg | POST /csgtree | POST /smooth | POST /repair\n";
    std::cerr << cOk() << "[OK]" << cReset() << " Ready.\n";

    while (true) {
        sockaddr_in clientAddr{};
        socklen_t clientLen = sizeof(clientAddr);
        SocketFD fd = accept(srv, (sockaddr*)&clientAddr, &clientLen);
        if (fd == NASSCAD_SOCK_INVALID) continue;
        // [PERF 18/08] Nagle desactive sur CETTE socket cliente — sert directement
        // l'objectif deja documente pour GET /ping ("detection au boot, latence
        // minimale") : sans TCP_NODELAY, un petit paquet (reponse /ping, ou meme le
        // tout premier chunk de /stepstream) peut rester coalesce en attendant l'ACK
        // du paquet precedent (algorithme de Nagle) au lieu de partir immediatement
        // — mesurable meme en loopback des que l'ecriture se fait en plusieurs
        // send() (cf. writeAll/writeChunk plus bas). Best-effort, comme SO_REUSEADDR
        // plus haut : valeur de retour ignoree, une socket qui refuse cette option
        // reste utilisable, juste sans le gain de latence.
        {
            int nodelay = 1;
            setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (const char*)&nodelay, sizeof(nodelay));
        }

        // [28/08 AUDIT] Timeouts de socket — indispensables ici, et pas un simple
        // durcissement de principe. Cette boucle est STRICTEMENT SERIE : un seul
        // accept(), une requete traitee de bout en bout, puis la suivante. Sans
        // timeout, une connexion qui s'ouvre et n'envoie jamais rien bloque
        // readHttpRequest() indefiniment dans son recv() — et donc bloque le
        // MOTEUR ENTIER, pas seulement ce client. N'importe quel scan de port, un
        // onglet qui meurt entre le connect() et le send(), un proxy curieux, et
        // NASSCAD affiche "MEDUSA unreachable" alors que le process tourne
        // toujours. Depuis le retrait du repli WASM, ce blocage n'est plus
        // seulement genant : il n'y a plus rien derriere.
        // 30 s, et c'est par appel recv()/send(), pas pour la requete entiere :
        // un gros STEP qui transfere en continu ne les declenche jamais. En cas
        // de declenchement, recv() renvoie -1 -> readHttpRequest() retourne false
        // -> socket fermee, boucle relancee. Exactement le comportement voulu.
        {
#ifdef _WIN32
            DWORD tv = 30000; // millisecondes
#else
            struct timeval tv; tv.tv_sec = 30; tv.tv_usec = 0;
#endif
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv));
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, (const char*)&tv, sizeof(tv));
        }

        HttpRequest req;
        // [28/08 AUDIT] Filet autour du parsing : chaque handler d'endpoint a son
        // try/catch, mais readHttpRequest() etait appele a nu dans la boucle.
        // Toute exception qui en sortait n'etait attrapee nulle part et terminait
        // le process. Le cas concret (std::stoul sur un Content-Length non
        // numerique) est corrige a la source ; ce catch couvre le reste — un
        // bad_alloc sur le resize() du corps, en premier lieu.
        bool reqOk = false;
        try {
            reqOk = readHttpRequest(fd, req);
        } catch (const std::exception& e) {
            std::cerr << cErr() << "[HTTP] requete rejetee:" << cReset() << " " << e.what() << "\n";
            reqOk = false;
        } catch (...) {
            std::cerr << cErr() << "[HTTP] request rejected (non-standard exception)" << cReset() << "\n";
            reqOk = false;
        }
        if (!reqOk) { nasscadCloseSocket(fd); continue; }

        if (req.method == "OPTIONS") {
            sendResponse(fd, 204, "No Content", "text/plain", nullptr, 0);
        }
        else if (req.method == "GET" && req.path == "/ping") {
            // [v2.5] /ping machine-aware : MEDUSA est le seul des deux cotes a
            // pouvoir lire le materiel REEL (Firefox n'expose pas deviceMemory,
            // et hardwareConcurrency peut etre bride en mode privacy). Le client
            // s'en sert pour auto-dimensionner pool/workers — cf. incident du
            // 08/08 : pool 2GB sur une machine 8GB = swap, import x8 plus lent.
            // [v2.6] + availMB : RAM REELLEMENT disponible a l'instant T (via
            // /proc/meminfo MemAvailable), pas seulement la RAM totale installee.
            // Sur une machine avec plein d'onglets Firefox deja ouverts, ramMB
            // dit "16 Go installes" quand availMB dit la verite : "3 Go libres
            // maintenant". Le client doit preferer availMB quand present.
            long ramMB = 0;
#ifdef _WIN32
            // Meme logique que readAvailableRamMB() : sys/sysinfo.h (glibc/Linux)
            // n'est pas inclus sous _WIN32 (cf. garde ligne 43), struct sysinfo/
            // sysinfo() n'existent pas sous MSVC/MinGW-w64. GlobalMemoryStatusEx
            // donne l'equivalent Windows de si.totalram.
            MEMORYSTATUSEX statex;
            statex.dwLength = sizeof(statex);
            if (GlobalMemoryStatusEx(&statex)) ramMB = (long)(statex.ullTotalPhys / (1024ULL*1024ULL));
#else
            struct sysinfo si;
            if (sysinfo(&si) == 0) ramMB = (long)((si.totalram * (unsigned long long)si.mem_unit) / (1024ULL*1024ULL));
#endif
            long availMB = readAvailableRamMB();
            unsigned cores = std::thread::hardware_concurrency();
            // [27/08] "csgtree":true — capability flag, PAS un numero de version.
            // Depuis le deport complet des workers Manifold, le client n'a plus de
            // repli WASM : s'il tourne face a un binaire MEDUSA anterieur a cet
            // endpoint, il doit le savoir AVANT d'envoyer un arbre, pour retomber
            // sur sa decomposition post-ordre en /csg successifs plutot que de se
            // prendre un 404 en plein Deep Re-run. Un flag nomme se teste sans
            // parser/comparer des numeros de version.
            std::string j = "{\"engine\":\"nasscad-medusa-engine\",\"version\":\"3.1\",\"occt\":\"" OCC_VERSION_COMPLETE "\",\"protocol\":\"NSTP1\""
                            ",\"csgtree\":true"
                            ",\"ramMB\":" + std::to_string(ramMB) +
                            ",\"availMB\":" + std::to_string(availMB) +
                            ",\"cores\":" + std::to_string(cores) + "}";
            sendResponse(fd, 200, "OK", "application/json", j.data(), j.size());
        }
        else if (req.method == "POST" && (req.path == "/stepstream" || req.path.rfind("/stepstream?", 0) == 0)) {
            // Mode streaming : headers chunked immediats, puis une frame par mesh
            // AU FIL de la tessellation — le navigateur peut construire et afficher
            // chaque corps sans attendre la fin du calcul complet.
            std::string head =
                "HTTP/1.1 200 OK\r\n"
                + std::string(CORS_HEADERS) +
                "Content-Type: application/octet-stream\r\n"
                "Transfer-Encoding: chunked\r\n"
                "Connection: close\r\n\r\n";
            writeAll(fd, head.data(), head.size());
            logStepFileBanner(req.body, "/stepstream");   // [28/08] nom du fichier importe
            try {
                double tessMs = 0; int faceCount = 0; int sent = 0;
                auto t0 = Clock::now();
                processStepBuffer(req.body, -1.0, tessMs, faceCount,
                    [&](const MeshData& m){ writeMeshFrame(fd, m); sent++; });
                std::ostringstream fin;
                fin << "{\"end\":true,\"meshCount\":" << sent << ",\"tessMs\":" << tessMs << "}";
                writeJsonFrame(fd, fin.str());
                endChunks(fd);
                auto t1 = Clock::now();
                std::cerr << cInfo() << "[POST /stepstream]" << cReset() << " " << (req.body.size()/1024.0) << " KB STEP -> "
                          << sent << " mesh(es) streamed, " << faceCount << " faces, "
                          << ms(t0,t1) << " ms total\n";
            } catch (const std::exception& e) {
                // Trop tard pour un statut HTTP propre (headers 200 deja partis) :
                // frame d'erreur terminale, le client la detecte et bascule sur /step.
                std::ostringstream err;
                err << "{\"end\":true,\"error\":\"" << jsonEscape(e.what()) << "\"}";
                writeJsonFrame(fd, err.str());
                endChunks(fd);
                std::cerr << cErr() << "[POST /stepstream] ERROR:" << cReset() << " " << e.what() << "\n";
            } catch (...) {
                writeJsonFrame(fd, "{\"end\":true,\"error\":\"non-standard exception\"}");
                endChunks(fd);
                std::cerr << cErr() << "[POST /stepstream] non-standard ERROR" << cReset() << "\n";
            }
        }
        else if (req.method == "POST" && (req.path == "/csg" || req.path.rfind("/csg?", 0) == 0)) {
            // [27/08] La lambda weldMeshForCSG qui vivait ici est passee au scope
            // fichier (juste avant main) : /csgtree en a besoin sur chaque feuille
            // de l arbre. Corps identique, appel identique — voir sa doc la-bas.
            // ─── Boolean CSG natif via Manifold compile en dur (pas WASM) ───────────
            // Protocole requete : [u32 opType 0=union/1=subtract/2=intersect]
            //   [u32 operandCount] puis par operande : [u32 nVert][u32 nTri]
            //   [float32 x nVert*3 positions][uint32 x nTri*3 indices]
            // Reponse : JSON header (jsonLen u32 LE) + positions f32 + indices u32,
            // meme esprit que NSTP.
            try {
                auto t0 = Clock::now();
                const std::string& b = req.body;
                if (b.size() < 8) throw std::runtime_error("/csg request body too short");
                size_t off = 0;
                auto rdU32 = [&](size_t& o)->uint32_t{
                    if (o + 4 > b.size()) throw std::runtime_error("/csg: out-of-bounds read");
                    uint32_t v; std::memcpy(&v, b.data()+o, 4); o += 4; return v;
                };
                uint32_t opType = rdU32(off);
                uint32_t operandCount = rdU32(off);
                if (operandCount < 2) throw std::runtime_error("/csg: at least 2 operands required");
                // [PROTO v2] solidsCount : nombre d'operandes EN TETE de la liste qui
                // forment la cible (a unioner ENTRE EUX avant la soustraction), le
                // reste (operandCount - solidsCount) etant les trous a soustraire.
                // =1 : cas historique, une seule cible (bouton Subtract explicite,
                // ou union/intersect ou solidsCount n'est pas utilise). >1 : plusieurs
                // solides selectionnes en meme temps que des trous cote client
                // (_hasMix) — AVANT ce champ, seul operand[0] etait traite comme
                // cible et tout operand[1..] (solides additionnels inclus) etait
                // soustrait comme un trou, faisant disparaitre silencieusement tout
                // solide au-dela du premier au lieu de le fusionner dans le resultat.
                uint32_t solidsCount = rdU32(off);
                if (opType == 1 && (solidsCount < 1 || solidsCount >= operandCount))
                    throw std::runtime_error("/csg: invalid solidsCount for subtract (must be in [1, operandCount-1])");
                // Plus de cap metier (l'ancien "500 safety cap" est saute : les
                // workers CSG sont deportes sur MEDUSA, c'est lui qui encaisse).
                // Seule reste une borne de COHERENCE protocolaire : chaque operande
                // occupe au minimum 8 octets (headers nVert/nTri), donc un
                // operandCount superieur a bodySize/8 est forcement un u32 corrompu
                // — pas une vraie requete. Les vraies limites physiques (RAM) sont
                // deja couvertes par les checks "truncated operand" plus bas.
                if ((size_t)operandCount > b.size() / 8) throw std::runtime_error("/csg: operandCount inconsistent with request size (corrupt header)");

                ManifoldArena manMem; // buffers des operandes — liberes ET detruits a la sortie du bloc
                std::vector<ManifoldManifold*> operands;
                // Stockage a duree de requete pour les meshes soudes (voir weldMeshForCSG) : les
                // ManifoldMeshGL construits ci-dessous referencent ces buffers directement, ils
                // doivent rester valides jusqu'au manifold_boolean tout en bas.
                std::vector<std::vector<float>> operandBuffers;
                std::vector<std::vector<uint32_t>> operandIdxBuffers;
                // Barre CSG — meme famille que PARSING/RESOLUTION/TESSELLATION :
                // mono-thread (cette boucle tourne avant tout parallelisme), donc
                // pas besoin de gConsoleMutex ici. Les anciens logs "welded"/
                // "status=" par operande partaient en clair sur la console a
                // chaque iteration (std::cerr direct) et empechaient toute barre
                // de rester stable, exactement le meme symptome que COLOR avant
                // le fix RESOLUTION -- donc meme remede : logFileOnly (visibles
                // dans medusa.log, plus sur la console) + une barre qui avance.
                barPhaseStart();
                for (uint32_t i = 0; i < operandCount; i++) {
                    uint32_t nVert = rdU32(off), nTri = rdU32(off);
                    size_t vBytes = (size_t)nVert * 3 * 4, iBytes = (size_t)nTri * 3 * 4;
                    if (off + vBytes + iBytes > b.size()) throw std::runtime_error("/csg: truncated operand");
                    const float* vp = reinterpret_cast<const float*>(b.data() + off); off += vBytes;
                    const uint32_t* ip = reinterpret_cast<const uint32_t*>(b.data() + off); off += iBytes;

                    // Copie modifiable pour la soudure (le buffer requete original reste const).
                    std::vector<float> wPos(vp, vp + nVert * 3);
                    std::vector<uint32_t> wIdx(ip, ip + nTri * 3);
                    size_t vertBefore = wPos.size() / 3;
                    weldMeshForCSG(wPos, wIdx);
                    if (wPos.size() / 3 != vertBefore) {
                        std::ostringstream oss;
                        oss << "  CSG: operand " << i << " welded (" << vertBefore << " -> "
                            << (wPos.size()/3) << " vertices, UV seam duplicates merged)\n";
                        logFileOnly(oss.str());
                    }
                    // wPos/wIdx doivent survivre jusqu'a l'appel manifold_boolean (Manifold ne copie
                    // pas forcement les donnees a la construction) -> stockage a duree de requete.
                    operandBuffers.push_back(std::move(wPos));
                    operandIdxBuffers.push_back(std::move(wIdx));
                    auto& fPos = operandBuffers.back();
                    auto& fIdx = operandIdxBuffers.back();

                    ManifoldMeshGL* mg = manMem.make(manifold_meshgl_size(), [&](void* p){
                        return manifold_meshgl(p, fPos.data(), fPos.size()/3, 3,
                                               fIdx.data(), fIdx.size()/3); });
                    ManifoldManifold* m = manMem.make(manifold_manifold_size(), [&](void* p){
                        return manifold_of_meshgl(p, mg); });
                    if (manifold_status(m) != MANIFOLD_NO_ERROR) {
                        std::ostringstream oss;
                        oss << "  CSG: operand " << i << " status=" << (int)manifold_status(m)
                            << " after welding (residual - Manifold will try anyway)\n";
                        logFileOnly(oss.str());
                    }
                    operands.push_back(m);

                    // Throttlee comme RESOLUTION : un pourcentage entier a la fois,
                    // plus toujours la derniere iteration (garantit 100% affiche).
                    int pct = (int)(100.0 * (i + 1) / operandCount);
                    int prevPct = (int)(100.0 * i / operandCount);
                    if (pct != prevPct || (i + 1) == operandCount) {
                        drawBarLine("CSG", (double)(i + 1) / operandCount,
                            std::to_string(pct) + "%  (" + std::to_string(i + 1) + "/" + std::to_string(operandCount) + ")");
                    }
                }

                // [PERF 30/08] Le corps de requete est MORT a partir d'ici : chaque
                // operande a ete copie dans operandBuffers (copie modifiable exigee
                // par la soudure, le corps etant const). Le laisser alloue le fait
                // vivre pendant TOUT le calcul Manifold -- c'est-a-dire exactement
                // au pic memoire, ou coexistent deja : les operandes soudes, la
                // representation interne Manifold, puis le resultat. Sur une union
                // de gros maillages, c'est une copie pleine de l'entree gardee pour
                // rien au pire moment. Verifie avant retrait : plus une seule
                // lecture de req.body au-dela de ce point dans ce handler.
                req.body.clear();
                req.body.shrink_to_fit();

                ManifoldOpType mop = opType == 0 ? MANIFOLD_ADD : opType == 1 ? MANIFOLD_SUBTRACT : MANIFOLD_INTERSECT;

                // ?legacy=1 : repli sur l'ancien fold sequentiel pur, uniquement pour
                // comparaison A/B directe (meme requete, meme machine) avec le chemin
                // batch ci-dessous -- voir POST /csg?legacy=1.
                bool legacyFold = false;
                {
                    auto qpos2 = req.path.find('?');
                    if (qpos2 != std::string::npos) {
                        legacyFold = req.path.substr(qpos2 + 1).find("legacy=1") != std::string::npos;
                    }
                }

                // Declaree APRES manMem : detruite avant elle a la sortie du bloc,
                // donc un intermediaire ne survit jamais a l'operande qui l'a produit.
                ManifoldArena resultMem;
                ManifoldManifold* result;

                if (legacyFold) {
                    // ── Ancien chemin : fold sequentiel A puis B puis C... aucun
                    // parallelisme, aucun tri par taille. Conserve uniquement pour
                    // mesurer le delta reel face au chemin batch (meme session).
                    // NE respecte PAS solidsCount (fold naif, operand[0] en tete) --
                    // sans consequence : chemin debug opt-in (?legacy=1), jamais
                    // emprunte par le client par defaut. ──
                    result = operands[0];
                    for (size_t i = 1; i < operands.size(); i++) {
                        ManifoldManifold* acc = result;
                        result = resultMem.make(manifold_manifold_size(), [&](void* p){
                            return manifold_boolean(p, acc, operands[i], mop); });
                    }
                } else if (opType == 1) {
                    // ── Subtract : non-commutatif, manifold_batch_boolean ne le supporte
                    // pas (assert cote lib -- Union/Intersect seulement). Mais l'identite
                    // ensembliste (S1∪S2∪..) - (H1∪H2∪..) tient toujours : on batch-union
                    // les solides (operand[0..solidsCount-1]) pour former la cible reelle,
                    // on batch-union les trous (operand[solidsCount..end], ca c'est
                    // commutatif et parallelisable), puis UNE seule soustraction finale
                    // cible − trous. ──
                    ManifoldManifold* target;
                    if (solidsCount > 1) {
                        ManifoldManifoldVec* solidVec = resultMem.make(manifold_manifold_vec_size(),
                            [&](void* p){ return manifold_manifold_empty_vec(p); });
                        for (size_t i = 0; i < solidsCount; i++) manifold_manifold_vec_push_back(solidVec, operands[i]);
                        target = resultMem.make(manifold_manifold_size(), [&](void* p){
                            return manifold_batch_boolean(p, solidVec, MANIFOLD_ADD); });
                    } else {
                        target = operands[0]; // cas historique : une seule cible
                    }

                    ManifoldManifoldVec* subVec = resultMem.make(manifold_manifold_vec_size(),
                        [&](void* p){ return manifold_manifold_empty_vec(p); });
                    for (size_t i = solidsCount; i < operands.size(); i++) manifold_manifold_vec_push_back(subVec, operands[i]);

                    ManifoldManifold* subtrahends = resultMem.make(manifold_manifold_size(), [&](void* p){
                        return manifold_batch_boolean(p, subVec, MANIFOLD_ADD); });

                    result = resultMem.make(manifold_manifold_size(), [&](void* p){
                        return manifold_boolean(p, target, subtrahends, MANIFOLD_SUBTRACT); });
                } else {
                    // ── Union / Intersect : commutatifs -> manifold_batch_boolean natif
                    // (Manifold::BatchBoolean, src/csg_tree.cpp). Deux gains empiles sans
                    // code maison : (1) tri par taille croissante -- fusionne les petits
                    // maillages en premier, moins de copie/traitement ; (2) des que la lib
                    // est compilee avec MANIFOLD_PAR=1 (deja le cas, build_manifold.sh
                    // -DMANIFOLD_PAR=ON), un tbb::task_group traite 4 paires a la fois en
                    // parallele reel, sans thread-pool maison ni risque de sur-souscription
                    // (c'est TBB qui gere son propre pool global). ──
                    ManifoldManifoldVec* vec = resultMem.make(manifold_manifold_vec_size(),
                        [&](void* p){ return manifold_manifold_empty_vec(p); });
                    for (auto* o : operands) manifold_manifold_vec_push_back(vec, o);

                    result = resultMem.make(manifold_manifold_size(), [&](void* p){
                        return manifold_batch_boolean(p, vec, mop); });
                }

                double volume = manifold_volume(result);
                int status = (int)manifold_status(result);
                // [PERF 18/08] manifold_num_vert(result)/manifold_num_tri(result)
                // retires : leur resultat (nVertOut/nTriOut) n'etait jamais lu — le
                // JSON de reponse et les tailles de buffer plus bas utilisent deja
                // outNV/outNT, obtenus via manifold_meshgl_num_vert/tri sur le
                // meshgl extrait juste en dessous. Deux appels bibliotheque morts en
                // moins par requete /csg (confirme mort par le compilateur lui-meme,
                // -Wunused-variable sur les deux, avant ce retrait).

                // [MANIFOLD-CALC] Trois grandeurs deja disponibles sur le solide
                // resultat, sans nouveau maillage ni cout notable (Manifold les
                // tient a jour en interne pendant le boolean), jusqu'ici jetees :
                //  - surfaceArea : pendant naturel de volume (manifold_surface_area,
                //    meme signature) -- utile cote UI pour un calcul de matiere/
                //    surface a peindre, etc.
                //  - isEmpty (manifold_is_empty) : distingue explicitement un
                //    resultat VIDE (ex. Subtract qui consomme entierement la
                //    cible) d'un vrai succes -- avant ce champ le client recevait
                //    success:true, vertCount:0 sans moyen de le detecter sans
                //    deviner sur outNV cote JS.
                //  - genus (manifold_genus, caracteristique d'Euler V-E+F) :
                //    indicateur bon marche de topologie cassee, INDEPENDANT de
                //    "status" (qui ne capte que les erreurs internes Manifold, pas
                //    un resultat degenere mais structurellement "valide" a ses yeux).
                double surfaceArea = manifold_surface_area(result);
                bool isEmpty = manifold_is_empty(result) != 0;
                int genus = manifold_genus(result);
                if (isEmpty) {
                    logFileOnly("  CSG: empty result (isEmpty=true) -- solid entirely consumed by the operation\n");
                }

                ManifoldMeshGL* outMesh = resultMem.make(manifold_meshgl_size(), [&](void* p){
                    return manifold_get_meshgl(p, result); });
                size_t outNV = manifold_meshgl_num_vert(outMesh), outNT = manifold_meshgl_num_tri(outMesh);

                float*    vertBuf = manifold_meshgl_vert_properties(resultMem.raw(sizeof(float) * outNV * 3), outMesh);
                uint32_t* triBuf  = manifold_meshgl_tri_verts(resultMem.raw(sizeof(uint32_t) * outNT * 3), outMesh);

                auto t1 = Clock::now();
                double csgMs = ms(t0, t1);

                std::ostringstream json;
                json << "{\"success\":true,\"vertCount\":" << outNV << ",\"triCount\":" << outNT
                     << ",\"volume\":" << volume << ",\"surfaceArea\":" << surfaceArea
                     << ",\"manifold\":" << (status == 0 ? "true" : "false")
                     << ",\"isEmpty\":" << (isEmpty ? "true" : "false") << ",\"genus\":" << genus
                     << ",\"csgMs\":" << csgMs << ",\"operandCount\":" << operandCount << "}";
                std::string js = json.str();
                uint32_t jl = (uint32_t)js.size();
                size_t vB = outNV * 3 * 4, iB = outNT * 3 * 4;
                // [PERF 30/08] Reponse STREAMEE au lieu d'un tampon unique.
                // Avant : un std::vector<uint8_t> de (JSON + positions + indices) etait
                // alloue puis rempli par memcpy -- une copie pleine du resultat, en vie
                // en meme temps que les tampons Manifold dont elle est copiee. On emet
                // maintenant directement depuis ces tampons, en chunked (RFC 7230), avec
                // l'infrastructure deja utilisee par /stepstream.
                // Cote client : fetch() reassemble le chunked de facon transparente et
                // res.arrayBuffer() rend exactement les memes octets, dans le meme ordre
                // -- AUCUN changement navigateur. La mise en chunked n'a lieu qu'ICI,
                // apres le calcul reussi : tous les chemins d'erreur passent avant et
                // gardent leur sendResponse(500) classique avec ses en-tetes.
                {
                    std::string head =
                        "HTTP/1.1 200 OK\r\n"
                        + std::string(CORS_HEADERS) +
                        "Content-Type: application/octet-stream\r\n"
                        "Transfer-Encoding: chunked\r\n"
                        "Connection: close\r\n\r\n";
                    writeAll(fd, head.data(), head.size());
                    uint8_t lenLE[4] = { (uint8_t)(jl & 0xFF), (uint8_t)((jl >> 8) & 0xFF),
                                         (uint8_t)((jl >> 16) & 0xFF), (uint8_t)((jl >> 24) & 0xFF) };
                    writeChunk(fd, lenLE, 4);
                    writeChunk(fd, (const uint8_t*)js.data(), jl);
                    if (vB) writeChunk(fd, (const uint8_t*)vertBuf, vB);
                    if (iB) writeChunk(fd, (const uint8_t*)triBuf, iB);
                    endChunks(fd);
                }
                std::cerr << cInfo() << "[POST /csg]" << cReset() << " " << operandCount << " operand(s), op=" << opType
                          << (legacyFold ? " [legacy fold]" : " [batch]")
                          << " -> " << outNV << " verts, " << outNT << " tris, volume=" << volume
                          << ", area=" << surfaceArea << (isEmpty ? ", EMPTY" : "")
                          << ", " << csgMs << " ms\n";

            } catch (const std::exception& e) {
                std::string err = std::string("{\"success\":false,\"error\":\"") + jsonEscape(e.what()) + "\"}";
                std::cerr << cErr() << "[POST /csg] ERROR:" << cReset() << " " << e.what() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err.data(), err.size());
            } catch (...) {
                const char* err = "{\"success\":false,\"error\":\"non-standard exception (Manifold?)\"}";
                std::cerr << cErr() << "[POST /csg] non-standard ERROR" << cReset() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err, strlen(err));
            }
        }
        else if (req.method == "POST" && (req.path == "/csgtree" || req.path.rfind("/csgtree?", 0) == 0)) {
            // ─── Arbre CSG natif — voir la doc du protocole au-dessus de main() ──
            // Remplace _workerCSGTree (Manifold WASM) : l arbre entier en UNE
            // requete, evalue en post-ordre, intermediaires gardes vivants entre
            // niveaux, une seule extraction meshgl a la racine.
            try {
                auto t0 = Clock::now();
                const std::string& b = req.body;
                if (b.size() < 12) throw std::runtime_error("/csgtree request body too short");
                size_t off = 0;
                uint32_t magic; std::memcpy(&magic, b.data(), 4); off = 4;
                if (magic != 0x45525443u) throw std::runtime_error("/csgtree: bad magic (expected 'CTRE')");
                uint32_t ver; std::memcpy(&ver, b.data()+off, 4); off += 4;
                if (ver != 1u) throw std::runtime_error("/csgtree: unsupported protocol version");

                CsgTreeNode root;
                uint32_t nodeCount = 0, leafCount = 0;
                parseCsgTreeNode(b, off, root, 0, nodeCount, leafCount);

                // [PERF 30/08] Le corps de requete est MORT a partir d'ici : chaque
                // feuille de l'arbre possede ses propres vecteurs pos/idx (copies
                // faites par parseCsgTreeNode). Le laisser alloue le fait
                // vivre pendant TOUT le calcul Manifold -- c'est-a-dire exactement
                // au pic memoire, ou coexistent deja : les operandes soudes, la
                // representation interne Manifold, puis le resultat. Sur une union
                // de gros maillages, c'est une copie pleine de l'entree gardee pour
                // rien au pire moment. Verifie avant retrait : plus une seule
                // lecture de req.body au-dela de ce point dans ce handler.
                req.body.clear();
                req.body.shrink_to_fit();

                if (root.leaf) throw std::runtime_error("/csgtree: root must be an internal node (nothing to evaluate)");

                // ── Soudure des feuilles en parallele — meme pool artisanal que
                // /smooth (compteur atomique + threads bornes aux coeurs et au
                // nombre de feuilles). C est du C++ pur sur des buffers disjoints,
                // aucun etat partage, aucune API Manifold touchee ici.
                std::vector<CsgTreeNode*> leaves;
                collectCsgTreeLeaves(root, leaves);
                if (leaves.empty()) throw std::runtime_error("/csgtree: no leaf mesh in tree");
                {
                    unsigned nThreads = std::thread::hardware_concurrency();
                    if (nThreads == 0) nThreads = 4;
                    nThreads = (unsigned)std::min((size_t)nThreads, leaves.size());
                    std::atomic<uint32_t> nextIdx{0};
                    std::atomic<uint32_t> weldDone{0};
                    uint32_t lastDrawnWeld = 0;
                    std::exception_ptr firstErr = nullptr;
                    std::mutex errMutex;
                    const uint32_t nLeaves = (uint32_t)leaves.size();
                    barPhaseStart();
                    std::vector<std::thread> pool;
                    pool.reserve(nThreads);
                    for (unsigned t = 0; t < nThreads; t++) {
                        pool.emplace_back([&]() {
                            for (;;) {
                                uint32_t i = nextIdx.fetch_add(1);
                                if (i >= nLeaves) break;
                                try {
                                    weldMeshForCSG(leaves[i]->pos, leaves[i]->idx);
                                } catch (...) {
                                    std::lock_guard<std::mutex> lk(errMutex);
                                    if (!firstErr) firstErr = std::current_exception();
                                }
                                uint32_t done = weldDone.fetch_add(1) + 1;
                                std::lock_guard<std::mutex> lk(gConsoleMutex);
                                if (done > lastDrawnWeld) {
                                    int pct = (int)(100.0 * done / nLeaves);
                                    int prevPct = (int)(100.0 * lastDrawnWeld / nLeaves);
                                    if (pct != prevPct || done == nLeaves) {
                                        drawBarLine("CSGTREE", (double)done / nLeaves,
                                            std::to_string(pct) + "%  (" + std::to_string(done) + "/" + std::to_string(nLeaves) + " leaves)");
                                    }
                                    lastDrawnWeld = done;
                                }
                            }
                        });
                    }
                    for (auto& th : pool) th.join();
                    if (firstErr) std::rethrow_exception(firstErr);
                }

                ManifoldArena mem; // tous les buffers Manifold — liberes ET detruits a la sortie du bloc
                ManifoldManifold* result = evalCsgTreeNode(root, mem);

                double volume = manifold_volume(result);
                int status = (int)manifold_status(result);
                // [MANIFOLD-CALC] Memes trois grandeurs additionnelles qu'en /csg
                // (voir le commentaire detaille la-bas) : surfaceArea, isEmpty,
                // genus -- deja tenues a jour par Manifold sur "result", jamais
                // lues jusqu'ici sur ce chemin /csgtree non plus.
                double surfaceArea = manifold_surface_area(result);
                bool isEmpty = manifold_is_empty(result) != 0;
                int genus = manifold_genus(result);
                if (isEmpty) {
                    logFileOnly("  CSGTREE: empty result (isEmpty=true) -- tree entirely consumed\n");
                }

                ManifoldMeshGL* outMesh = mem.make(manifold_meshgl_size(), [&](void* p){
                    return manifold_get_meshgl(p, result); });
                size_t outNV = manifold_meshgl_num_vert(outMesh), outNT = manifold_meshgl_num_tri(outMesh);

                float*    vertBuf = manifold_meshgl_vert_properties(mem.raw(sizeof(float) * outNV * 3), outMesh);
                uint32_t* triBuf  = manifold_meshgl_tri_verts(mem.raw(sizeof(uint32_t) * outNT * 3), outMesh);

                auto t1 = Clock::now();
                double csgMs = ms(t0, t1);

                // Cadre de reponse IDENTIQUE a /csg (le client partage le decodeur).
                // csgMs porte le meme nom pour la meme raison.
                std::ostringstream json;
                json << "{\"success\":true,\"vertCount\":" << outNV << ",\"triCount\":" << outNT
                     << ",\"volume\":" << volume << ",\"surfaceArea\":" << surfaceArea
                     << ",\"manifold\":" << (status == 0 ? "true" : "false")
                     << ",\"isEmpty\":" << (isEmpty ? "true" : "false") << ",\"genus\":" << genus
                     << ",\"csgMs\":" << csgMs << ",\"nodeCount\":" << nodeCount
                     << ",\"leafCount\":" << leafCount << "}";
                std::string js = json.str();
                uint32_t jl = (uint32_t)js.size();
                size_t vB = outNV * 3 * 4, iB = outNT * 3 * 4;
                // [PERF 30/08] Reponse STREAMEE au lieu d'un tampon unique.
                // Avant : un std::vector<uint8_t> de (JSON + positions + indices) etait
                // alloue puis rempli par memcpy -- une copie pleine du resultat, en vie
                // en meme temps que les tampons Manifold dont elle est copiee. On emet
                // maintenant directement depuis ces tampons, en chunked (RFC 7230), avec
                // l'infrastructure deja utilisee par /stepstream.
                // Cote client : fetch() reassemble le chunked de facon transparente et
                // res.arrayBuffer() rend exactement les memes octets, dans le meme ordre
                // -- AUCUN changement navigateur. La mise en chunked n'a lieu qu'ICI,
                // apres le calcul reussi : tous les chemins d'erreur passent avant et
                // gardent leur sendResponse(500) classique avec ses en-tetes.
                {
                    std::string head =
                        "HTTP/1.1 200 OK\r\n"
                        + std::string(CORS_HEADERS) +
                        "Content-Type: application/octet-stream\r\n"
                        "Transfer-Encoding: chunked\r\n"
                        "Connection: close\r\n\r\n";
                    writeAll(fd, head.data(), head.size());
                    uint8_t lenLE[4] = { (uint8_t)(jl & 0xFF), (uint8_t)((jl >> 8) & 0xFF),
                                         (uint8_t)((jl >> 16) & 0xFF), (uint8_t)((jl >> 24) & 0xFF) };
                    writeChunk(fd, lenLE, 4);
                    writeChunk(fd, (const uint8_t*)js.data(), jl);
                    if (vB) writeChunk(fd, (const uint8_t*)vertBuf, vB);
                    if (iB) writeChunk(fd, (const uint8_t*)triBuf, iB);
                    endChunks(fd);
                }
                std::cerr << cInfo() << "[POST /csgtree]" << cReset() << " " << nodeCount << " node(s), "
                          << leafCount << " leaf/leaves -> " << outNV << " verts, " << outNT
                          << " tris, volume=" << volume << ", area=" << surfaceArea
                          << (isEmpty ? ", EMPTY" : "") << ", " << csgMs << " ms\n";

            } catch (const std::exception& e) {
                std::string err = std::string("{\"success\":false,\"error\":\"") + jsonEscape(e.what()) + "\"}";
                std::cerr << cErr() << "[POST /csgtree] ERROR:" << cReset() << " " << e.what() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err.data(), err.size());
            } catch (...) {
                const char* err = "{\"success\":false,\"error\":\"non-standard exception (Manifold tree?)\"}";
                std::cerr << cErr() << "[POST /csgtree] non-standard ERROR" << cReset() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err, strlen(err));
            }
        }
        else if (req.method == "POST" && (req.path == "/smooth" || req.path.rfind("/smooth?", 0) == 0)) {
            // ─── Lissage BFS natif, EN LOT ET EN PARALLELE ────────────────
            // Cible directe du goulot mesure sur import STEP multi-corps :
            // N corps INDEPENDANTS (contrairement au CSG, aucune dependance
            // croisee entre eux) traites un thread par coeur, au lieu de
            // sequentiellement dans l'unique Worker JS Postprocess.
            // Protocole requete : [f32 creaseAngleDeg][u32 meshCount] puis
            // par mesh : [u32 nVert][u32 nTri][f32 x nVert*3 positions]
            // [u32 x nTri*3 indices].
            // Reponse : JSON header (jsonLen u32 LE, counts[] = nb de
            // vertices EN SORTIE par mesh, non-indexe) puis, par mesh dans
            // l'ordre, positions f32 + normales f32 concatenees.
            try {
                auto t0 = Clock::now();
                const std::string& b = req.body;
                if (b.size() < 8) throw std::runtime_error("/smooth request body too short");
                size_t off = 0;
                auto rdU32 = [&](size_t& o)->uint32_t{
                    if (o + 4 > b.size()) throw std::runtime_error("/smooth: out-of-bounds read");
                    uint32_t v; std::memcpy(&v, b.data()+o, 4); o += 4; return v;
                };
                auto rdF32 = [&](size_t& o)->float{
                    if (o + 4 > b.size()) throw std::runtime_error("/smooth: out-of-bounds read");
                    float v; std::memcpy(&v, b.data()+o, 4); o += 4; return v;
                };
                float creaseDeg = rdF32(off);
                uint32_t meshCount = rdU32(off);
                if (meshCount < 1) throw std::runtime_error("/smooth: at least 1 mesh required");
                // Borne de coherence protocolaire (meme esprit que /csg) : chaque
                // mesh occupe au moins 8 octets de header (nVert+nTri).
                if ((size_t)meshCount > b.size() / 8) throw std::runtime_error("/smooth: meshCount inconsistent with request size (corrupt header)");
                static constexpr double PI_LOCAL = 3.14159265358979323846;
                double cosCrease = std::cos(creaseDeg * PI_LOCAL / 180.0);

                std::vector<std::vector<float>> inPos(meshCount);
                std::vector<std::vector<uint32_t>> inIdx(meshCount);
                for (uint32_t m = 0; m < meshCount; m++) {
                    uint32_t nVert = rdU32(off), nTri = rdU32(off);
                    size_t vBytes = (size_t)nVert * 3 * 4, iBytes = (size_t)nTri * 3 * 4;
                    if (off + vBytes + iBytes > b.size()) throw std::runtime_error("/smooth: truncated mesh");
                    const float* vp = reinterpret_cast<const float*>(b.data() + off); off += vBytes;
                    const uint32_t* ip = reinterpret_cast<const uint32_t*>(b.data() + off); off += iBytes;
                    inPos[m].assign(vp, vp + (size_t)nVert * 3);
                    inIdx[m].assign(ip, ip + (size_t)nTri * 3);
                }

                // ── Parallelisation : chaque mesh est independant, un pool
                // de threads (borne au nb de coeurs ET au nb de meshes) tire
                // les indices restants via un compteur atomique partage ──
                std::vector<SmoothResult> results(meshCount);
                std::exception_ptr firstErr = nullptr;
                std::mutex errMutex;
                unsigned nThreads = std::thread::hardware_concurrency();
                if (nThreads == 0) nThreads = 4; // hardware_concurrency() peut renvoyer 0, filet de secu
                nThreads = (unsigned)std::min((size_t)nThreads, (size_t)meshCount);
                std::atomic<uint32_t> nextIdx{0};
                // Barre SMOOTH — meme technique que TESSELLATION (voir processStepBuffer) :
                // compteur atomique de completion + gConsoleMutex + lastDrawn qui ne recule
                // jamais, throttlee aux paliers de 1%. Ordre de completion non deterministe
                // entre threads, donc on affiche l'avancement global, pas "le mesh en cours".
                std::atomic<uint32_t> smoothDone{0};
                uint32_t lastDrawnSmooth = 0;
                barPhaseStart();
                std::vector<std::thread> pool;
                pool.reserve(nThreads);
                for (unsigned t = 0; t < nThreads; t++) {
                    pool.emplace_back([&]() {
                        for (;;) {
                            uint32_t m = nextIdx.fetch_add(1);
                            if (m >= meshCount) break;
                            try {
                                results[m] = smoothMeshBFSLocal(std::move(inPos[m]), std::move(inIdx[m]), cosCrease);
                            } catch (...) {
                                std::lock_guard<std::mutex> lk(errMutex);
                                if (!firstErr) firstErr = std::current_exception();
                            }
                            uint32_t done = smoothDone.fetch_add(1) + 1;
                            std::lock_guard<std::mutex> lk(gConsoleMutex);
                            if (done > lastDrawnSmooth) {
                                int pct = (int)(100.0 * done / meshCount);
                                int prevPct = (int)(100.0 * lastDrawnSmooth / meshCount);
                                if (pct != prevPct || done == meshCount) {
                                    drawBarLine("SMOOTH", (double)done / meshCount,
                                        std::to_string(pct) + "%  (" + std::to_string(done) + "/" + std::to_string(meshCount) + ")");
                                }
                                lastDrawnSmooth = done;
                            }
                        }
                    });
                }
                for (auto& th : pool) th.join();
                if (firstErr) std::rethrow_exception(firstErr);

                auto t1 = Clock::now();
                double smoothMs = ms(t0, t1);

                std::ostringstream json;
                json << "{\"success\":true,\"meshCount\":" << meshCount << ",\"counts\":[";
                for (uint32_t m = 0; m < meshCount; m++) {
                    if (m) json << ",";
                    json << (results[m].pos.size() / 3);
                }
                json << "],\"idxCounts\":[";
                for (uint32_t m = 0; m < meshCount; m++) {
                    if (m) json << ",";
                    json << results[m].idx.size();
                }
                json << "],\"smoothMs\":" << smoothMs << "}";
                std::string js = json.str();
                uint32_t jl = (uint32_t)js.size();

                size_t totalBinBytes = 0, totalInFaces = 0, totalOutVerts = 0;
                for (auto& r : results) {
                    totalBinBytes += r.pos.size() * 4 + r.nrm.size() * 4 + r.idx.size() * 4;
                    totalInFaces += r.idx.size() / 3;
                    totalOutVerts += r.pos.size() / 3;
                }
                std::vector<uint8_t> out(4 + jl + totalBinBytes);
                out[0]=jl&0xFF; out[1]=(jl>>8)&0xFF; out[2]=(jl>>16)&0xFF; out[3]=(jl>>24)&0xFF;
                std::memcpy(out.data()+4, js.data(), jl);
                size_t wOff = 4 + jl;
                for (auto& r : results) {
                    std::memcpy(out.data()+wOff, r.pos.data(), r.pos.size()*4); wOff += r.pos.size()*4;
                    std::memcpy(out.data()+wOff, r.nrm.data(), r.nrm.size()*4); wOff += r.nrm.size()*4;
                    std::memcpy(out.data()+wOff, r.idx.data(), r.idx.size()*4); wOff += r.idx.size()*4;
                }

                // Taux de reduction reel vs l'ancienne sortie non-indexee (faces*3) —
                // visible immediatement dans la console, pas juste suppose.
                double reduction = totalInFaces > 0 ? (1.0 - (double)totalOutVerts / (double)(totalInFaces * 3)) * 100.0 : 0.0;
                std::cerr << cInfo() << "[POST /smooth]" << cReset() << " " << meshCount << " mesh(es), crease=" << creaseDeg
                          << "deg, " << nThreads << " thread(s) -> " << smoothMs << " ms"
                          << " (indexed output: " << totalOutVerts << " verts vs " << (totalInFaces*3)
                          << " old non-indexed, -" << reduction << "%)\n";

                sendResponse(fd, 200, "OK", "application/octet-stream", (const char*)out.data(), out.size());
            } catch (const std::exception& e) {
                std::string err = std::string("{\"success\":false,\"error\":\"") + jsonEscape(e.what()) + "\"}";
                std::cerr << cErr() << "[POST /smooth] ERROR:" << cReset() << " " << e.what() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err.data(), err.size());
            } catch (...) {
                const char* err = "{\"success\":false,\"error\":\"non-standard exception (smooth)\"}";
                std::cerr << cErr() << "[POST /smooth] non-standard ERROR" << cReset() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err, strlen(err));
            }
        }
        else if (req.method == "POST" && (req.path == "/repair" || req.path.rfind("/repair?", 0) == 0)) {
            // ─── Repair manifold natif, EN LOT ET EN PARALLELE — mirror de /smooth ──
            // [11/08] Meme diagnostic que /smooth en son temps : mesure sur
            // Scania-Engine-V8-XT-Turbo.step (1297 corps, meme lot), repair
            // sequentiel client (pool 4 workers) = 234.6s vs smooth natif = 17.5s —
            // 13x d'ecart, meme classe de probleme (N corps geometriquement
            // independants). Cf. session Nass 11/08, chiffres [perf-step] mesures.
            //
            // Technique de repair identique au client (_manifoldRepair, step-import.js) :
            // weld (soudure vertices dupliques aux coutures, cf. weldMeshLocal —
            // deja utilisee ailleurs dans ce fichier, meme fonction que weldMeshForCSG
            // dans /csg) puis union d'un mesh avec une COPIE INDEPENDANTE de lui-meme.
            // Le simple weld suffit parfois, mais forcer le corps a travers le
            // pipeline de construction robuste du boolean Manifold repare des cas
            // qu'un check de validite seul ne repare pas — c'est le comportement
            // PROUVE cote client (1292/1297 corps repares avec succes, 2 runs
            // identiques), pas une hypothese : ce handler le reproduit a l'identique,
            // aucune optimisation "skip union si deja propre" — verifiee dangereuse
            // en theorie seulement (impossible de compiler/tester Manifold ici),
            // donc pas prise. Copies A/B strictement separees (pas des alias du
            // meme buffer) : meme prudence memoire que le commentaire /csg plus haut
            // ("Manifold ne copie pas forcement les donnees a la construction").
            //
            // DIFFERENCE CRITIQUE avec /smooth : un corps non-manifold est un
            // resultat NORMAL et FREQUENT ici (~5/1297 sur le fichier de reference),
            // pas une erreur rare. /smooth propage la PREMIERE exception et tue tout
            // le lot (firstErr + rethrow) ; /repair NE FAIT JAMAIS CA — un corps qui
            // echoue son repair retombe sur sa geometrie D'ORIGINE (inchangee,
            // indexee trivialement), exactement le fallback silencieux de
            // _manifoldRepair cote client. Seule une erreur de PROTOCOLE (requete
            // malformee, lecture hors-bornes) fait echouer la requete entiere.
            //
            // Protocole requete : [u32 meshCount] puis par mesh, triangle soup NON
            // indexe (meme forme que ce qu'envoie _manifoldRepair) : [u32 nVert]
            // [f32 x nVert*3 positions] — nTri implicite = nVert/3, indexation
            // triviale 0,1,2... consecutive par construction (pas d'index en entree).
            // Reponse : JSON header (jsonLen u32 LE, counts[]=nVertOut,
            // idxCounts[]=nIdxOut par mesh, repairedCount=nb de corps reellement
            // repares) puis par mesh dans l'ordre : positions f32 + indices u32.
            try {
                auto t0 = Clock::now();
                const std::string& b = req.body;
                if (b.size() < 4) throw std::runtime_error("/repair request body too short");
                size_t off = 0;
                auto rdU32 = [&](size_t& o)->uint32_t{
                    if (o + 4 > b.size()) throw std::runtime_error("/repair: out-of-bounds read");
                    uint32_t v; std::memcpy(&v, b.data()+o, 4); o += 4; return v;
                };
                uint32_t meshCount = rdU32(off);
                if (meshCount < 1) throw std::runtime_error("/repair: at least 1 mesh required");
                // Borne de coherence protocolaire (meme esprit que /smooth et /csg) :
                // chaque mesh occupe au moins 4 octets de header (nVert).
                if ((size_t)meshCount > b.size() / 4) throw std::runtime_error("/repair: meshCount inconsistent with request size (corrupt header)");

                std::vector<std::vector<float>> inPos(meshCount);
                for (uint32_t m = 0; m < meshCount; m++) {
                    uint32_t nVert = rdU32(off);
                    if (nVert % 3 != 0) throw std::runtime_error("/repair: nVert not a multiple of 3 (non-indexed triangle soup expected)");
                    size_t vBytes = (size_t)nVert * 3 * 4;
                    if (off + vBytes > b.size()) throw std::runtime_error("/repair: truncated mesh");
                    const float* vp = reinterpret_cast<const float*>(b.data() + off); off += vBytes;
                    inPos[m].assign(vp, vp + (size_t)nVert * 3);
                }

                // ── Parallelisation : chaque corps est independant, meme pattern
                // pull-based que /smooth (compteur atomique partage) ──
                std::vector<RepairResult> results(meshCount);
                unsigned nThreads = std::thread::hardware_concurrency();
                if (nThreads == 0) nThreads = 4; // hardware_concurrency() peut renvoyer 0, filet de secu
                nThreads = (unsigned)std::min((size_t)nThreads, (size_t)meshCount);
                std::atomic<uint32_t> nextIdx{0};
                std::atomic<uint32_t> repairedCount{0};
                // Barre REPAIR — meme technique que TESSELLATION/SMOOTH : compteur
                // atomique de completion + gConsoleMutex + lastDrawn monotone. Le
                // nombre repare/inchange (repairedCount) est deja calcule pour le
                // JSON final, on le refletra aussi en direct dans le suffixe.
                std::atomic<uint32_t> repairDone{0};
                uint32_t lastDrawnRepair = 0;
                barPhaseStart();
                std::vector<std::thread> pool;
                pool.reserve(nThreads);
                for (unsigned t = 0; t < nThreads; t++) {
                    pool.emplace_back([&]() {
                        for (;;) {
                            uint32_t m = nextIdx.fetch_add(1);
                            if (m >= meshCount) break;

                            const std::vector<float>& srcPos = inPos[m];
                            size_t nVert = srcPos.size() / 3;
                            std::vector<uint32_t> trivialIdx(nVert);
                            for (size_t i = 0; i < nVert; i++) trivialIdx[i] = (uint32_t)i;

                            // Fallback par defaut : geometrie d'origine, indexee
                            // trivialement. Ecrase plus bas UNIQUEMENT si le repair
                            // reussit reellement — un corps recalcitrant n'est jamais
                            // une exception a lever, juste un resultat inchange.
                            results[m].pos = srcPos;
                            results[m].idx = trivialIdx;
                            results[m].repaired = false;

                            ManifoldArena localMem; // libere ET detruit en fin d'iteration, succes ou echec
                            try {
                                // Copies INDEPENDANTES A et B (pas des alias) — meme
                                // prudence que vertsA/vertsB cote client JS.
                                std::vector<float> wPosA = srcPos;
                                std::vector<uint32_t> wIdxA = trivialIdx;
                                weldMeshLocal(wPosA, wIdxA);
                                std::vector<float> wPosB = srcPos;
                                std::vector<uint32_t> wIdxB = trivialIdx;
                                weldMeshLocal(wPosB, wIdxB);

                                ManifoldMeshGL* mgA = localMem.make(manifold_meshgl_size(), [&](void* p){
                                    return manifold_meshgl(p, wPosA.data(), wPosA.size()/3, 3,
                                                           wIdxA.data(), wIdxA.size()/3); });
                                ManifoldManifold* mA = localMem.make(manifold_manifold_size(), [&](void* p){
                                    return manifold_of_meshgl(p, mgA); });

                                ManifoldMeshGL* mgB = localMem.make(manifold_meshgl_size(), [&](void* p){
                                    return manifold_meshgl(p, wPosB.data(), wPosB.size()/3, 3,
                                                           wIdxB.data(), wIdxB.size()/3); });
                                ManifoldManifold* mB = localMem.make(manifold_manifold_size(), [&](void* p){
                                    return manifold_of_meshgl(p, mgB); });

                                ManifoldManifold* result = localMem.make(manifold_manifold_size(), [&](void* p){
                                    return manifold_boolean(p, mA, mB, MANIFOLD_ADD); });

                                if (manifold_status(result) == MANIFOLD_NO_ERROR && manifold_num_vert(result) > 0) {
                                    ManifoldMeshGL* outMesh = localMem.make(manifold_meshgl_size(), [&](void* p){
                                        return manifold_get_meshgl(p, result); });
                                    size_t outNV = manifold_meshgl_num_vert(outMesh), outNT = manifold_meshgl_num_tri(outMesh);
                                    if (outNV > 0 && outNT > 0) {
                                        float*    vertBuf = manifold_meshgl_vert_properties(localMem.raw(sizeof(float) * outNV * 3), outMesh);
                                        uint32_t* triBuf  = manifold_meshgl_tri_verts(localMem.raw(sizeof(uint32_t) * outNT * 3), outMesh);
                                        results[m].pos.assign(vertBuf, vertBuf + outNV * 3);
                                        results[m].idx.assign(triBuf, triBuf + outNT * 3);
                                        results[m].repaired = true;
                                        repairedCount.fetch_add(1);
                                    }
                                }
                                // Sinon (status != NO_ERROR, ou sortie vide) : results[m]
                                // reste au fallback pose plus haut. Attendu, pas une erreur.
                            } catch (...) {
                                // Meme filet que _manifoldRepair cote JS : un corps qui
                                // plante retombe sur son originale, silencieusement.
                                // results[m] deja pose au fallback avant le try.
                            }

                            uint32_t done = repairDone.fetch_add(1) + 1;
                            std::lock_guard<std::mutex> lk(gConsoleMutex);
                            if (done > lastDrawnRepair) {
                                int pct = (int)(100.0 * done / meshCount);
                                int prevPct = (int)(100.0 * lastDrawnRepair / meshCount);
                                if (pct != prevPct || done == meshCount) {
                                    drawBarLine("REPAIR", (double)done / meshCount,
                                        std::to_string(pct) + "%  (" + std::to_string(done) + "/" + std::to_string(meshCount) + ")  R:" + std::to_string(repairedCount.load()));
                                }
                                lastDrawnRepair = done;
                            }
                        }
                    });
                }
                for (auto& th : pool) th.join();

                auto t1 = Clock::now();
                double repairMs = ms(t0, t1);

                std::ostringstream json;
                json << "{\"success\":true,\"meshCount\":" << meshCount
                     << ",\"repairedCount\":" << repairedCount.load() << ",\"counts\":[";
                for (uint32_t m = 0; m < meshCount; m++) {
                    if (m) json << ",";
                    json << (results[m].pos.size() / 3);
                }
                json << "],\"idxCounts\":[";
                for (uint32_t m = 0; m < meshCount; m++) {
                    if (m) json << ",";
                    json << results[m].idx.size();
                }
                json << "],\"repairMs\":" << repairMs << "}";
                std::string js = json.str();
                uint32_t jl = (uint32_t)js.size();

                size_t totalBinBytes = 0;
                for (auto& r : results) totalBinBytes += r.pos.size() * 4 + r.idx.size() * 4;
                std::vector<uint8_t> out(4 + jl + totalBinBytes);
                out[0]=jl&0xFF; out[1]=(jl>>8)&0xFF; out[2]=(jl>>16)&0xFF; out[3]=(jl>>24)&0xFF;
                std::memcpy(out.data()+4, js.data(), jl);
                size_t wOff = 4 + jl;
                for (auto& r : results) {
                    std::memcpy(out.data()+wOff, r.pos.data(), r.pos.size()*4); wOff += r.pos.size()*4;
                    std::memcpy(out.data()+wOff, r.idx.data(), r.idx.size()*4); wOff += r.idx.size()*4;
                }

                std::cerr << cInfo() << "[POST /repair]" << cReset() << " " << meshCount << " mesh(es), " << nThreads << " thread(s) -> "
                          << repairMs << " ms (" << repairedCount.load() << "/" << meshCount
                          << " actually repaired, " << (meshCount - repairedCount.load()) << " unchanged fallback)\n";

                sendResponse(fd, 200, "OK", "application/octet-stream", (const char*)out.data(), out.size());
            } catch (const std::exception& e) {
                std::string err = std::string("{\"success\":false,\"error\":\"") + jsonEscape(e.what()) + "\"}";
                std::cerr << cErr() << "[POST /repair] ERROR:" << cReset() << " " << e.what() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err.data(), err.size());
            } catch (...) {
                const char* err = "{\"success\":false,\"error\":\"non-standard exception (repair)\"}";
                std::cerr << cErr() << "[POST /repair] non-standard ERROR" << cReset() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err, strlen(err));
            }
        }
        else if (req.method == "POST" && (req.path == "/step" || req.path.rfind("/step?", 0) == 0)) {
            double deflection = -1.0; // auto (ratio bbox) sauf ?deflection= explicite
            auto qpos = req.path.find('?');
            if (qpos != std::string::npos) {
                std::string q = req.path.substr(qpos + 1);
                auto dpos = q.find("deflection=");
                if (dpos != std::string::npos) {
                    try { deflection = std::stod(q.substr(dpos + 11)); } catch (...) {}
                }
            }
            logStepFileBanner(req.body, "/step");         // [28/08] nom du fichier importe
            try {
                double tessMs = 0; int faceCount = 0;
                auto t0 = Clock::now();
                std::vector<uint8_t> nstp = processStepBuffer(req.body, deflection, tessMs, faceCount);
                auto t1 = Clock::now();
                std::cerr << cInfo() << "[POST /step]" << cReset() << " " << (req.body.size()/1024.0) << " KB STEP -> "
                          << nstp.size()/1024.0 << " KB NSTP, " << faceCount << " faces, "
                          << ms(t0,t1) << " ms total\n";
                sendResponse(fd, 200, "OK", "application/octet-stream",
                             reinterpret_cast<const char*>(nstp.data()), nstp.size());
            } catch (const std::exception& e) {
                std::string err = std::string("{\"success\":false,\"error\":\"") + jsonEscape(e.what()) + "\"}";
                std::cerr << cErr() << "[POST /step] ERROR:" << cReset() << " " << e.what() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err.data(), err.size());
            } catch (...) {
                // Filet ultime : certaines erreurs OCCT remontent des types non derives
                // de std::exception (Standard_Failure selon la config de build) — le
                // serveur loggue et SURVIT, il ne s'eteint jamais sur un fichier hostile.
                const char* err = "{\"success\":false,\"error\":\"non-standard exception (OCCT?)\"}";
                std::cerr << cErr() << "[POST /step] non-standard exception caught - server still alive" << cReset() << "\n";
                sendResponse(fd, 500, "Internal Server Error", "application/json", err, strlen(err));
            }
        }
        else {
            const char* nf = "Not Found";
            sendResponse(fd, 404, "Not Found", "text/plain", nf, strlen(nf));
        }
        nasscadCloseSocket(fd);
    }
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
