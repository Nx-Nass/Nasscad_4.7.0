#!/bin/bash
# ============================================================================
# uninstall-linux.sh -- removes what install-linux.sh created. Nothing else.
#
# Deletes, and says so before doing it:
#   ~/nasscad-medusa/      engine, Manifold sources and build
#   ~/occt801_gcc/         OCCT 8.0.1 sources, build tree and install prefix
#                          (only exists if you took the --occt=source path)
#
# Leaves alone: the apt packages, and the NASSCAD folder with its web files.
# Removing build-essential or cmake because you uninstalled one application
# would be rude; the web files are yours, not this script's to delete.
#
# Usage:  bash uninstall-linux.sh [--yes]
# ============================================================================
set -u

NASSCAD_HOME="$HOME/nasscad-medusa"
OCCT_ROOT="$HOME/occt801_gcc"
ASSUME_YES=0
[ "${1:-}" = "--yes" ] && ASSUME_YES=1

echo "============================================================"
echo "  NASSCAD MEDUSA -- uninstall"
echo "============================================================"
echo ""

FOUND=0
for d in "$NASSCAD_HOME" "$OCCT_ROOT"; do
    if [ -d "$d" ]; then
        FOUND=1
        printf "  %-28s %s\n" "$(du -sh "$d" 2>/dev/null | cut -f1)" "$d"
    fi
done

if [ "$FOUND" = "0" ]; then
    echo "  Nothing to remove -- neither folder exists."
    exit 0
fi

echo ""
echo "  Left untouched: apt packages, and your NASSCAD folder with its web files."
echo ""

if [ "$ASSUME_YES" != "1" ]; then
    printf "  Delete the folders listed above? [y/N] "
    read -r ans
    case "$ans" in
        [yY]|[yY][eE][sS]) ;;
        *) echo "  Cancelled -- nothing removed."; exit 0 ;;
    esac
fi

if pkill -f 'nasscad_medusa$' 2>/dev/null; then
    echo "  Engine stopped."
    sleep 0.5
fi

for d in "$NASSCAD_HOME" "$OCCT_ROOT"; do
    if [ -d "$d" ]; then
        rm -rf "$d"
        echo "  Removed: $d"
    fi
done

echo ""
echo "  Done. Reinstall with: bash install-linux.sh"
