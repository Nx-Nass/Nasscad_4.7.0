@echo off
setlocal EnableDelayedExpansion
title NASSCAD MEDUSA launcher
cd /d "%~dp0"

REM ===========================================================================
REM  medusa.bat -- starts the MEDUSA engine inside WSL, then opens NASSCAD.
REM
REM  Replaces the "nasscad 4.7.0.exe" launcher when it has not been built
REM  (that one is compiled from nasscad.cpp, which is not shipped in
REM  DEPLOY.zip). Same job, no compilation needed.
REM
REM  ASCII only, no accents -- same rule as the other scripts here, avoids
REM  any display corruption in cmd.exe.
REM ===========================================================================

set "DISTRO=Ubuntu"
set "ENGINE=~/nasscad-medusa/engine"
set "PAGE=NASSCAD_V4_7_0.htm"

REM -- Arguments passes au moteur lui-meme ------------------------------------
REM Vide par defaut : depuis la version du 04/09 le moteur n'ecrit AUCUN
REM fichier de log tant qu'on ne le demande pas, son journal se lit a la
REM demande par GET /log (bouton meduse du panneau Logs de NASSCAD).
REM   Medusa_Engine_3.1.bat --logfile   retablit le medusa-logs-<date>.txt.
set "ENGINE_ARGS="
if /i "%~1"=="--logfile" set "ENGINE_ARGS= --logfile"

echo ============================================================
echo   NASSCAD MEDUSA -- WSL launcher
echo ============================================================
echo.

REM -- 1. Locate the NASSCAD folder ------------------------------------------
REM Detected by CONTENT, not by name: the right folder is the one holding the
REM page. Survives any future rename -- the same lesson deploy.bat learned on
REM 31/08, when the hard-coded folder name had stopped matching reality.
set "NASSCAD_DIR="
if exist "%~dp0%PAGE%" set "NASSCAD_DIR=%~dp0"
if not defined NASSCAD_DIR (
    for /d %%D in ("%USERPROFILE%\Downloads\*NASSCAD*") do (
        if exist "%%~fD\%PAGE%" set "NASSCAD_DIR=%%~fD"
    )
)
if not defined NASSCAD_DIR (
    echo   ERROR: no folder containing %PAGE% was found,
    echo          neither next to this script nor under
    echo          %USERPROFILE%\Downloads\
    echo.
    pause
    exit /b 1
)
echo   NASSCAD folder : !NASSCAD_DIR!

REM -- 2. Is WSL reachable? --------------------------------------------------
wsl -d %DISTRO% -- true >nul 2>&1
if errorlevel 1 (
    echo.
    echo   ERROR: WSL distribution "%DISTRO%" is not responding.
    echo          Check with:  wsl -l -v
    echo.
    pause
    exit /b 1
)

REM -- 3. Is the engine deployed? --------------------------------------------
wsl -d %DISTRO% bash -lc "test -x %ENGINE%/nasscad_medusa" >nul 2>&1
if errorlevel 1 (
    echo.
    echo   ERROR: the engine is not built yet.
    echo          Expected: %ENGINE%/nasscad_medusa
    echo.
    echo          Run deploy.bat once ^(first run builds OCCT 8.0.1,
    echo          15 to 60 minutes depending on the machine^).
    echo.
    pause
    exit /b 1
)
echo   Engine         : found in WSL
echo.

REM -- 4. Already running? ---------------------------------------------------
REM Starting a second instance would fail on bind() -- port 8765 already taken.
REM Better to detect it and go straight to opening the page.
curl -s -f -m 2 http://127.0.0.1:8765/ping >nul 2>&1
if not errorlevel 1 (
    echo   MEDUSA is ALREADY running -- reusing it.
    goto :open_page
)

REM -- 5. Start it in its own window -----------------------------------------
REM Its own window on purpose, not a detached background process: you can read
REM the log live, and closing that window stops the engine. No PID to hunt.
REM ';' and 'exec' rather than '&&' -- '&' is a cmd separator and does not
REM always survive the quoting through 'start'.
echo   Starting MEDUSA...
start "NASSCAD MEDUSA Engine" wsl -d %DISTRO% bash -lc "cd %ENGINE%; exec ./nasscad_medusa%ENGINE_ARGS%"

REM -- 6. Wait for it to answer ----------------------------------------------
set "READY=0"
for /l %%i in (1,1,20) do (
    if "!READY!"=="0" (
        curl -s -f -m 2 http://127.0.0.1:8765/ping >nul 2>&1
        if not errorlevel 1 (
            set "READY=1"
        ) else (
            timeout /t 1 /nobreak >nul
        )
    )
)

if "!READY!"=="0" (
    echo.
    echo   WARNING: no answer on http://127.0.0.1:8765/ping after 20 seconds.
    echo            The engine window is open -- read it, the reason is there.
    echo            Common cause: another process already holds port 8765.
    echo.
    REM [05/09] Ce message promettait un repli navigateur qui n'existe plus :
    REM depuis la 4.7.0, manifold.js est retire, il n'y a AUCUN repli WASM.
    echo   Opening NASSCAD anyway, but Union / Subtraction / Intersection will
    echo   refuse to run: since 4.7.0 there is no in-browser fallback. Viewing,
    echo   primitives, fillet, measure and import/export keep working.
    echo.
) else (
    echo   MEDUSA is up and answering on port 8765.
    for /f "delims=" %%p in ('curl -s -m 2 http://127.0.0.1:8765/ping 2^>nul') do echo   %%p
    echo.
)

:open_page
echo   Opening %PAGE%...
start "" "!NASSCAD_DIR!\%PAGE%"
echo.
echo ============================================================
echo   Done.
echo.
echo   IMPORTANT: NASSCAD probes MEDUSA ONCE per page session.
echo   If the page was already open before the engine started,
echo   press F5 -- otherwise it keeps believing MEDUSA is absent.
echo   The Logs panel must show:
echo     "NASSCAD Engine detected ^(native localhost companion^)"
echo.
echo   To stop the engine: close the "NASSCAD MEDUSA Engine" window,
echo   or run:  wsl -d %DISTRO% pkill -f nasscad_medusa
echo.
echo   The engine writes no log file. Read its journal from the Logs panel
echo   ^(jellyfish button^). Run this launcher with --logfile to get a
echo   medusa-logs-^<date^>.txt in Downloads as well.
echo ============================================================
echo.
timeout /t 8 /nobreak >nul
exit /b 0
