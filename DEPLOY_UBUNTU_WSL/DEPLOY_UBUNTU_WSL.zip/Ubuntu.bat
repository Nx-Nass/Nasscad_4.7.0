@echo off
setlocal enabledelayedexpansion
title Ubuntu (WSL) reset

:: Verifier que le script est lance en administrateur
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ===================================================
    echo   This script must be run as administrator.
    echo   Right-click the file -^> "Run as administrator"
    echo ===================================================
    pause
    exit /b 1
)

echo ===================================================
echo   Clean reset of Ubuntu (WSL)
echo ===================================================
echo.
echo WARNING: this will delete ALL data in the Ubuntu instance.
echo Press CTRL+C to cancel, or any key to continue...
pause

echo.
echo [1/2] Uninstalling Ubuntu...
wsl --unregister Ubuntu
if %errorlevel% neq 0 (
    echo.
    echo WARNING: the uninstall failed, or no instance named
    echo "Ubuntu" was found ^(check the exact name with "wsl -l -v"^).
    echo Continuing with the reinstall anyway...
)

echo.
echo [2/2] Reinstalling Ubuntu...
wsl --install -d Ubuntu
if %errorlevel% neq 0 (
    echo.
    echo WARNING: "wsl --install" failed ^(often a 429 /
    echo 0x801901ad error - GitHub rate-limiting the request^).
    echo Trying the Microsoft Store ^(winget^) instead...
    echo.
    winget install -e --id Canonical.Ubuntu --accept-package-agreements --accept-source-agreements
    if %errorlevel% neq 0 (
        echo.
        echo ERROR: both methods failed.
        echo Try again in a few minutes, or install "Ubuntu"
        echo manually from the Microsoft Store.
        pause
        exit /b 1
    )
)

echo.
echo ===================================================
echo   Done. An Ubuntu window will open separately to finish
echo   the setup ^(username / password^).
echo   Do not close this window until that is done.
echo ===================================================
pause
