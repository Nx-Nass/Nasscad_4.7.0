@echo off
REM deploy.bat - double-clic = deploiement complet + compilation + demarrage MEDUSA.
REM
REM Remplace toute l'ancienne chaine de scripts (deploy_all / install_medusa /
REM reinstall_medusa / provision_medusa) : un seul clic, qui s'adapte tout seul
REM a ce qui existe deja sur la machine (rien du tout / ancien "booster" /
REM "engine" deja installe) - plus besoin de choisir le bon script a la main.
REM
REM ASCII pur (pas d'accent, pas de tiret long) - meme lecon que les scripts
REM precedents : evite tout risque de corruption d'affichage dans cmd.exe.
REM
REM A placer DANS LE MEME DOSSIER que deploy.sh, nasscad_medusa.cpp, et
REM nasscad.cpp (launcher Windows -- recompile a chaque deploiement si
REM present ; sinon un "nasscad 4.7.0.exe" deja existant est deploye tel quel).
cd /d "%~dp0"
wsl bash deploy.sh
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ============================================
    echo Deployment failed ^(see above^) -- NASSCAD not started.
    echo ============================================
    pause >nul
    exit /b 1
)
echo.
REM [FIX 18/08] L'ancien lancement de l'exe etait inconditionnel -- plantait
REM (dialogue Windows "fichier introuvable") si l'exe n'existait pas encore a
REM cet endroit. On verifie maintenant sa presence avant de tenter le lancement.
REM
REM [FIX 31/08] Le dossier etait code en dur ("_1_NASSCAD_4.7.0_SHOGUN") et ne
REM correspond plus au dossier reel, renomme depuis en
REM "_NASSCAD_4.7.0_SHOGUN - PROVING GROUND" : le lancement echouait donc
REM toujours, avec le message "not found". On le DETECTE maintenant : le bon
REM dossier est celui qui contient NASSCAD_V4_7_0_DEV.htm -- il survivra a
REM n'importe quel renommage futur. Meme regle que dans deploy.sh.
set "NASSCAD_DIR="
for /d %%D in ("%USERPROFILE%\Downloads\*NASSCAD*") do (
    if exist "%%~fD\NASSCAD_V4_7_0_DEV.htm" set "NASSCAD_DIR=%%~fD"
)
if not defined NASSCAD_DIR (
    if exist "%USERPROFILE%\Downloads\_1_NASSCAD_4.7.0_SHOGUN" set "NASSCAD_DIR=%USERPROFILE%\Downloads\_1_NASSCAD_4.7.0_SHOGUN"
)

if not defined NASSCAD_DIR (
    echo ============================================
    echo Deployment done, but no NASSCAD folder containing
    echo NASSCAD_V4_7_0_DEV.htm was found under
    echo %USERPROFILE%\Downloads\
    echo ============================================
) else if exist "%NASSCAD_DIR%\nasscad 4.7.0.exe" (
    echo Starting NASSCAD from "%NASSCAD_DIR%"...
    start "" "%NASSCAD_DIR%\nasscad 4.7.0.exe"
    echo.
    echo ============================================
    echo Done. NASSCAD is starting.
    echo Press any key to close.
    echo ============================================
) else (
    echo ============================================
    echo Deployment done, but nasscad 4.7.0.exe was not found in
    echo %NASSCAD_DIR%\
    echo Start it manually from that folder once it has been built.
    echo ============================================
)
pause >nul