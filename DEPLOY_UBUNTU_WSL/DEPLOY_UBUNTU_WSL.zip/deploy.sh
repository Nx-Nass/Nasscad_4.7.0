#!/bin/bash
# deploy.sh -- deploiement + compilation NASSCAD MEDUSA, en UN SEUL script.
#
# Remplace toute l'ancienne chaine (deploy_all.sh + install_medusa.sh +
# reinstall_medusa.sh + provision_medusa.sh + build.sh + build_manifold.sh).
#
# [15/08 FIX v6] Demande explicite de Nass : reinstaller TOUTES les
# librairies necessaires A CHAQUE deploiement, comme sur une machine neuve --
# plus de "si deja construit, on saute cette etape". Chaque execution :
#   1. Paquets systeme (apt-get) -- toujours reinstalles/reverifies.
#   2. Manifold natif -- toujours reclone + recompile a partir de zero
#      (l'ancien manifold_src/, s'il existe, est supprime avant).
#   3. nasscad_medusa -- toujours recompile.
# Plus lent qu'un deploiement incremental (plusieurs minutes a chaque fois,
# le temps de la compilation de Manifold), mais garantit un environnement
# identique a une installation neuve a chaque lancement -- fini les
# divergences invisibles entre machines ou les restes d'une session
# precedente qui faussent un diagnostic.
#
# La seule chose encore automatique (pas une "reinstallation", juste ne pas
# perdre les fichiers d'une ancienne install au mauvais endroit) : si
# ~/nasscad-medusa/booster/ existe encore (ancien nom, avant le renommage en
# "engine"), il est renomme en engine/ avant que tout le reste ne soit
# reconstruit dedans.
#
# Usage : place ce script A COTE de nasscad_medusa.cpp, puis double-clique
# sur deploy.bat (ou : bash deploy.sh depuis un terminal Ubuntu/WSL).
set -e

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NASSCAD_HOME="$HOME/nasscad-medusa"
ENGINE_DIR="$NASSCAD_HOME/engine"
BOOSTER_DIR="$NASSCAD_HOME/booster"  # ancien nom -- migre automatiquement si trouve

# ── [01/09] OCCT 8.0.1 COMPILE DEPUIS LES SOURCES ──────────────────────────
# Avant cette date, ce script prenait OCCT par apt : 7.6.3 sur Ubuntu 24.04,
# 7.5.x sur 22.04, autre chose ailleurs. Le moteur compilait et fonctionnait,
# mais Windows et Linux ne tournaient pas sur le meme noyau CAO -- le maillage
# STEP pouvait diverger a la marge d'une version a l'autre, sans que rien ne
# le signale.
#
# On construit donc exactement la meme version que le build MSVC (8.0.1,
# tag V8_0_1) avec exactement les memes options, recopiees de build_msvc.bat :
# bibliotheques partagees, Visualization et Draw desactives, FreeType et
# FreeImage desactives, TBB active. Desactiver Visualization et Draw supprime
# du meme coup les dependances X11, Tcl/Tk et FreeType : sur une WSL sans
# serveur graphique, c'est ce qui rend le build possible sans rien installer
# de plus que TBB.
#
# EXCEPTION ASSUMEE a la regle "tout est reconstruit a chaque deploiement"
# enoncee en tete de ce fichier : OCCT est mis en CACHE. Le reconstruire a
# chaque lancement ajouterait 30 a 60 minutes a chaque deploiement, ce qui
# rendrait le script inutilisable au quotidien. Il est reconstruit uniquement
# si absent, si la version installee ne correspond pas, ou sur demande
# explicite : OCCT_REBUILD=1 bash deploy.sh
OCCT_VERSION="8.0.1"
OCCT_TAG="V8_0_1"
OCCT_ROOT="$HOME/occt801_gcc"
OCCT_SRC="$OCCT_ROOT/src"
OCCT_BUILD="$OCCT_ROOT/build"
OCCT_INSTALL="$OCCT_ROOT/install"
OCCT_INC="$OCCT_INSTALL/include/opencascade"
OCCT_LIB="$OCCT_INSTALL/lib"
OCCT_REBUILD="${OCCT_REBUILD:-0}"

vital() {
    if ! eval "$2"; then
        echo "    FAILED: $1"
        echo "    Stopping -- nothing left half-done."
        exit 1
    fi
    echo "    OK: $1"
}

echo "==================================================="
echo "  NASSCAD MEDUSA -- full (re)install + compilation"
echo "  (all libraries are reinstalled on every run)"
echo "==================================================="

# -- [0] Fichier source present a cote de ce script ------------------------
vital "nasscad_medusa.cpp found next to this script" "[ -f '$HERE/nasscad_medusa.cpp' ]"

# -- [1] Migration silencieuse d'une ancienne installation "booster" -------
if [ ! -d "$ENGINE_DIR" ] && [ -d "$BOOSTER_DIR" ]; then
    echo ""
    echo "[MIGRATION] Old 'booster/' install detected -> renamed to 'engine/'."
    mv "$BOOSTER_DIR" "$ENGINE_DIR"
fi
mkdir -p "$ENGINE_DIR"

# -- [2] Detection du schema de nommage OCCT (identique a l'ancien build.sh) --
detect_occt_libs() {
    # [01/09] La detection lit desormais NOTRE prefixe (OCCT 8.0.1 compile
    # ci-dessus) et non plus ldconfig, qui refletait la version apt du systeme.
    # La branche <=7.7 est conservee : elle ne sert plus au cas nominal, mais
    # elle evite un echec silencieux si quelqu'un pointe OCCT_INSTALL sur une
    # installation plus ancienne.
    if [ -f "$OCCT_LIB/libTKSTEP.so" ]; then
        echo "    OCCT <=7.7 layout (separate TKSTEP)"
        STEP_LIBS="-lTKSTEP -lTKSTEPBase -lTKSTEPAttr -lTKXSBase -lTKShHealing"
        XDE_STEP_LIBS="-lTKXDESTEP"
    else
        echo "    OCCT >=7.8 layout (TKDE/TKDESTEP consolidated)"
        STEP_LIBS="-lTKDE -lTKDESTEP -lTKXSBase -lTKShHealing"
        XDE_STEP_LIBS=""
    fi
    # [31/08] Affiche la version OCCT REELLE obtenue par apt. Elle depend de la
    # version d'Ubuntu (24.04 -> 7.6.3, par exemple) et n'est PAS la meme que
    # cote Windows, ou MSVC est compile contre OCCT 8.0.1 installe a la main.
    # Le code source de MEDUSA compile et fonctionne sur les deux (verifie), mais
    # le maillage STEP peut differer a la marge d'une version d'OCCT a l'autre.
    OCCT_VER="$(sed -n 's/^#define *OCC_VERSION_COMPLETE *"\([^"]*\)".*/\1/p' \
                "$OCCT_INC/Standard_Version.hxx" 2>/dev/null)"
    if [ "$OCCT_VER" = "$OCCT_VERSION" ]; then
        echo "    OCCT version: ${OCCT_VER}   [identical to the Windows/MSVC build]"
    else
        echo "    OCCT version: ${OCCT_VER:-unknown}   [WARNING: MSVC uses $OCCT_VERSION]"
    fi
}

# -- [3] Paquets systeme -- TOUJOURS reinstalles/reverifies ----------------
echo ""
echo "[step 1/3] System packages (OCCT + TBB + build tools)"
SUDO=""
[ "$(id -u)" = "0" ] || SUDO="sudo"
$SUDO apt-get update || echo "    (at least one repo failed -- continuing)"
# [01/09] Les paquets libocct-*-dev ont disparu de cette liste : OCCT n'est
# plus pris par apt mais compile depuis les sources a l'etape suivante, en
# 8.0.1, pour coller au build Windows. Ne les reintroduis pas -- leurs
# en-tetes dans /usr/include/opencascade masqueraient les notres a la
# compilation et tu croirais tourner sur 8.0.1 en tournant sur 7.6.
$SUDO apt-get install -y \
    build-essential cmake git curl \
    libtbb-dev \
    g++-mingw-w64-x86-64
vital "g++ installed" "command -v g++ >/dev/null 2>&1"
vital "cmake installed" "command -v cmake >/dev/null 2>&1"
vital "Windows cross-compiler installed (x86_64-w64-mingw32-g++)" "command -v x86_64-w64-mingw32-g++ >/dev/null 2>&1"

# -- [3bis] OCCT 8.0.1 depuis les sources -- MIS EN CACHE (cf. en-tete) -----
echo ""
echo "[step 2/4] OCCT $OCCT_VERSION from source (parity with the MSVC build)"

OCCT_HAVE=""
if [ -f "$OCCT_INC/Standard_Version.hxx" ]; then
    OCCT_HAVE="$(sed -n 's/^#define *OCC_VERSION_COMPLETE *"\([^"]*\)".*/\1/p' \
                 "$OCCT_INC/Standard_Version.hxx")"
fi

if [ "$OCCT_REBUILD" = "1" ]; then
    echo "    OCCT_REBUILD=1 -- removing $OCCT_ROOT"
    rm -rf "$OCCT_ROOT"
    OCCT_HAVE=""
fi

if [ "$OCCT_HAVE" = "$OCCT_VERSION" ]; then
    echo "    OCCT $OCCT_VERSION already installed in $OCCT_INSTALL -- reused."
    echo "    (force a rebuild with: OCCT_REBUILD=1 bash deploy.sh)"
else
    if [ -n "$OCCT_HAVE" ]; then
        echo "    Found OCCT $OCCT_HAVE, expected $OCCT_VERSION -- rebuilding."
        rm -rf "$OCCT_ROOT"
    fi
    echo "    Building OCCT $OCCT_VERSION -- 30 to 60 minutes on a first run."
    echo "    This happens ONCE; later deployments reuse it."
    mkdir -p "$OCCT_ROOT"
    [ -d "$OCCT_SRC/.git" ] || git clone --depth 1 --branch "$OCCT_TAG" \
        https://github.com/Open-Cascade-SAS/OCCT.git "$OCCT_SRC"
    vital "OCCT sources cloned" "[ -d '$OCCT_SRC/src' ]"

    mkdir -p "$OCCT_BUILD"
    # Options recopiees a l'identique de build_msvc.bat (moins la partie vcpkg,
    # inutile ici : TBB vient d'apt). Visualization et Draw coupes -- le moteur
    # n'affiche rien, il maille et calcule.
    ( cd "$OCCT_BUILD" && cmake "$OCCT_SRC" \
        -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_INSTALL_PREFIX="$OCCT_INSTALL" \
        -DBUILD_LIBRARY_TYPE=Shared \
        -DBUILD_DOC_Overview=OFF \
        -DBUILD_MODULE_Visualization=OFF \
        -DBUILD_MODULE_Draw=OFF \
        -DUSE_FREETYPE=OFF \
        -DUSE_TBB=ON \
        -DUSE_FREEIMAGE=OFF \
        -DUSE_OPENVR=OFF \
        -DUSE_FFMPEG=OFF )
    vital "OCCT configured" "[ -f '$OCCT_BUILD/Makefile' ]"

    ( cd "$OCCT_BUILD" && make -j"$(nproc)" && make install )
fi

vital "OCCT headers installed" "[ -f '$OCCT_INC/Standard_Version.hxx' ]"
vital "OCCT STEP toolkit built"  "[ -f '$OCCT_LIB/libTKDESTEP.so' ] || [ -f '$OCCT_LIB/libTKSTEP.so' ]"
vital "OCCT XCAF toolkit built"  "[ -f '$OCCT_LIB/libTKXCAF.so' ]"

# -- [4] Manifold natif -- TOUJOURS reclone + recompile a partir de zero ---
#
# [31/08] MANIFOLD_REF : vide par defaut = branche par defaut du depot (HEAD),
# comportement historique. Attention, c'est NON DETERMINISTE : deux
# deploiements a un mois d'intervalle ne produisent pas le meme moteur. Cote
# Windows, MSVC est lie a une archive Manifold FIGEE (manifold-3.5.2).
# Pour aligner Ubuntu sur une version precise, mets ici un tag ou un SHA :
#     MANIFOLD_REF="v3.5.1"
# Verifie d'abord que la reference existe vraiment :
#     git ls-remote --tags https://github.com/elalish/manifold.git
# (au 31/08/2026, HEAD declare 3.5.1 et il n'existe PAS de tag v3.5.2 :
#  l'archive Windows est un etat post-3.5.1 non tague, donc elle ne se
#  reproduit pas par un simple clone tague.)
MANIFOLD_REF="${MANIFOLD_REF:-}"

echo ""
echo "[step 2/3] Native Manifold (clone + build from scratch -- can take"
echo "            several minutes)"
rm -rf "$ENGINE_DIR/manifold_src" "$ENGINE_DIR/libmanifoldc.so"* "$ENGINE_DIR/libmanifold.so"*
if [ -n "$MANIFOLD_REF" ]; then
    echo "    Pinned Manifold reference: $MANIFOLD_REF"
    git clone --depth 1 --branch "$MANIFOLD_REF" https://github.com/elalish/manifold.git "$ENGINE_DIR/manifold_src"
else
    echo "    Manifold reference: default branch HEAD (NOT reproducible --"
    echo "    set MANIFOLD_REF=<tag|sha> to pin it)"
    git clone --depth 1 https://github.com/elalish/manifold.git "$ENGINE_DIR/manifold_src"
fi
vital "Manifold clone present" "[ -d '$ENGINE_DIR/manifold_src/.git' ]"
MANIFOLD_VER="$(sed -n 's/^set(MANIFOLD_VERSION_[A-Z]* \([0-9]*\)).*/\1/p' \
                "$ENGINE_DIR/manifold_src/CMakeLists.txt" | head -3 | paste -sd. -)"
echo "    Manifold version obtained: ${MANIFOLD_VER:-unknown}"
mkdir -p "$ENGINE_DIR/manifold_src/build"
(
    cd "$ENGINE_DIR/manifold_src/build"
    cmake .. -DCMAKE_BUILD_TYPE=Release -DMANIFOLD_PAR=ON -DMANIFOLD_TEST=OFF \
             -DMANIFOLD_PYBIND=OFF -DMANIFOLD_CBIND=ON
    make manifoldc -j"$(nproc)"
)
vital "libmanifoldc.so built" "[ -f '$ENGINE_DIR/manifold_src/build/bindings/c/libmanifoldc.so' ]"
vital "libmanifold.so built" "[ -f '$ENGINE_DIR/manifold_src/build/src/libmanifold.so' ]"
cp "$ENGINE_DIR/manifold_src/build/bindings/c/libmanifoldc.so"* "$ENGINE_DIR/"
cp "$ENGINE_DIR/manifold_src/build/src/libmanifold.so"* "$ENGINE_DIR/"
echo "    OK: native Manifold rebuilt from scratch."

# -- [5] Sources a jour + arret de l'ancien serveur -------------------------
echo ""
echo "[Sources] Copying the latest .cpp"
cp "$HERE/nasscad_medusa.cpp" "$ENGINE_DIR/nasscad_medusa.cpp"
echo "    OK: nasscad_medusa.cpp copied."
pkill -f 'nasscad_medusa$' 2>/dev/null && { echo "    Old server stopped."; sleep 0.5; } || echo "    No server to stop."

# -- [6] Compilation ---------------------------------------------------------
echo ""
echo "[step 3/3] Compiling nasscad_medusa"
detect_occt_libs
# [01/09] Trois changements par rapport a la version apt :
#   -I / -L pointent sur NOTRE OCCT 8.0.1, plus sur /usr/include/opencascade ;
#   un second -rpath vers $OCCT_LIB, sinon le binaire ne retrouve pas les .so
#     d'OCCT au lancement (ils ne sont pas dans le cache ldconfig du systeme) ;
#   --disable-new-dtags AJOUTE, et ce n'est pas cosmetique. Par defaut ld
#     emet un RUNPATH, qui n'est PAS consulte pour resoudre les dependances
#     DES dependances. Avec OCCT dans /usr/lib (installation apt) ca ne se
#     voyait pas : le cache ldconfig du systeme resolvait tout. Avec OCCT
#     dans un prefixe prive, libTKXCAF.so ne retrouve plus libTKVCAF.so et
#     le binaire refuse de demarrer -- "cannot open shared object file",
#     alors meme qu'il a compile et linke sans une erreur. Ce drapeau emet
#     un RPATH a la place, qui lui est herite. Verifie : 27 bibliotheques
#     introuvables avant, zero apres.
#   -lTKVCAF RETIRE. C'est la bibliotheque "Visualization CAF", elle n'existe
#     pas quand BUILD_MODULE_Visualization=OFF. Le build MSVC coupe deja ce
#     module et link sans elle : la preuve que le moteur ne s'en sert pas.
g++ -O2 -std=c++17 -pthread -I"$OCCT_INC" \
    -I"$ENGINE_DIR/manifold_src/bindings/c/include" \
    "$ENGINE_DIR/nasscad_medusa.cpp" -o "$ENGINE_DIR/nasscad_medusa" \
    -L"$ENGINE_DIR" -lmanifoldc \
    -L"$OCCT_LIB" -Wl,--disable-new-dtags -Wl,-rpath,'$ORIGIN' -Wl,-rpath,"$OCCT_LIB" \
    $STEP_LIBS $XDE_STEP_LIBS -lTKXCAF -lTKCAF -lTKLCAF \
    -lTKMesh -lTKTopAlgo -lTKGeomAlgo -lTKGeomBase \
    -lTKBRep -lTKG3d -lTKG2d -lTKMath -lTKernel
vital "nasscad_medusa binary produced" "[ -x '$ENGINE_DIR/nasscad_medusa' ]"
DEPS_MISSING=$(ldd "$ENGINE_DIR/nasscad_medusa" 2>/dev/null | grep "not found" || true)
vital "zero missing dependency (ldd)" "[ -z '$DEPS_MISSING' ]"

# -- [6bis] Launcher Windows -- TOUJOURS recompile depuis nasscad.cpp ------
# [16/08 FIX] nasscad.cpp corrige : ouvre desormais le .htm de l'appli par
# son chemin complet au lieu d'ouvrir juste le dossier -- fini le probleme
# ou le navigateur affichait un listing de fichiers faute d'index.html.
# Meme logique "tout reinstaller/recompiler a chaque fois" que le reste de
# ce script : le .exe livre n'est jamais un vieux binaire suppose a jour,
# toujours frais depuis la source.
echo ""
echo "[Windows Launcher] Compiling nasscad.cpp -> nasscad 4.7.0.exe (MinGW-w64)"
if [ -f "$HERE/nasscad.cpp" ]; then
    x86_64-w64-mingw32-g++ -O2 -std=c++17 -static \
        -o "$HERE/nasscad 4.7.0.exe" "$HERE/nasscad.cpp" -lshlwapi -lws2_32
    vital "nasscad 4.7.0.exe built from nasscad.cpp" "[ -f '$HERE/nasscad 4.7.0.exe' ]"
else
    echo "    [SKIP] nasscad.cpp not found next to this script -- any existing"
    echo "           'nasscad 4.7.0.exe' will be deployed as-is, not rebuilt."
fi

# -- [7] Fichiers Windows -> dossier NASSCAD (best-effort, comme avant) -----
#
# [31/08 FIX] Deux bugs corriges ici, tous deux invisibles jusqu'a une
# installation sur machine NEUVE :
#
#  1. Le dossier de destination etait code en dur ("_1_NASSCAD_4.7.0_SHOGUN").
#     Il ne correspond plus au dossier reel, qui a ete renomme depuis
#     ("_NASSCAD_4.7.0_SHOGUN - PROVING GROUND"). Resultat : le bloc entier
#     etait saute en silence. Il est desormais DETECTE : on cherche dans
#     Downloads le dossier qui contient NASSCAD_V4_7_0_DEV.htm, donc il
#     survit a n'importe quel renommage futur.
#
#  2. La liste de fichiers copies etait perimee (3 .js + un
#     clear_step_cache.html qui n'existe plus), alors que l'application en
#     exige 17 depuis les fusions (nasscad-io.js, nasscad-gens.js,
#     nasscad-draco.js, nasscad-fonts.js...). Sur une machine ou le dossier
#     etait vide, on deployait donc une application CASSEE. La liste est
#     maintenant l'ensemble exact des <script src> de NASSCAD_V4_7_0_DEV.htm,
#     plus les 3 gros blobs charges dynamiquement par step-import.js /
#     quick-fillet.js / step-xcaf.js.
NASSCAD_RUNTIME_FILES="
NASSCAD_V4_7_0_DEV.htm
three.js
nasscad-fonts.js
nasscad_logs.js
occt-import-js.js
nasscad-draco.js
occt-loader-b64.js
quick-fillet.js
step-import.js
nasscad-io.js
step-export.js
step-xcaf.js
nassscript.js
nasscad-materials.js
nasscad-gens.js
nasscad_occt_wasm.js
opencascade.wasm.data.js
opencascade.wasm.wasm
"

WIN_USERPROFILE="$(wslpath "$(cmd.exe /c echo %USERPROFILE% 2>/dev/null | tr -d '\r')" 2>/dev/null)"
if [ -n "$WIN_USERPROFILE" ] && [ -d "$WIN_USERPROFILE" ]; then
    # Detection : le dossier NASSCAD est celui qui contient le .htm.
    WIN_DST=""
    for d in "$WIN_USERPROFILE/Downloads/"*NASSCAD*/; do
        [ -f "$d/NASSCAD_V4_7_0_DEV.htm" ] && { WIN_DST="${d%/}"; break; }
    done
    # Repli sur l'ancien nom code en dur, au cas ou le .htm n'y soit pas encore.
    [ -z "$WIN_DST" ] && [ -d "$WIN_USERPROFILE/Downloads/_1_NASSCAD_4.7.0_SHOGUN" ] \
        && WIN_DST="$WIN_USERPROFILE/Downloads/_1_NASSCAD_4.7.0_SHOGUN"
    if [ -n "$WIN_DST" ] && [ -d "$WIN_DST" ]; then
        echo ""
        echo "[Windows files] -> $WIN_DST"
        _copied=0; _absent=""
        # NB: la liste est parcourue non quotee EXPRES (c'est ce qui la
        # decoupe en mots) -- aucun nom de fichier de l'application ne
        # contient d'espace. Le launcher "nasscad 4.7.0.exe", lui, en
        # contient : il est traite separement plus bas, hors de la boucle.
        for f in $NASSCAD_RUNTIME_FILES; do
            if [ -f "$HERE/$f" ]; then
                cp "$HERE/$f" "$WIN_DST/$f"
                echo "    OK: $f"
                _copied=$((_copied+1))
            elif [ ! -f "$WIN_DST/$f" ]; then
                # Ni a cote du script, ni deja en place cote Windows : l'appli
                # sera cassee. On le DIT, au lieu de sauter en silence.
                _absent="$_absent
$f"
            fi
        done
        # Launcher Windows : optionnel (recompile plus haut s'il y a
        # nasscad.cpp, sinon on deploie celui deja present tel quel), donc
        # jamais signale comme manquant.
        if [ -f "$HERE/nasscad 4.7.0.exe" ]; then
            cp "$HERE/nasscad 4.7.0.exe" "$WIN_DST/nasscad 4.7.0.exe"
            echo "    OK: nasscad 4.7.0.exe"
            _copied=$((_copied+1))
        fi
        echo "    $_copied file(s) copied."
        if [ -n "$_absent" ]; then
            echo "    WARNING: required by NASSCAD_V4_7_0_DEV.htm but found"
            echo "             neither next to deploy.sh nor in the target folder:"
            printf '%s\n' "$_absent" | sed '/^$/d;s/^/               - /'
        fi

        # -- [7bis] index.html -- filet de securite, plus la ligne principale --
        # Desormais que le launcher recompile (etape ci-dessus) ouvre le .htm
        # par son chemin complet, ceci ne sert plus qu'en secours (ex. si la
        # compilation MinGW a echoue plus haut et qu'un vieil exe est deploye
        # tel quel). Ne fait de mal dans aucun cas -- laisse en place.
        if [ -f "$HERE/NASSCAD_V4_7_0_DEV.htm" ]; then
            cp "$HERE/NASSCAD_V4_7_0_DEV.htm" "$WIN_DST/index.html"
            echo "    OK: index.html (safety net, generated from NASSCAD_V4_7_0_DEV.htm)"
        fi
    else
        echo ""
        echo "[Windows files] SKIPPED -- no folder matching *NASSCAD* containing"
        echo "                NASSCAD_V4_7_0_DEV.htm found under Downloads."
    fi
fi

# -- [8] Auto-test bref -- demarre, verifie /ping, arrete --------------------
# [FIX] Ne demarre plus MEDUSA en premier plan indefiniment ici. Le launcher
# Windows (nasscad.cpp, compile a l'etape [Launcher Windows] plus haut)
# demarre desormais MEDUSA lui-meme, dans sa propre fenetre WSL, quand on
# double-clique l'exe. Le laisser tourner EN PLUS ici bloquerait deploy.sh
# indefiniment (deploy.bat n'aurait jamais la main pour lancer l'exe) ET
# ferait entrer deux instances en conflit sur le port 8765 (bind() failed --
# meme risque que pkill guettait deja dans install_medusa.sh). A la place :
# meme principe d'auto-test que install_medusa.sh -- demarre, verifie que
# /ping repond, arrete proprement. Le launcher redemarre un serveur frais
# a l'ouverture reelle.
# -- [7bis] Auto-test du decodage couleur -----------------------------------
# [01/09] Quelques millisecondes, aucun fichier, aucun serveur. Verifie
# l'aller-retour sRGB et la table de precedence solide/faces sur les cas
# limites releves dans de vrais exports CAO. C'est le controle le moins cher
# du script et celui qui attrape la regression la plus vicieuse : une couleur
# fausse ne fait pas planter, elle s'affiche.
#
# 'timeout' n'est pas decoratif : un binaire compile depuis un ancien .cpp ne
# connait pas ce drapeau, interprete "--selftest-colors" comme un numero de
# port et demarre un serveur qui ne rend jamais la main. Le timeout coupe, et
# le grep sur ALL PASS distingue "a repondu" de "a repondu la bonne chose".
echo ""
echo "==================================================="
echo "  Colour decoding self-test"
echo "==================================================="
cd "$ENGINE_DIR"
if timeout 30 ./nasscad_medusa --selftest-colors >/tmp/nasscad_selftest.log 2>&1 \
   && grep -q "ALL PASS" /tmp/nasscad_selftest.log; then
    sed 's/^/    /' /tmp/nasscad_selftest.log
    echo "    OK: colour decoding verified."
else
    echo "    FAILED: the colour self-test did not pass."
    sed 's/^/    /' /tmp/nasscad_selftest.log 2>/dev/null || true
    echo "    (an empty log means the binary does not know --selftest-colors:"
    echo "     it was built from an outdated nasscad_medusa.cpp)"
    exit 1
fi

echo ""
echo "==================================================="
echo "  Smoke test (brief start + /ping + stop)"
echo "==================================================="
cd "$ENGINE_DIR"
pkill -f 'nasscad_medusa$' 2>/dev/null && sleep 0.5 || true
./nasscad_medusa >/tmp/nasscad_medusa_smoketest.log 2>&1 &
_PID=$!
sleep 1
if kill -0 "$_PID" 2>/dev/null && curl -s -f "http://127.0.0.1:8765/ping" >/tmp/nasscad_medusa_ping.json 2>/dev/null; then
    echo "    OK: server started and responding: $(cat /tmp/nasscad_medusa_ping.json)"
    # [31/08] Verification de PARITE avec la version MSVC. /ping annonce
    # "csgtree":true seulement si l'endpoint /csgtree natif est compile dedans.
    # C'est LA difference entre ce binaire et celui livre jusqu'ici cote
    # Ubuntu (qui ne l'avait pas du tout) : sans lui, NASSCAD retombe sur
    # l'evaluation operation-par-operation, bien plus lente sur les arbres CSG.
    if grep -q '"csgtree":true' /tmp/nasscad_medusa_ping.json; then
        echo "    OK: native CSG tree endpoint present (parity with the MSVC build)."
    else
        echo "    WARNING: /ping does not advertise csgtree -- this binary was built"
        echo "             from an OLD nasscad_medusa.cpp. NASSCAD will fall back to"
        echo "             the slower per-operation CSG path."
    fi
else
    echo "    FAILED: server not responding -- see /tmp/nasscad_medusa_smoketest.log"
    kill "$_PID" 2>/dev/null || true; wait "$_PID" 2>/dev/null || true
    exit 1
fi
kill "$_PID" 2>/dev/null || true
wait "$_PID" 2>/dev/null || true
echo "    OK: server stopped cleanly -- the launcher will start a fresh one on open."