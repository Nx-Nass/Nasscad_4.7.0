@echo off
REM uninstall.bat - double-clic = desinstallation COMPLETE et PROPRE de NASSCAD
REM MEDUSA cote WSL (supprime pour de vrai, pas une simple archive comme
REM l'ancien uninstall_medusa.bat). Demande une confirmation avant de
REM supprimer quoi que ce soit.
REM
REM ASCII pur (pas d'accent, pas de tiret long) - meme lecon que les autres
REM scripts .bat de ce projet.
REM
REM A placer DANS LE MEME DOSSIER que uninstall.sh.
cd /d "%~dp0"
wsl bash uninstall.sh
echo.
echo ============================================
echo Done ^(or cancelled / error above - read it^).
echo Press any key to close.
echo ============================================
pause >nul
