#!/bin/bash
# uninstall.sh -- COMPLETE, CLEAN removal of NASSCAD MEDUSA from this WSL.
#
# Unlike the old uninstall_medusa.sh (which archived without ever deleting --
# engine.old.<timestamp>/ folders piling up forever, zero disk space recovered),
# this one really removes everything the project put on this WSL: the running
# server, the whole of ~/nasscad-medusa/ (engine/, booster/, and any .old.*
# archive that may have accumulated), the private OpenCASCADE 8.0.1 prefix, and
# the temporary files left by the install tests.
#
# [01/09] The OCCT prefix is listed here because deploy.sh no longer installs
# the libocct-*-dev packages: it builds OpenCASCADE 8.0.1 from source into
# ~/occt801_gcc for strict parity with the MSVC build. That tree is several GB.
# Leaving it behind while announcing "no trace left" would simply be untrue.
#
# Nothing outside those two prefixes is touched -- no system package (TBB,
# build-essential, cmake, git) is removed: they are shared libraries that may
# well serve something else on this machine, not files owned by this project.
set -e

NASSCAD_HOME="$HOME/nasscad-medusa"
OCCT_ROOT="$HOME/occt801_gcc"

echo "==================================================="
echo "  NASSCAD MEDUSA -- full uninstall"
echo "==================================================="

if [ ! -d "$NASSCAD_HOME" ] && [ ! -d "$OCCT_ROOT" ]; then
    echo ""
    echo "Nothing to do: neither $NASSCAD_HOME nor $OCCT_ROOT exists."
    exit 0
fi

echo ""
echo "About to be removed:"
for d in "$NASSCAD_HOME" "$OCCT_ROOT"; do
    [ -d "$d" ] || continue
    du -sh "$d" 2>/dev/null | awk '{print "    " $2 "  (" $1 ")"}'
    find "$d" -maxdepth 1 -mindepth 1 | sed 's/^/    - /'
done

echo ""
read -p "Confirm permanent deletion? [y/N] " _rep
case "$_rep" in
    [yY]|[yY][eE][sS]) ;;
    *)
        echo ""
        echo "Cancelled -- nothing was removed."
        exit 0 ;;
esac

echo ""
echo "[1/2] Stopping the server"
pkill -f 'nasscad_medusa$' 2>/dev/null && { echo "    Server stopped."; sleep 0.5; } || echo "    No server running."

echo ""
echo "[2/2] Removing the folders"
for d in "$NASSCAD_HOME" "$OCCT_ROOT"; do
    [ -d "$d" ] || continue
    rm -rf "$d"
    echo "    Removed: $d"
done
# [31/08 FIX] The first two names date back to the old install_medusa.sh and are
# never created any more: deploy.sh now writes nasscad_medusa_*. All four are
# cleaned up, to also cover a machine where an older install left its own behind.
rm -f /tmp/medusa_install_test.log /tmp/medusa_install_ping.json \
      /tmp/nasscad_medusa_smoketest.log /tmp/nasscad_medusa_ping.json

LEFT=""
for d in "$NASSCAD_HOME" "$OCCT_ROOT"; do
    [ -d "$d" ] && LEFT="$LEFT $d"
done
if [ -z "$LEFT" ]; then
    echo "    OK: everything removed."
else
    echo "    WARNING: still present --$LEFT"
    echo "    Check the permissions (sudo?)."
    exit 1
fi

echo ""
echo "==================================================="
echo "  Done -- no trace of NASSCAD MEDUSA left on this WSL."
echo "  (the TBB/build-essential/cmake/git system packages stay in"
echo "   place -- shared libraries, not files owned by this project."
echo "   Remove them yourself if you really want to start from a"
echo "   clean slate: apt-get remove libtbb-dev)"
echo "==================================================="
