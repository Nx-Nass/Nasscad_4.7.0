# Building NASSCAD Medusa Engine on a fresh Windows machine

`Nasscad_Medusa_Engine_3.1.exe` is the native companion that NASSCAD talks to on
`127.0.0.1:8765`. It reads STEP files, tessellates them and runs boolean CSG —
work the browser cannot do at that scale.

Everything is driven by **`build_msvc.bat`**. You install three things by hand;
the script fetches and builds the rest.

---

## 1. Prerequisites

| Requirement | Why, and what exactly |
|---|---|
| **Windows x64** | 32-bit is not viable — the engine warns at startup that the address space caps at ~2–4 GB regardless of installed RAM. |
| **Visual Studio 2022 (v17) or 2026 (v18)** | Workload **Desktop development with C++**, x64 toolchain (`Microsoft.VisualCpp.Tools.HostX64.TargetX64`). **Community edition is enough.** The script locates it with `vswhere.exe` and **rejects any other major version** — VS 2019 will stop the build at step 1/9. |
| **CMake 3.21 or newer** | Must be reachable as plain `cmake`. **Install it standalone** — see §1.1. The script tests it *after* activating the MSVC environment, so a CMake bundled with Visual Studio may or may not be visible depending on your installation; a standalone install removes the question. |
| **Git** | On the PATH. Used to clone vcpkg, Manifold and OCCT. |
| **Internet access** | Three repositories are cloned on first run. |
| **~15–25 GB free disk** | Almost all of it is the OCCT build tree. |

### Quick install

```bat
winget install Kitware.CMake
winget install Git.Git
winget install Microsoft.VisualStudio.2022.Community
```

> **`winget` installs Visual Studio but not the C++ workload.** Open *Visual
> Studio Installer* afterwards, select your VS installation → *Modify* → tick
> **Desktop development with C++**. Without it `vswhere` finds nothing and the
> build stops immediately.

Reopen a terminal after installing so the PATH is refreshed.

### 1.1 CMake — install the right version, and check it

This is the prerequisite that wastes the most time, because the failure is
delayed and the message is unhelpful. Two separate things can go wrong: CMake
missing from the PATH, or CMake present but too old.

**What the script actually does.** It runs `cmake --version` and stops with
`ERROR: CMake not found.` if that fails. That is the only check — **it never
looks at the version number**, it just prints it. The real floor, `3.21`, is
declared in `CMakeLists.txt` and is only enforced much later, at configure time
(step 7/9), after you have already waited through the whole OCCT build. Check it
before you start.

**Install:**

```bat
winget install Kitware.CMake
```

That gives you the current release, far above the 3.21 floor. To pin an exact
version instead:

```bat
winget install Kitware.CMake --version 3.31.6
```

No winget? Take the `.msi` from <https://cmake.org/download/> and, in the
installer, select **Add CMake to the system PATH for all users**. That checkbox
is not ticked by default and skipping it is the usual cause of
`ERROR: CMake not found.`

**Then verify — in a freshly opened terminal:**

```bat
cmake --version
```

You want `cmake version 3.21.0` or higher on the first line. If the command is
not recognised, CMake is installed but not on the PATH: either reinstall with
the PATH option, or add its `bin` folder manually
(typically `C:\Program Files\CMake\bin`).

> The CMake shipped inside Visual Studio (*C++ CMake tools for Windows*) lives
> under the VS installation and is not added to the system PATH. It is reliably
> available inside a Developer Command Prompt, but this script runs from a plain
> `cmd` and calls `vcvars64.bat` itself, which does not guarantee exposing it.
> Install CMake standalone and the question disappears.

---

## 2. Put the sources in place

Extract **all ten files** from `Medusa_Engine_MSVC.zip` into **one folder**:

```
nasscad_medusa.cpp          the engine
CMakeLists.txt              build definition
build_msvc.bat              the build script
vcpkg.json                  dependency manifest (clipper2 + tbb)
vcpkg-configuration.json    pinned vcpkg baseline
nasscad_medusa.rc           Windows resources (icon + version info)
Nasscad_V4.ico              application icon

build_medusa_onefile.bat    all-in-one packaging (step 9/9)
medusa_onefile.c            self-extracting stub, compiled by cl /MT
medusa_onefile.rc           stub version resource
```

The script takes its own directory as the project root and looks for the other
files beside it. Splitting them across folders breaks the build.

---

## 3. Build

Open a **plain `cmd`** in that folder and run:

```bat
build_msvc.bat
```

Do **not** use an already-configured Developer Command Prompt — the script calls
`vcvars64.bat` itself.

First run on a fresh machine: **40 to 90 minutes**, most of it OCCT. Later runs
are near-instant, everything is cached outside the project folder.

> Add the three build directories to your antivirus exclusions before starting.
> Real-time scanning can roughly double the OCCT build time.

---

## 4. What the script does

| Step | Action | Lands in |
|---|---|---|
| 1/9 | Detect Visual Studio, activate the x64 toolchain | — |
| 2/9 | Bootstrap **vcpkg** | `%VS_PATH%\VC\vcpkg` if present, else `%LOCALAPPDATA%\vcpkg` |
| 3/9 | `vcpkg install` against a **pinned baseline** — clipper2 + tbb | `vcpkg_installed\` |
| 4/9 | Clone and build **Manifold 3.5.3** (tag `v3.5.3`) with C bindings | `%USERPROFILE%\manifold35_msvc` |
| 5/9 | Clone and build **OCCT 8.0.1** (tag `V8_0_1`) from source | `%USERPROFILE%\occt801_msvc` |
| 6/9 | Stop any engine already running on port 8765 | — |
| 7/9 | CMake configure + build `nasscad_medusa` | `build_msvc\` |
| 8/9 | Start the exe and self-test `GET /ping` | — |
| 9/9 | Pack engine + DLLs into a single `.exe`, then self-test it too | next to `build_msvc.bat` |

At the end it copies the executable **and every required DLL** (OCCT, Manifold,
vcpkg) next to `build_msvc.bat`, so the folder is directly runnable and
directly shippable.

The vcpkg baseline is pinned on purpose (`4334d8b4c8916018600212ab4dd4bbdc343065d1`):
two machines building months apart get the same dependency versions.

---

## 5. Verify

Two checks, both fast.

**Colour decoding logic** — no file, no server, a few milliseconds:

```bat
Nasscad_Medusa_Engine_3.1.exe --selftest-colors
```

Expected last line:

```
ALL PASS — 0 failure(s)
```

It exercises the sRGB round-trip and the solid-vs-face colour precedence table
on the edge cases actually found in real CAD exports. A failure here means a
refactor broke colour handling — stop and look before shipping.

**Server** — start the engine, then from another terminal:

```bat
curl http://127.0.0.1:8765/ping
```

The build script already does this at step 8/9. If it reports *no /ping response
after 10 seconds*, it usually means a missing DLL beside the exe (see
Troubleshooting) or the port is taken.

---

## 6. The all-in-one (single .exe)

Step 9/9 packs the engine and its 54 DLLs into **one** executable —
`Medusa_Engine_<version>.exe`, about 52 MB — beside the normal build output.

Nothing is compressed or obfuscated: a small self-extracting stub is prepended
to the files, followed by a manifest and a 28-byte footer (format `NMDSFX01`,
documented in `ONEFILE-reverse-engineering.md`). On first launch the stub
unpacks everything into `%LOCALAPPDATA%\NasscadMedusa\<stamp>\`, drops a
`.ready` marker, starts the engine, forwards its arguments and returns its exit
code. Later launches skip the extraction. The all-in-one therefore behaves
exactly like the engine on the command line — stdout, Ctrl-C, exit code.

The stub is compiled by `cl /O2 /MT` from `medusa_onefile.c`, so its CRT is
static and it depends on nothing. Three files must sit beside `build_msvc.bat`
for the step to run: `build_medusa_onefile.bat`, `medusa_onefile.c` and
`medusa_onefile.rc`. If they are missing, the step is skipped with a message and
the build is still a success.

The stub carries the same icon as the engine, through `medusa_onefile.rc`
(`IDI_ICON1 ICON "Nasscad_V4.ico"`, guarded by `#ifdef HAVE_ICON` so a missing
`.ico` only costs the icon, never the build). `Nasscad_V4.ico` holds ten images,
16 to 256 — a lone 256x256 PNG entry makes Explorer fall back to the generic
icon in list and details views, which is exactly how the all-in-one used to show
up blank.

The step runs **after** the `/ping` self-test — a build that does not answer is
never packaged — and then pings the all-in-one itself. That second test is the
only one that exercises the extraction path, which is where real-world failures
happen: antivirus, locked folder, full disk.

Packaging alone, without rebuilding:

```bat
build_medusa_onefile.bat
build_medusa_onefile.bat --stamp 1789368682   :: replay an old package byte for byte
```

> **The all-in-one still needs the Visual C++ Redistributable** on the target
> machine: the engine imports `MSVCP140.dll` and `VCRUNTIME140*.dll`, which are
> not embedded. To make it truly standalone, drop those DLLs into the folder
> before packaging — they get inlined like the rest, no format change needed.

> Nothing is cleaned up client-side: every build leaves ~52 MB under
> `%LOCALAPPDATA%\NasscadMedusa\`. Deleting a folder's `.ready` marker forces a
> clean re-extraction.

---

## 7. Options

```bat
build_msvc.bat --rebuild             :: wipe vcpkg_installed, Manifold and OCCT, rebuild all
build_msvc.bat --rebuild-occt        :: rebuild OCCT only
build_msvc.bat --rebuild-manifold    :: rebuild Manifold only
build_msvc.bat --no-bundle           :: do not copy DLLs next to the exe
build_msvc.bat --no-test             :: skip the /ping self-test
build_msvc.bat --no-onefile          :: skip the all-in-one packaging
```

When one dependency misbehaves, rebuild that one — not everything. A full
`--rebuild` costs you the whole OCCT build again.

---

## 8. Troubleshooting

| Message | Cause and fix |
|---|---|
| `WARNING: no /ping response from the all-in-one after 20 seconds.` | The stub could not unpack, or the engine did not start. Look under `%LOCALAPPDATA%\NasscadMedusa\` — antivirus quarantine and a full disk are the usual causes. Delete the `.ready` file there to force a clean re-extraction. |
| `ERROR: vswhere.exe not found.` | Visual Studio is not installed, or only the Build Tools without the Installer. Install VS 2022/2026. |
| `ERROR: Visual Studio with x64 C++ tools not found.` | VS is there but the C++ workload is missing. Installer → Modify → **Desktop development with C++**. |
| `ERROR: unsupported Visual Studio version:` | Only major 17 (2022) and 18 (2026) are handled. |
| `ERROR: CMake not found.` | CMake is absent, or installed without the PATH option. See §1.1 — install standalone, tick *Add CMake to the system PATH*, then **open a new terminal**. |
| `ERROR: Git not found.` | Same thing for Git. Install, reopen the terminal. |
| At step 7/9: `CMake 3.21 or higher is required` | Your CMake is older than the floor. The script did not catch it earlier — it only checks that `cmake` runs, never the version. Upgrade (§1.1) and re-run; OCCT and Manifold are cached, you will not rebuild them. |
| `ERROR: MSVC x64 activation failed.` | `vcvars64.bat` did not run. Usually a damaged VS installation — repair it from the Installer. |
| `ERROR: OCCT toolkits missing.` | The OCCT build did not finish. Re-run with `--rebuild-occt` and read the CMake output. |
| `ERROR: vcpkg.json still contains "cbind".` | Stale manifest — take the `vcpkg.json` shipped in the zip. |
| `Manifold version mismatch: found …` (step 7/9) or `installed Manifold is not …` (step 4/9) | The cached build in `%USERPROFILE%\manifold35_msvc` is not the version the script pins. Run `build_msvc.bat --rebuild-manifold`. vcpkg no longer provides Manifold at all: the engine only accepts the one built at step 4/9, the same version as the Linux and WSL packages. |
| `WARNING: no /ping response after 10 seconds.` | The exe starts but does not answer. Check that the OCCT and Manifold DLLs sit next to it (do not use `--no-bundle`), and that nothing else holds port 8765. |
| Build succeeds, NASSCAD does not see the engine | The engine must be **running** when you import. NASSCAD probes `127.0.0.1:8765` once per session — reload the page after starting it. |

---

## 9. Why bother

Without this companion NASSCAD still opens STEP files in the browser alone, but
with two measured limits: colours come **per part only** — the in-browser engine
exposes no per-face colour at all — and large assemblies may tessellate to
nothing. Files up to roughly 20 MB are comfortable in the browser; beyond that,
the companion is not an accelerator, it is the requirement.
