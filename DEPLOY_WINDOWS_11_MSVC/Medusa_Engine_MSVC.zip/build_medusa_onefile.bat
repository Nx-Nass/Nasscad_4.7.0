@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
set "PROJ=%cd%"

:: IMPORTANT : chemin de CE fichier capture AVANT la boucle d'options.
:: "shift" decale aussi %0, donc %~f0 ne designe plus le .bat une fois les
:: arguments consommes -- et le packer PowerShell, qui relit ce fichier, se
:: retrouvait a analyser le dernier argument passe.
set "SELF=%~f0"

:: ============================================================================
:: build_medusa_onefile.bat
::
:: Fabrique le .exe "all-in-one" (Medusa inline) : stub auto-extracteur
:: + moteur + toutes les DLL concatenes dans un seul executable.
::
:: Format produit : NMDSFX01 (retro-ingenierie de Medusa_Engine_3.1.exe,
:: stamp 1789368682 = 14/09/2026 08:51:22). Le meme algorithme rejoue sur
:: les fichiers d'origine redonne l'exe au bit pres (MD5 identique).
::
:: Appele automatiquement par l'etape [9/9] de build_msvc.bat, qui vient de
:: deposer le moteur et les 54 DLL a plat dans Medusa_Engine_MSVC\ -- c'est
:: exactement l'entree attendue ici. Peut aussi tourner seul.
::
:: Le stub est compile avec cl.exe (MSVC) : c'est deja la chaine du projet, et
:: /MT le rend independant du redistribuable. Repli sur gcc (MinGW) si cl est
:: introuvable, ou --stub pour reutiliser un stub deja compile.
:: ============================================================================

:: ============================================================================
:: OPTIONS
:: ============================================================================
set "SRC_DIR=%PROJ%"
set "OUT="
set "STUB="
set "STAMP="
set "ENGINE="
set "OPT_KEEP=0"
set "PAUSE_CMD=pause"

:parse_args
if "%~1"=="" goto end_parse

if /i "%~1"=="--src" (
    set "SRC_DIR=%~2"
    shift
    shift
    goto parse_args
)

if /i "%~1"=="--out" (
    set "OUT=%~2"
    shift
    shift
    goto parse_args
)

if /i "%~1"=="--stub" (
    set "STUB=%~2"
    shift
    shift
    goto parse_args
)

if /i "%~1"=="--stamp" (
    set "STAMP=%~2"
    shift
    shift
    goto parse_args
)

if /i "%~1"=="--engine" (
    set "ENGINE=%~2"
    shift
    shift
    goto parse_args
)

if /i "%~1"=="--keep" (
    set "OPT_KEEP=1"
    shift
    goto parse_args
)

if /i "%~1"=="--nopause" (
    set "PAUSE_CMD=rem"
    shift
    goto parse_args
)

echo ERROR: unknown option: %~1
echo.
echo Options:
echo   --src    ^<dir^>    dossier moteur + DLL      (defaut : dossier du .bat)
echo   --out    ^<file^>   exe all-in-one produit    (defaut : %%SRC%%\Medusa_Engine_^<ver^>.exe)
echo   --stub   ^<file^>   stub deja compile         (defaut : compile medusa_onefile.c)
echo   --stamp  ^<n^>      stamp unix a graver       (defaut : maintenant)
echo   --engine ^<file^>   nom de l'exe moteur       (defaut : le plus recent)
echo   --keep            garder le stub compile
echo   --nopause         pas de pause finale        (appel depuis un autre .bat)
%PAUSE_CMD%
exit /b 1

:end_parse

echo.
echo ============================================================
echo  MEDUSA ALL-IN-ONE  --  packaging NMDSFX01
echo ============================================================
echo.

if not exist "%SRC_DIR%" (
    echo ERROR: dossier source introuvable : %SRC_DIR%
    %PAUSE_CMD%
    exit /b 1
)

:: ============================================================================
:: [1/4] MOTEUR
:: ============================================================================
echo [1/4] Detection du moteur...

if not defined ENGINE (
    for /f "delims=" %%f in (
        'dir /b /a-d /o-d "%SRC_DIR%\Nasscad_Medusa_Engine_*.exe" 2^>nul'
    ) do (
        if not defined ENGINE set "ENGINE=%%f"
    )
)

if not defined ENGINE (
    echo.
    echo ERROR: aucun Nasscad_Medusa_Engine_*.exe dans :
    echo   %SRC_DIR%
    echo   ^(lancer build_msvc.bat d'abord^)
    %PAUSE_CMD%
    exit /b 1
)

if not exist "%SRC_DIR%\%ENGINE%" (
    echo ERROR: %ENGINE% introuvable dans %SRC_DIR%
    %PAUSE_CMD%
    exit /b 1
)

echo       Moteur : !ENGINE!

:: Nasscad_Medusa_Engine_3.1.exe  ->  Medusa_Engine_3.1.exe
if not defined OUT set "OUT=%SRC_DIR%\Medusa_Engine_!ENGINE:Nasscad_Medusa_Engine_=!"

echo       Sortie : !OUT!

:: ============================================================================
:: [2/4] STUB
:: ============================================================================
echo.
echo [2/4] Stub auto-extracteur...

set "STUB_TMP="

if defined STUB (
    if not exist "!STUB!" (
        echo ERROR: stub introuvable : !STUB!
        %PAUSE_CMD%
        exit /b 1
    )
    echo       Stub fourni : !STUB!
    goto stub_ok
)

if not exist "%PROJ%\medusa_onefile.c" (
    echo ERROR: medusa_onefile.c introuvable a cote du .bat
    echo        ^(ou passer --stub ^<stub_deja_compile.exe^>^)
    %PAUSE_CMD%
    exit /b 1
)

set "STUB=%TEMP%\medusa_onefile_stub.exe"
set "STUB_TMP=1"

:: --- icone : la meme que le moteur, sinon l'all-in-one sort blanc dans
::     l'explorateur. Si Nasscad_V4.ico est absente on compile quand meme,
::     medusa_onefile.rc la rend optionnelle via #ifdef HAVE_ICON.
set "ICO_DIR="
if exist "%PROJ%\Nasscad_V4.ico" set "ICO_DIR=%PROJ%"
if not defined ICO_DIR if exist "%SRC_DIR%\Nasscad_V4.ico" set "ICO_DIR=%SRC_DIR%"

if defined ICO_DIR (
    echo       Icone  : Nasscad_V4.ico
) else (
    echo       Icone  : absente ^(Nasscad_V4.ico introuvable, stub sans icone^)
)

:: --- cl.exe est-il deja la ? (c'est le cas quand build_msvc.bat nous appelle,
::     il a fait "call vcvars64.bat" a l'etape [1/9])
where cl >nul 2>&1
if not errorlevel 1 goto stub_msvc

:: --- sinon on charge l'environnement VS nous-memes
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "!VSWHERE!" set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"

set "VS_PATH="

if exist "!VSWHERE!" (
    for /f "delims=" %%i in (
        '"!VSWHERE!" -latest -products * -requires Microsoft.VisualCpp.Tools.HostX64.TargetX64 -property installationPath 2^>nul'
    ) do (
        if not defined VS_PATH set "VS_PATH=%%i"
    )
)

if defined VS_PATH (
    if exist "!VS_PATH!\VC\Auxiliary\Build\vcvars64.bat" (
        echo       Chargement de l'environnement Visual Studio...
        call "!VS_PATH!\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
    )
)

where cl >nul 2>&1
if not errorlevel 1 goto stub_msvc

:: --- dernier repli : MinGW
where gcc >nul 2>&1
if not errorlevel 1 goto stub_gcc

echo.
echo ERROR: aucun compilateur trouve ^(ni cl.exe ni gcc^).
echo        Lancer depuis un Developer Command Prompt, installer MinGW-w64,
echo        ou passer --stub ^<stub_deja_compile.exe^>
%PAUSE_CMD%
exit /b 1

:: ---------------------------------------------------------------------------
:: MSVC  --  /MT : CRT statique, le stub ne depend d'aucun redistribuable
:: ---------------------------------------------------------------------------
:stub_msvc

set "RES="
del /q "%TEMP%\medusa_onefile.res" >nul 2>&1

if not exist "%PROJ%\medusa_onefile.rc" goto msvc_compile
where rc >nul 2>&1
if errorlevel 1 goto msvc_compile

if defined ICO_DIR (
    rc /nologo /i "!ICO_DIR!" /d HAVE_ICON /fo "%TEMP%\medusa_onefile.res" "%PROJ%\medusa_onefile.rc" >nul 2>&1
) else (
    rc /nologo /fo "%TEMP%\medusa_onefile.res" "%PROJ%\medusa_onefile.rc" >nul 2>&1
)

if exist "%TEMP%\medusa_onefile.res" set "RES=%TEMP%\medusa_onefile.res"

:msvc_compile

echo       cl /O2 /MT ...

cl /nologo /O2 /MT /W3 /D_CRT_SECURE_NO_WARNINGS ^
   /Fe:"!STUB!" /Fo:"%TEMP%\medusa_onefile.obj" ^
   "%PROJ%\medusa_onefile.c" !RES!

if errorlevel 1 (
    echo.
    echo ERROR: compilation MSVC du stub echouee.
    %PAUSE_CMD%
    exit /b 1
)

del /q "%TEMP%\medusa_onefile.obj" >nul 2>&1
goto stub_ok

:: ---------------------------------------------------------------------------
:: MinGW  --  repli ; c'est la chaine d'origine du stub de septembre 2026
:: ---------------------------------------------------------------------------
:stub_gcc

set "RES="
del /q "%TEMP%\medusa_onefile.res" >nul 2>&1

if not exist "%PROJ%\medusa_onefile.rc" goto gcc_compile
where windres >nul 2>&1
if errorlevel 1 goto gcc_compile

if defined ICO_DIR (
    windres --include-dir "!ICO_DIR!" -DHAVE_ICON "%PROJ%\medusa_onefile.rc" -O coff -o "%TEMP%\medusa_onefile.res" >nul 2>&1
) else (
    windres "%PROJ%\medusa_onefile.rc" -O coff -o "%TEMP%\medusa_onefile.res" >nul 2>&1
)

if exist "%TEMP%\medusa_onefile.res" set "RES=%TEMP%\medusa_onefile.res"

:gcc_compile

echo       gcc -O2 -s ...

gcc -O2 -s -o "!STUB!" "%PROJ%\medusa_onefile.c" !RES! -lkernel32

if errorlevel 1 (
    echo.
    echo ERROR: compilation MinGW du stub echouee.
    %PAUSE_CMD%
    exit /b 1
)

:stub_ok

for %%f in ("!STUB!") do set /a STUB_KB=%%~zf / 1024
echo       Stub OK ^(!STUB_KB! KB^)

:: ============================================================================
:: [3/4] PACKAGING
:: ============================================================================
echo.
echo [3/4] Concatenation moteur + DLL + manifeste...

set "MDS_SELF=%SELF%"
set "MDS_SRC=%SRC_DIR%"
set "MDS_OUT=%OUT%"
set "MDS_STUB=%STUB%"
set "MDS_STAMP=%STAMP%"
set "MDS_ENGINE=%ENGINE%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:MDS_SELF);Invoke-Expression $t.Substring($t.LastIndexOf([char]35+'PS_BEGIN')+9)"

if errorlevel 1 (
    echo.
    echo ERROR: packaging echoue.
    if "%OPT_KEEP%"=="0" if defined STUB_TMP del /q "!STUB!" >nul 2>&1
    %PAUSE_CMD%
    exit /b 1
)

if "%OPT_KEEP%"=="0" if defined STUB_TMP del /q "!STUB!" >nul 2>&1

:: ============================================================================
:: [4/4] RESULTAT
:: ============================================================================
echo.
echo [4/4] Verification...

if not exist "!OUT!" (
    echo ERROR: !OUT! non produit.
    %PAUSE_CMD%
    exit /b 1
)

for %%f in ("!OUT!") do set /a OUT_MB=%%~zf / 1048576

echo.
echo ============================================================
echo  ALL-IN-ONE READY
echo ============================================================
echo   Fichier : !OUT!
echo   Taille  : !OUT_MB! MB
echo.
echo   Au premier lancement le stub extrait tout dans :
echo     %%LOCALAPPDATA%%\NasscadMedusa\^<stamp^>\
echo   puis lance !ENGINE! et lui transmet ses arguments.
echo   Le marqueur .ready fait sauter l'extraction ensuite.
echo ============================================================
echo.

%PAUSE_CMD%
exit /b 0


::  Tout ce qui suit n'est jamais lu par cmd (exit /b ci-dessus) : c'est le
::  packer PowerShell, charge par Invoke-Expression a l'etape [3/4].
::  ---------------------------------------------------------------------------
#PS_BEGIN
$ErrorActionPreference = 'Stop'

$src    = $env:MDS_SRC
$out    = $env:MDS_OUT
$stub   = $env:MDS_STUB
$engine = $env:MDS_ENGINE

if ($env:MDS_STAMP) { $stamp = [uint64]$env:MDS_STAMP }
else { $stamp = [uint64][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }

function Add-Pad([IO.Stream]$s) {
    $r = [int]($s.Length % 512)
    if ($r -ne 0) {
        $z = New-Object byte[] (512 - $r)
        $s.Write($z, 0, $z.Length)
    }
}

# --- liste des fichiers : moteur d'abord, puis les DLL en ordre alphabetique
#     insensible a la casse (ordinal) : c'est exactement l'ordre observe dans
#     Medusa_Engine_3.1.exe.
$files = @((Join-Path $src $engine))
$dlls  = [string[]]@(Get-ChildItem -LiteralPath $src -Filter *.dll -File |
                     ForEach-Object { $_.Name })
if ($dlls.Count -eq 0) { Write-Error "aucune DLL dans $src"; exit 1 }
[Array]::Sort($dlls, [StringComparer]::OrdinalIgnoreCase)
$files += ($dlls | ForEach-Object { Join-Path $src $_ })

Write-Host ("      {0} fichier(s) a embarquer" -f $files.Count)

# --- ecriture
$fs = [IO.File]::Create($out)
try {
    $b = [IO.File]::ReadAllBytes($stub)
    $fs.Write($b, 0, $b.Length)
    Add-Pad $fs

    $man = New-Object System.Collections.ArrayList
    foreach ($f in $files) {
        $off = [uint64]$fs.Position
        $b   = [IO.File]::ReadAllBytes($f)
        $fs.Write($b, 0, $b.Length)
        [void]$man.Add([pscustomobject]@{
            Name = [IO.Path]::GetFileName($f)
            Off  = $off
            Size = [uint64]$b.Length
        })
        Add-Pad $fs
    }

    $manOff = [uint64]$fs.Position
    $bw = New-Object IO.BinaryWriter($fs, [Text.Encoding]::UTF8, $true)

    # manifeste : [u16 nameLen][name UTF-8][u64 offset][u64 size] * count
    foreach ($e in $man) {
        $nb = [Text.Encoding]::UTF8.GetBytes($e.Name)
        $bw.Write([uint16]$nb.Length)
        $bw.Write($nb)
        $bw.Write([uint64]$e.Off)
        $bw.Write([uint64]$e.Size)
    }

    # pied : [u32 count][u64 manifestOffset][u64 stamp]["NMDSFX01"]  = 28 octets
    $bw.Write([uint32]$man.Count)
    $bw.Write([uint64]$manOff)
    $bw.Write([uint64]$stamp)
    $bw.Write([Text.Encoding]::ASCII.GetBytes('NMDSFX01'))
    $bw.Flush()
    $bw.Dispose()
}
finally { $fs.Dispose() }

# --- relecture du pied (controle)
$fs = [IO.File]::OpenRead($out)
try {
    $br = New-Object IO.BinaryReader($fs)
    $fs.Seek(-28, 'End') | Out-Null
    $rc = $br.ReadUInt32()
    $ro = $br.ReadUInt64()
    $rs = $br.ReadUInt64()
    $rm = [Text.Encoding]::ASCII.GetString($br.ReadBytes(8))
    $len = $fs.Length
}
finally { $fs.Dispose() }

if ($rm -ne 'NMDSFX01') { Write-Error "magic relu invalide : $rm"; exit 1 }
if ($rc -ne $man.Count) { Write-Error "count relu incoherent : $rc"; exit 1 }

Write-Host ("      magic    : {0}" -f $rm)
Write-Host ("      count    : {0}" -f $rc)
Write-Host ("      manifest : 0x{0:X}" -f $ro)
Write-Host ("      stamp    : {0}  ({1} UTC)" -f $rs, [DateTimeOffset]::FromUnixTimeSeconds([long]$rs).UtcDateTime.ToString('yyyy-MM-dd HH:mm:ss'))
Write-Host ("      taille   : {0:N0} octets" -f $len)
exit 0
