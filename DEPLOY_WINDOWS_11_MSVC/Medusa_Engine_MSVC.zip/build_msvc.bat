@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
set "PROJ=%cd%"

:: ============================================================================
:: OPTIONS
:: ============================================================================
set "OPT_REBUILD=0"
set "OPT_REBUILD_OCCT=0"
set "OPT_REBUILD_MANIFOLD=0"
set "OPT_BUNDLE=1"
set "OPT_TEST=1"

:parse_args
if "%~1"=="" goto end_parse

if /i "%~1"=="--rebuild" (
    set "OPT_REBUILD=1"
    shift
    goto parse_args
)

if /i "%~1"=="--rebuild-occt" (
    set "OPT_REBUILD_OCCT=1"
    shift
    goto parse_args
)

if /i "%~1"=="--rebuild-manifold" (
    set "OPT_REBUILD_MANIFOLD=1"
    shift
    goto parse_args
)

if /i "%~1"=="--no-bundle" (
    set "OPT_BUNDLE=0"
    shift
    goto parse_args
)

if /i "%~1"=="--no-test" (
    set "OPT_TEST=0"
    shift
    goto parse_args
)

echo ERROR: unknown option: %~1
echo.
echo Options:
echo   --rebuild
echo   --rebuild-occt
echo   --rebuild-manifold
echo   --no-bundle
echo   --no-test
pause
exit /b 1

:end_parse

:: ============================================================================
:: CONSTANTES
:: ============================================================================

set "VCPKG_BASELINE=4334d8b4c8916018600212ab4dd4bbdc343065d1"

:: ---------------------------------------------------------------------------
:: MANIFOLD
:: ---------------------------------------------------------------------------
set "MANIFOLD_VERSION=3.5.2"
set "MANIFOLD_REPO=https://github.com/elalish/manifold.git"

set "MANIFOLD_ROOT=%USERPROFILE%\manifold35_msvc"
set "MANIFOLD_SRC=%MANIFOLD_ROOT%\src"
set "MANIFOLD_BUILD=%MANIFOLD_ROOT%\build"
set "MANIFOLD_INSTALL=%MANIFOLD_ROOT%\install"

:: ---------------------------------------------------------------------------
:: OCCT
::
:: Racine installation :
::   C:\Users\Nasser\occt801_msvc\install
::
:: Headers :
::   install\inc
::
:: MSVC x64 :
::   install\win64\vc14\lib
::   install\win64\vc14\bin
:: ---------------------------------------------------------------------------
set "OCCT_VERSION=8.0.1"
set "OCCT_TAG=V8_0_1"
set "OCCT_REPO=https://github.com/Open-Cascade-SAS/OCCT.git"

set "OCCT_ROOT=%USERPROFILE%\occt801_msvc"
set "OCCT_SRC=%OCCT_ROOT%\occt-src"
set "OCCT_BUILD=%OCCT_ROOT%\build"
set "OCCT_INSTALL=%OCCT_ROOT%\install"
set "OCCT_PLATFORM=%OCCT_INSTALL%\win64\vc14"
set "OCCT_LIB=%OCCT_PLATFORM%\lib"
set "OCCT_BIN=%OCCT_PLATFORM%\bin"
set "OCCT_INC=%OCCT_INSTALL%\inc"

:: ---------------------------------------------------------------------------
:: PROJET
:: ---------------------------------------------------------------------------
set "BUILD_DIR=%PROJ%\build_msvc"
:: [26/08] Valeur de REPLI uniquement. Le vrai nom est relu apres compilation
:: depuis ce que CMake a reellement produit (voir "VERIFICATION EXE" plus bas).
:: C'est cette ligne qui avait fige le nom en 3.1 alors que CMakeLists.txt etait
:: passe en 3.2c : la compilation reussissait, le controle post-build echouait.
set "EXE_NAME=Nasscad_Medusa_Engine_3.1.exe"

:: ============================================================================
:: FICHIERS REQUIS
:: ============================================================================

for %%f in (
    nasscad_medusa.cpp
    nasscad_medusa.rc
    Nasscad_V4.ico
    CMakeLists.txt
    vcpkg.json
    vcpkg-configuration.json
) do (
    if not exist "%%f" (
        echo.
        echo ERROR: %%f not found in:
        echo   %PROJ%
        echo.
        pause
        exit /b 1
    )
)

:: ============================================================================
:: BANNIERE
:: ============================================================================

echo.
echo ============================================================
echo  NASSCAD MEDUSA -- native MSVC build
echo  VS 2026/2022 + vcpkg + Manifold + OCCT 8.0.1
echo ============================================================
echo  Project   : %PROJ%
echo  Manifold  : %MANIFOLD_ROOT%
echo  OCCT      : %OCCT_INSTALL%
echo.
echo  [1/8] Detecting Visual Studio
echo  [2/8] Bootstrap vcpkg
echo  [3/8] vcpkg: pinned baseline + manifold + tbb
echo  [4/8] Manifold 3.5.2 + C binding
echo  [5/8] OCCT 8.0.1 from source
echo  [6/8] Stopping existing server
echo  [7/8] Building nasscad_medusa
echo  [8/8] Auto-test /ping
echo.
echo  Do not close this window.
echo ============================================================
echo.

:: ============================================================================
:: [1/8] DETECTION VISUAL STUDIO
:: ============================================================================

echo [1/8] Detecting Visual Studio...

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"

if not exist "%VSWHERE%" (
    set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"
)

if not exist "%VSWHERE%" (
    echo.
    echo ERROR: vswhere.exe not found.
    echo.
    pause
    exit /b 1
)

echo   vswhere : %VSWHERE%

set "VS_PATH="

for /f "delims=" %%i in ('"%VSWHERE%" -latest -products * -requires Microsoft.VisualCpp.Tools.HostX64.TargetX64 -property installationPath 2^>nul') do (
    if not defined VS_PATH set "VS_PATH=%%i"
)

if not defined VS_PATH (
    echo.
    echo ============================================================
    echo  ERROR: Visual Studio with x64 C++ tools not found.
    echo ============================================================
    echo.
    "%VSWHERE%" -products * -property installationPath
    echo.
    pause
    exit /b 1
)

set "VS_FULL_VER="

for /f "delims=" %%v in ('"%VSWHERE%" -latest -products * -requires Microsoft.VisualCpp.Tools.HostX64.TargetX64 -property installationVersion 2^>nul') do (
    if not defined VS_FULL_VER set "VS_FULL_VER=%%v"
)

set "VS_MAJ="

for /f "tokens=1 delims=." %%m in ("%VS_FULL_VER%") do (
    set "VS_MAJ=%%m"
)

if "%VS_MAJ%"=="18" (
    set "CMAKE_GENERATOR=Visual Studio 18 2026"
    goto :vs_ok
)

if "%VS_MAJ%"=="17" (
    set "CMAKE_GENERATOR=Visual Studio 17 2022"
    goto :vs_ok
)

echo.
echo ERROR: unsupported Visual Studio version:
echo   %VS_FULL_VER%
echo.
pause
exit /b 1

:vs_ok

set "VCVARS=%VS_PATH%\VC\Auxiliary\Build\vcvars64.bat"

if not exist "%VCVARS%" (
    echo.
    echo ERROR: vcvars64.bat not found :
    echo   %VCVARS%
    echo.
    pause
    exit /b 1
)

echo.
echo   Visual Studio : %VS_FULL_VER%
echo   Path          : %VS_PATH%
echo   Generator     : %CMAKE_GENERATOR%
echo   vcvars64      : %VCVARS%
echo.

call "%VCVARS%" >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: MSVC x64 activation failed.
    echo.
    pause
    exit /b 1
)

echo   MSVC x64 active.
echo.

cmake --version >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: CMake not found.
    echo.
    pause
    exit /b 1
)

for /f "tokens=3" %%v in ('cmake --version 2^>nul ^| findstr /b /c:"cmake version"') do (
    set "CMAKE_VERSION=%%v"
)

echo   CMake : !CMAKE_VERSION!

git --version >nul 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: Git not found.
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%g in ('git --version 2^>nul') do (
    echo   Git   : %%g
)

echo.

:: ============================================================================
:: [2/8] BOOTSTRAP VCPKG
:: ============================================================================

echo [2/8] Bootstrap vcpkg...

set "VCPKG_EXE="

if exist "%VS_PATH%\VC\vcpkg\vcpkg.exe" (
    set "VCPKG_ROOT=%VS_PATH%\VC\vcpkg"
    set "VCPKG_EXE=%VS_PATH%\VC\vcpkg\vcpkg.exe"
)

if not defined VCPKG_EXE (
    if defined VCPKG_ROOT (
        if exist "%VCPKG_ROOT%\vcpkg.exe" (
            set "VCPKG_EXE=%VCPKG_ROOT%\vcpkg.exe"
        )
    )
)

if not defined VCPKG_EXE (
    if exist "%LOCALAPPDATA%\vcpkg\vcpkg.exe" (
        set "VCPKG_ROOT=%LOCALAPPDATA%\vcpkg"
        set "VCPKG_EXE=%LOCALAPPDATA%\vcpkg\vcpkg.exe"
    )
)

if not defined VCPKG_EXE (
    for /f "delims=" %%p in ('where vcpkg 2^>nul') do (
        set "VCPKG_EXE=%%p"
        goto :vcpkg_found
    )
)

if not defined VCPKG_EXE (
    echo   vcpkg not found.
    echo   Cloning into %LOCALAPPDATA%\vcpkg...
    echo.

    if not exist "%LOCALAPPDATA%\vcpkg" (
        git clone --depth 1 https://github.com/microsoft/vcpkg.git "%LOCALAPPDATA%\vcpkg"

        if errorlevel 1 (
            echo.
            echo ERROR: git clone vcpkg failed.
            pause
            exit /b 1
        )
    )

    call "%LOCALAPPDATA%\vcpkg\bootstrap-vcpkg.bat" -disableMetrics

    if errorlevel 1 (
        echo.
        echo ERROR: bootstrap vcpkg failed.
        pause
        exit /b 1
    )

    set "VCPKG_ROOT=%LOCALAPPDATA%\vcpkg"
    set "VCPKG_EXE=%LOCALAPPDATA%\vcpkg\vcpkg.exe"
)

:vcpkg_found

if not defined VCPKG_ROOT (
    for %%d in ("%VCPKG_EXE%") do set "VCPKG_ROOT=%%~dpd"
)

if not exist "%VCPKG_EXE%" (
    echo.
    echo ERROR: vcpkg.exe not found :
    echo   %VCPKG_EXE%
    echo.
    pause
    exit /b 1
)

echo   vcpkg : %VCPKG_EXE%
echo   root  : %VCPKG_ROOT%
echo.

:: ============================================================================
:: [3/8] VCPKG
:: ============================================================================

echo [3/8] vcpkg: pinned baseline + manifold + tbb...
echo.

echo   Baseline :
echo     %VCPKG_BASELINE%
echo.

:: AUCUN x-update-baseline.

findstr /i /c:"cbind" "%PROJ%\vcpkg.json" >nul 2>&1

if not errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: vcpkg.json still contains "cbind".
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo   Manifest: manifold + tbb.
echo.

if "%OPT_REBUILD%"=="1" (
    echo   --rebuild : removing vcpkg_installed...
    rd /s /q "%PROJ%\vcpkg_installed" 2>nul
    echo.
)

"%VCPKG_EXE%" install ^
    --triplet x64-windows ^
    --vcpkg-root "%VCPKG_ROOT%" ^
    --x-manifest-root "%PROJ%"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: vcpkg install failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo   manifold + tbb : OK.
echo.

:: ============================================================================
:: [4/8] MANIFOLD
:: ============================================================================

echo [4/8] Manifold %MANIFOLD_VERSION% + C binding...
echo.

if "%OPT_REBUILD_MANIFOLD%"=="1" (
    echo   --rebuild-manifold : removing %MANIFOLD_ROOT%
    rd /s /q "%MANIFOLD_ROOT%" 2>nul
)

if "%OPT_REBUILD%"=="1" (
    echo   --rebuild : removing %MANIFOLD_ROOT%
    rd /s /q "%MANIFOLD_ROOT%" 2>nul
)

set "MANIFOLD_OK=0"

if exist "%MANIFOLD_INSTALL%\include" (
    if exist "%MANIFOLD_INSTALL%\lib\manifold.lib" (
        set "MANIFOLD_OK=1"
    )
)

if "%MANIFOLD_OK%"=="1" (
    echo   Manifold already installed :
    echo     %MANIFOLD_INSTALL%
    echo.
    goto :verify_manifold
)

if not exist "%MANIFOLD_SRC%\CMakeLists.txt" (
    echo   Cloning Manifold %MANIFOLD_VERSION%...
    echo.

    if exist "%MANIFOLD_SRC%" (
        rd /s /q "%MANIFOLD_SRC%" 2>nul
    )

    git clone ^
        --depth 1 ^
        --branch "v%MANIFOLD_VERSION%" ^
        --recurse-submodules ^
        "%MANIFOLD_REPO%" ^
        "%MANIFOLD_SRC%"

    if errorlevel 1 (
        echo.
        echo ERROR: clone of Manifold failed.
        echo.
        pause
        exit /b 1
    )
)

if exist "%MANIFOLD_BUILD%" (
    rd /s /q "%MANIFOLD_BUILD%" 2>nul
)

if not exist "%MANIFOLD_ROOT%" mkdir "%MANIFOLD_ROOT%"
if not exist "%MANIFOLD_BUILD%" mkdir "%MANIFOLD_BUILD%"
if not exist "%MANIFOLD_INSTALL%" mkdir "%MANIFOLD_INSTALL%"

echo.
echo   Checking TBB for Manifold...
echo.

set "TBB_ROOT=%PROJ%\vcpkg_installed\x64-windows"
set "TBB_CMAKE_DIR=%TBB_ROOT%\share\tbb"
set "TBB_CONFIG=%TBB_CMAKE_DIR%\TBBConfig.cmake"

if not exist "%TBB_CONFIG%" (
    echo.
    echo ERROR: TBBConfig.cmake not found :
    echo   %TBB_CONFIG%
    echo.
    pause
    exit /b 1
)

echo   TBBConfig.cmake : OK
echo   TBB root        : %TBB_ROOT%
echo.

echo   CMake configure Manifold...
echo.

cmake "%MANIFOLD_SRC%" ^
    -B "%MANIFOLD_BUILD%" ^
    -G "%CMAKE_GENERATOR%" ^
    -A x64 ^
    -DCMAKE_INSTALL_PREFIX="%MANIFOLD_INSTALL%" ^
    -DCMAKE_TOOLCHAIN_FILE="%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" ^
    -DVCPKG_TARGET_TRIPLET=x64-windows ^
    -DVCPKG_MANIFEST_MODE=OFF ^
    -DCMAKE_PREFIX_PATH="%TBB_ROOT%" ^
    -DTBB_DIR="%TBB_CMAKE_DIR%" ^
    -DMANIFOLD_PAR=TBB ^
    -DMANIFOLD_CBIND=ON ^
    -DMANIFOLD_PYBIND=OFF ^
    -DMANIFOLD_JSBIND=OFF ^
    -DMANIFOLD_TEST=OFF ^
    -DMANIFOLD_DEBUG=OFF ^
    -DMANIFOLD_ASSERT=OFF ^
    -DMANIFOLD_EXPORT=OFF ^
    -DMANIFOLD_CROSS_SECTION=ON ^
    -DMANIFOLD_USE_BUILTIN_TBB=OFF

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: configuration Manifold failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo   Building Manifold...
echo.

cmake --build "%MANIFOLD_BUILD%" --config Release --parallel

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: Manifold build failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo   Installation Manifold...
echo.

cmake --install "%MANIFOLD_BUILD%" --config Release

if errorlevel 1 (
    echo.
    echo ERROR: installation Manifold failed.
    echo.
    pause
    exit /b 1
)

:verify_manifold

echo.
echo   Checking Manifold...

if not exist "%MANIFOLD_INSTALL%\include" (
    echo   MISSING : %MANIFOLD_INSTALL%\include
    echo.
    pause
    exit /b 1
)

if not exist "%MANIFOLD_INSTALL%\lib\manifold.lib" (
    echo   MISSING : %MANIFOLD_INSTALL%\lib\manifold.lib
    echo.
    pause
    exit /b 1
)

echo   Manifold core : OK

set "MANIFOLDC_LIB="
set "MANIFOLDC_DLL="

for /r "%MANIFOLD_BUILD%" %%f in (manifoldc.lib) do (
    if not defined MANIFOLDC_LIB set "MANIFOLDC_LIB=%%f"
)

for /r "%MANIFOLD_BUILD%" %%f in (manifoldc.dll) do (
    if not defined MANIFOLDC_DLL set "MANIFOLDC_DLL=%%f"
)

if defined MANIFOLDC_LIB (
    echo   manifoldc.lib : !MANIFOLDC_LIB!
) else (
    echo   manifoldc.lib : not found
)

if defined MANIFOLDC_DLL (
    echo   manifoldc.dll : !MANIFOLDC_DLL!
) else (
    echo   manifoldc.dll : not found
)

echo.

:: ============================================================================
:: [5/8] OCCT
:: ============================================================================

echo [5/8] OCCT %OCCT_VERSION%...
echo.

echo   Install root:
echo     %OCCT_INSTALL%
echo.
echo   Headers :
echo     %OCCT_INC%
echo.
echo   Libraries :
echo     %OCCT_LIB%
echo.
echo   DLL :
echo     %OCCT_BIN%
echo.

:: ---------------------------------------------------------------------------
:: Ne supprime pas automatiquement l'installation existante.
:: Avec --rebuild-occt / --rebuild seulement on repart de zero.
:: ---------------------------------------------------------------------------

if "%OPT_REBUILD_OCCT%"=="1" (
    echo   --rebuild-occt : removing %OCCT_ROOT%
    rd /s /q "%OCCT_ROOT%" 2>nul
)

if "%OPT_REBUILD%"=="1" (
    echo   --rebuild : removing %OCCT_ROOT%
    rd /s /q "%OCCT_ROOT%" 2>nul
)

set "OCCT_OK=0"

if exist "%OCCT_INC%\Standard_Version.hxx" (
    findstr /c:"8.0.1" "%OCCT_INC%\Standard_Version.hxx" >nul 2>&1

    if not errorlevel 1 (
        if exist "%OCCT_LIB%\TKernel.lib" (
            set "OCCT_OK=1"
        )
    )
)

if "%OCCT_OK%"=="1" (
    echo   OCCT %OCCT_VERSION% already installed.
    echo.
    goto :verify_occt
)

echo   Building OCCT from source.
echo.

if not exist "%OCCT_SRC%\CMakeLists.txt" (
    echo   Cloning OCCT %OCCT_TAG%...
    echo.

    if exist "%OCCT_SRC%" (
        rd /s /q "%OCCT_SRC%" 2>nul
    )

    git clone ^
        --depth 1 ^
        --branch "%OCCT_TAG%" ^
        "%OCCT_REPO%" ^
        "%OCCT_SRC%"

    if errorlevel 1 (
        echo.
        echo ERROR: clone OCCT failed.
        echo.
        pause
        exit /b 1
    )
)

if exist "%OCCT_BUILD%" (
    rd /s /q "%OCCT_BUILD%" 2>nul
)

if not exist "%OCCT_ROOT%" mkdir "%OCCT_ROOT%"
if not exist "%OCCT_BUILD%" mkdir "%OCCT_BUILD%"
if not exist "%OCCT_INSTALL%" mkdir "%OCCT_INSTALL%"

echo.
echo   CMake configure OCCT...
echo.

cmake "%OCCT_SRC%" ^
    -B "%OCCT_BUILD%" ^
    -G "%CMAKE_GENERATOR%" ^
    -A x64 ^
    -DCMAKE_INSTALL_PREFIX="%OCCT_INSTALL%" ^
    -DCMAKE_TOOLCHAIN_FILE="%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" ^
    -DVCPKG_TARGET_TRIPLET=x64-windows ^
    -DVCPKG_MANIFEST_MODE=OFF ^
    -DCMAKE_PREFIX_PATH="%TBB_ROOT%;%OCCT_INSTALL%" ^
    -DBUILD_LIBRARY_TYPE=Shared ^
    -DBUILD_DOC_Overview=OFF ^
    -DBUILD_Inspector=OFF ^
    -DBUILD_MODULE_Visualization=OFF ^
    -DBUILD_MODULE_Draw=OFF ^
    -DUSE_FREETYPE=OFF ^
    -DUSE_TBB=ON ^
    -DUSE_FREEIMAGE=OFF ^
    -DUSE_OPENVR=OFF ^
    -DUSE_FFMPEG=OFF

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: configuration OCCT failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo   Building OCCT.
echo   First build: this can take 20-40 minutes.
echo.

cmake --build "%OCCT_BUILD%" --config Release --parallel

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: OCCT build failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo   Installation OCCT...
echo.

cmake --install "%OCCT_BUILD%" --config Release

if errorlevel 1 (
    echo.
    echo ERROR: installation OCCT failed.
    echo.
    pause
    exit /b 1
)

echo.
echo   OCCT %OCCT_VERSION% installed.
echo.

:: ============================================================================
:: VERIFICATION OCCT
:: ============================================================================

:verify_occt

echo   Checking OCCT headers...
echo.

if not exist "%OCCT_INC%\Standard_Version.hxx" (
    echo.
    echo ============================================================
    echo  ERROR: Standard_Version.hxx not found.
    echo ============================================================
    echo.
    echo Expected:
    echo   %OCCT_INC%\Standard_Version.hxx
    echo.
    echo Install folder:
    dir /b "%OCCT_INSTALL%" 2>nul
    echo.
    pause
    exit /b 1
)

echo   OCCT headers: OK
echo.

echo   Checking OCCT toolkits...
echo.
echo   Headers :
echo     %OCCT_INC%
echo.
echo   Libraries :
echo     %OCCT_LIB%
echo.
echo   DLL :
echo     %OCCT_BIN%
echo.

set "MISS=0"

for %%T in (
    TKernel
    TKMath
    TKG2d
    TKG3d
    TKBRep
    TKGeomBase
    TKGeomAlgo
    TKTopAlgo
    TKMesh
    TKCAF
    TKXCAF
    TKCDF
    TKLCAF
    TKVCAF
    TKShHealing
    TKXSBase
    TKDE
    TKDESTEP
) do (
    if not exist "%OCCT_LIB%\%%T.lib" (
        echo   MISSING : %%T.lib
        set "MISS=1"
    )
)

if "%MISS%"=="1" (
    echo.
    echo ============================================================
    echo  ERROR: OCCT toolkits missing.
    echo ============================================================
    echo.
    echo Contents of lib folder:
    dir /b "%OCCT_LIB%" 2>nul
    echo.
    pause
    exit /b 1
)

echo.
echo   All required OCCT toolkits are present.
echo.

:: ============================================================================
:: [6/8] ARRET SERVEUR
:: ============================================================================

echo [6/8] Stopping existing server...

:: [26/08] Arret de TOUTE instance Nasscad_Medusa_Engine_*, quelle que soit sa
:: version : un binaire d'une version precedente encore en memoire garde le port
:: 8765 et fait echouer l'auto-test /ping de l'etape [8/8].
for /f "tokens=1 delims=," %%p in (
    'tasklist /fo csv /nh 2^>nul ^| findstr /i "Nasscad_Medusa_Engine_"'
) do (
    taskkill /F /IM %%~p >nul 2>&1
)
taskkill /F /IM "%EXE_NAME%" >nul 2>&1
timeout /t 1 /nobreak >nul

echo   OK.
echo.

:: ============================================================================
:: [7/8] CONFIGURATION + COMPILATION NASSCAD
:: ============================================================================

echo [7/8] CMake configure nasscad_medusa...
echo.

if "%OPT_REBUILD%"=="1" (
    rd /s /q "%BUILD_DIR%" 2>nul
)

if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"

echo   OCCT root :
echo     %OCCT_INSTALL%
echo.
echo   OCCT headers :
echo     %OCCT_INC%
echo.
echo   OCCT libs :
echo     %OCCT_LIB%
echo.
echo   Manifold :
echo     %MANIFOLD_INSTALL%
echo.
echo   vcpkg :
echo     %TBB_ROOT%
echo.

:: ---------------------------------------------------------------------------
:: OpenCASCADE peut avoir son fichier de config sous :
::
::   install\win64\vc14\lib\cmake\opencascade
::
:: On le recherche pour donner a CMake le chemin exact si present.
:: ---------------------------------------------------------------------------

set "OCCT_CONFIG_DIR="

for /d %%d in (
    "%OCCT_LIB%\cmake\opencascade"
    "%OCCT_LIB%\cmake\OpenCASCADE"
    "%OCCT_INSTALL%\lib\cmake\opencascade"
    "%OCCT_INSTALL%\lib\cmake\OpenCASCADE"
) do (
    if exist "%%~d" (
        if exist "%%~d\OpenCASCADEConfig.cmake" (
            set "OCCT_CONFIG_DIR=%%~d"
        )
    )
)

if defined OCCT_CONFIG_DIR (
    echo   OpenCASCADEConfig :
    echo     !OCCT_CONFIG_DIR!
    echo.
) else (
    echo   OpenCASCADEConfig : auto-detected via CMAKE_PREFIX_PATH
    echo.
)

if defined OCCT_CONFIG_DIR (
    cmake -S "%PROJ%" ^
        -B "%BUILD_DIR%" ^
        -G "%CMAKE_GENERATOR%" ^
        -A x64 ^
        -DCMAKE_TOOLCHAIN_FILE="%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" ^
        -DVCPKG_TARGET_TRIPLET=x64-windows ^
        -DCMAKE_PREFIX_PATH="%OCCT_INSTALL%;%OCCT_CONFIG_DIR%;%MANIFOLD_INSTALL%;%TBB_ROOT%" ^
        -DOCCT_INSTALL_DIR="%OCCT_INSTALL%" ^
        -DOCCT_PLATFORM_DIR="%OCCT_PLATFORM%" ^
        -DMANIFOLD_INSTALL_DIR="%MANIFOLD_INSTALL%"
) else (
    cmake -S "%PROJ%" ^
        -B "%BUILD_DIR%" ^
        -G "%CMAKE_GENERATOR%" ^
        -A x64 ^
        -DCMAKE_TOOLCHAIN_FILE="%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" ^
        -DVCPKG_TARGET_TRIPLET=x64-windows ^
        -DCMAKE_PREFIX_PATH="%OCCT_INSTALL%;%OCCT_PLATFORM%;%MANIFOLD_INSTALL%;%TBB_ROOT%" ^
        -DOCCT_INSTALL_DIR="%OCCT_INSTALL%" ^
        -DOCCT_PLATFORM_DIR="%OCCT_PLATFORM%" ^
        -DMANIFOLD_INSTALL_DIR="%MANIFOLD_INSTALL%"
)

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: configuration nasscad_medusa failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo   Building nasscad_medusa...
echo.

cmake --build "%BUILD_DIR%" --config Release --parallel

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  ERROR: nasscad_medusa build failed.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

:: ============================================================================
:: VERIFICATION EXE
:: ============================================================================

:: [26/08] Le nom de l'executable n'est plus fige ici : il est RELU depuis ce
:: que CMake vient de produire. Avant, la meme chaine etait codee en dur a deux
:: endroits -- ce .bat et CMakeLists.txt (OUTPUT_NAME). Des que l'un des deux
:: avancait de version, la compilation reussissait puis ce controle echouait sur
:: un nom qui n'existait plus (cas vecu : Nasscad_Medusa_Engine_3.2c.exe produit,
:: Nasscad_Medusa_Engine_3.1.exe attendu). CMakeLists.txt reste la seule source
:: de verite du nom ; ce script se contente de le constater.
:: dir /o-d = du plus recent au plus ancien : si un exe d'une version precedente
:: traine encore dans Release\, c'est bien celui qui vient d'etre compile qui sort.

set "EXE_SRC="

for /f "delims=" %%f in (
    'dir /b /a-d /o-d "%BUILD_DIR%\Release\Nasscad_Medusa_Engine_*.exe" 2^>nul'
) do (
    if not defined EXE_SRC (
        set "EXE_NAME=%%f"
        set "EXE_SRC=%BUILD_DIR%\Release\%%f"
    )
)

if not defined EXE_SRC (
    echo.
    echo ============================================================
    echo  ERROR: no Nasscad_Medusa_Engine_*.exe produced in:
    echo   %BUILD_DIR%\Release
    echo ============================================================
    echo.
    pause
    exit /b 1
)

echo   Executable produced: !EXE_NAME!

copy /y "%EXE_SRC%" "%PROJ%\%EXE_NAME%" >nul

if errorlevel 1 (
    echo.
    echo ERROR: could not copy the executable.
    echo.
    pause
    exit /b 1
)

:: ============================================================================
:: BUNDLE DLL
:: ============================================================================

if "%OPT_BUNDLE%"=="1" (

    echo.
    echo   Copying DLL OCCT...

    if exist "%OCCT_BIN%" (
        for %%f in ("%OCCT_BIN%\*.dll") do (
            copy /y "%%f" "%PROJ%\" >nul 2>&1
        )
    )

    echo   Copying DLL vcpkg...

    set "VCPKG_BIN=%TBB_ROOT%\bin"

    if exist "!VCPKG_BIN!" (
        for %%f in ("!VCPKG_BIN!\*.dll") do (
            copy /y "%%f" "%PROJ%\" >nul 2>&1
        )
    )

    echo   Copying DLL Manifold...

    if exist "%MANIFOLD_INSTALL%\bin" (
        for %%f in ("%MANIFOLD_INSTALL%\bin\*.dll") do (
            copy /y "%%f" "%PROJ%\" >nul 2>&1
        )
    )

    if defined MANIFOLDC_DLL (
        copy /y "!MANIFOLDC_DLL!" "%PROJ%\" >nul 2>&1
    )

    if exist "%BUILD_DIR%\Release" (
        for %%f in ("%BUILD_DIR%\Release\*.dll") do (
            copy /y "%%f" "%PROJ%\" >nul 2>&1
        )
    )

    echo   Bundling complete.
)

:: ============================================================================
:: TAILLE EXE
:: ============================================================================

for %%f in ("%PROJ%\%EXE_NAME%") do (
    set "EXE_SIZE=%%~zf"
)

set /a EXE_KB=!EXE_SIZE! / 1024

echo.
echo ============================================================
echo  BUILD SUCCEEDED
echo ============================================================
echo   Executable : %EXE_NAME%
echo   Size       : !EXE_KB! KB
echo   Folder     : %PROJ%
echo ============================================================
echo.

:: ============================================================================
:: [8/8] AUTO-TEST /PING
:: ============================================================================

if "%OPT_TEST%"=="0" (
    echo [8/8] Self-test skipped (--no-test).
    goto :final_ok
)

echo [8/8] Auto-test /ping...
echo.

taskkill /F /IM "%EXE_NAME%" >nul 2>&1
timeout /t 1 /nobreak >nul

echo   Starting %EXE_NAME%...

start "" /B "%PROJ%\%EXE_NAME%"

set "PING_RESP="

for /l %%i in (1,1,10) do (
    if not defined PING_RESP (
        timeout /t 1 /nobreak >nul

        for /f "delims=" %%r in (
            'curl -sS -m 3 http://127.0.0.1:8765/ping 2^>nul'
        ) do (
            set "PING_RESP=%%r"
        )
    )
)

taskkill /F /IM "%EXE_NAME%" >nul 2>&1

if defined PING_RESP (
    echo.
    echo   OK : /ping -^> !PING_RESP!
) else (
    echo.
    echo   WARNING: no /ping response after 10 seconds.
    echo.
    echo   Manual test:
    echo     start "" "%PROJ%\%EXE_NAME%"
    echo     curl http://127.0.0.1:8765/ping
)

echo.

:final_ok

echo ============================================================
echo  READY
echo ============================================================
echo.
echo   Executable :
echo     %PROJ%\%EXE_NAME%
echo.
echo   Manifold :
echo     %MANIFOLD_INSTALL%
echo.
echo   OCCT :
echo     %OCCT_INSTALL%
echo.
echo   OCCT DLL :
echo     %OCCT_BIN%
echo.
echo   Interface :
echo     http://localhost:8765
echo.
echo ============================================================
echo.

pause
exit /b 0